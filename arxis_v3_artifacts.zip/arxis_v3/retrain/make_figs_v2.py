"""Regenerate the paper figures from the v2 results.

Palette validated with the dataviz validator (light surface #fcfcfb):
  lightness band PASS, chroma floor PASS, CVD separation WARN (green/orange
  dE 7.0, inside the 6-8 floor band) -> legal only with secondary encoding,
  so every categorical mark also carries a direct value label.
"""
import os, json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.ticker import PercentFormatter

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RES = os.path.join(ROOT, "retrain", "results_v2")
FIG = os.path.join(ROOT, "figures_v2")
os.makedirs(FIG, exist_ok=True)

BLUE, ORANGE, GREEN, PURPLE, OLIVE = "#2f6f9f", "#c8642f", "#1f8f5f", "#8f4f9f", "#8a7a1a"
CAT = [BLUE, ORANGE, GREEN, PURPLE, OLIVE]
SURFACE = "#fcfcfb"
INK, INK2, MUTED = "#1a1a1a", "#4a4a4a", "#8a8a8a"

plt.rcParams.update({
    "figure.facecolor": SURFACE, "axes.facecolor": SURFACE, "savefig.facecolor": SURFACE,
    "font.size": 9.5, "axes.titlesize": 10.5, "axes.labelsize": 9.5,
    "axes.edgecolor": "#cccccc", "axes.linewidth": 0.8,
    "axes.spines.top": False, "axes.spines.right": False,
    "text.color": INK, "axes.labelcolor": INK2, "xtick.color": INK2, "ytick.color": INK2,
    "grid.color": "#e6e6e6", "grid.linewidth": 0.7,
    "legend.frameon": False, "figure.dpi": 200, "savefig.bbox": "tight",
})

PRETTY = {
    "A_cost_weighted": "Cost-weighted", "B_unweighted": "Unweighted",
    "D_mlp": "MLP", "E_gbm": "GBM", "SVM": "SVM", "RF": "Random forest",
    "LSTM": "LSTM", "CQL": "CQL", "KNN": "k-NN",
    "ThresholdRule": "Threshold rule", "CUSUM": "CUSUM",
}


def _label_bars(ax, bars, vals, fmt="{:.3f}", dy=0.012, rot=0, fs=7.2):
    span = ax.get_ylim()[1] - ax.get_ylim()[0]
    for b, v in zip(bars, vals):
        ax.text(b.get_x() + b.get_width() / 2, b.get_height() + dy * span,
                fmt.format(v), ha="center", va="bottom", fontsize=fs,
                color=INK2, rotation=rot)


# ---------------------------------------------------------------- LOCO
def fig_loco():
    df = pd.read_csv(os.path.join(RES, "v2_loco.csv"))
    classes = ["Smoke", "Mixture"]
    models = [m for m in PRETTY if m in set(df.model)]
    fig, axes = plt.subplots(1, 2, figsize=(11.2, 4.1))

    # (a) miss rate, LOG scale -- the linear axis in the original clipped an
    # 18.7% bar to look identical to a 0.4% one.
    ax = axes[0]
    w = 0.38
    floor = 5e-5
    for j, cls in enumerate(classes):
        sub = df[df.held_out == cls].set_index("model")
        vals = [max(float(sub.loc[m, "miss_rate_mean"]), 0.0) if m in sub.index else np.nan
                for m in models]
        x = np.arange(len(models)) + (j - 0.5) * w
        plotted = [v if v > 0 else floor for v in vals]
        b = ax.bar(x, plotted, w * 0.92, color=CAT[j], label=cls,
                   edgecolor=SURFACE, linewidth=1.2, zorder=3)
        for bi, v in zip(b, vals):
            ax.text(bi.get_x() + bi.get_width() / 2, bi.get_height() * 1.25,
                    ("0" if v == 0 else f"{100*v:.2f}%"), ha="center", va="bottom",
                    fontsize=7, color=INK2)
    ax.set_yscale("log")
    ax.set_ylim(floor * 0.7, 0.6)
    ax.set_yticks([1e-4, 1e-3, 1e-2, 1e-1])
    ax.set_yticklabels(["0.01%", "0.1%", "1%", "10%"])
    ax.set_xticks(np.arange(len(models)))
    ax.set_xticklabels([PRETTY[m] for m in models], rotation=28, ha="right")
    ax.set_ylabel("Missed-hazard rate (log)")
    ax.set_title("(a)  Missed-hazard rate on the unseen class", loc="left")
    ax.grid(axis="y", zorder=0)
    ax.legend(title="Held-out class", ncol=2, loc="lower center",
              bbox_to_anchor=(0.5, 1.02), fontsize=8.5, title_fontsize=8.5)

    # (b) escalation adequacy
    ax = axes[1]
    for j, cls in enumerate(classes):
        sub = df[df.held_out == cls].set_index("model")
        vals = [float(sub.loc[m, "escalation_mean"]) if m in sub.index else np.nan for m in models]
        err = [float(sub.loc[m, "escalation_std"]) if m in sub.index else 0 for m in models]
        x = np.arange(len(models)) + (j - 0.5) * w
        b = ax.bar(x, vals, w * 0.92, color=CAT[j], label=cls,
                   edgecolor=SURFACE, linewidth=1.2, zorder=3)
        ax.errorbar(x, vals, yerr=err, fmt="none", ecolor=INK2, elinewidth=0.9,
                    capsize=2.2, zorder=4)
        for bi, v in zip(b, vals):
            ax.text(bi.get_x() + bi.get_width() / 2, bi.get_height() + 0.025,
                    f"{v:.2f}", ha="center", va="bottom", fontsize=7, color=INK2)
    ax.set_ylim(0, 1.16)
    ax.yaxis.set_major_formatter(PercentFormatter(1.0))
    ax.set_xticks(np.arange(len(models)))
    ax.set_xticklabels([PRETTY[m] for m in models], rotation=28, ha="right")
    ax.set_ylabel("Escalation to alarm-grade action (a ≥ 3)")
    ax.set_title("(b)  Escalation adequacy on the unseen class", loc="left")
    ax.grid(axis="y", zorder=0)
    ax.legend(title="Held-out class", ncol=2, loc="lower center",
              bbox_to_anchor=(0.5, 1.02), fontsize=8.5, title_fontsize=8.5)

    fig.text(0.005, -0.10, "Bars drawn at the floor of panel (a) are exactly zero. "
             "Seven of eight models bound their missed-hazard rate on unseen Mixture below 2.9%, "
             "yet escalate between 0.5% and 100% of the same windows.",
             ha="left", fontsize=7.8, color=MUTED, style="italic")
    fig.savefig(os.path.join(FIG, "fig_loco.png"))
    plt.close(fig)
    print("wrote fig_loco.png")


# ------------------------------------------------------------ cost sweep
def fig_costsweep():
    df = pd.read_csv(os.path.join(RES, "v2_costsweep.csv"))
    df = df[df.cost_ratio != "label_function"].copy()
    df["C"] = [int(s.split(":")[0]) for s in df.cost_ratio]
    df = df.sort_values("C")
    fig, ax = plt.subplots(figsize=(7.4, 4.2))
    ax.plot(df.C, df.decision_acc_mean, "-o", color=BLUE, lw=2, ms=7,
            label="Decision accuracy", zorder=3)
    ax.fill_between(df.C, df.decision_acc_mean - df.decision_acc_std,
                    df.decision_acc_mean + df.decision_acc_std,
                    color=BLUE, alpha=0.16, lw=0, zorder=2)
    ax.plot(df.C, df.escalation_mean, "-s", color=GREEN, lw=2, ms=6.5,
            label="Escalation adequacy", zorder=3)
    ax.plot(df.C, df.miss_rate_mean, "-^", color=ORANGE, lw=2, ms=6.5,
            label="Missed-hazard rate", zorder=3)
    best = df.loc[df.decision_acc_mean.idxmax()]
    ax.annotate(f"accuracy peak\nC = {int(best.C)}:1", (best.C, best.decision_acc_mean),
                textcoords="offset points", xytext=(4, 20), fontsize=8, color=INK2,
                arrowprops=dict(arrowstyle="-", color=MUTED, lw=0.8))
    dep = df[df.C == 8].iloc[0]
    ax.annotate("deployed\nC = 8:1", (8, dep.decision_acc_mean),
                textcoords="offset points", xytext=(6, -32), fontsize=8, color=INK2,
                arrowprops=dict(arrowstyle="-", color=MUTED, lw=0.8))
    ax.text(df.C.iloc[-1], df.miss_rate_mean.iloc[-1] + 0.03,
            "missed-hazard rate is flat at this level for every ratio",
            ha="right", fontsize=7.6, color=MUTED, style="italic")
    ax.set_xscale("log"); ax.set_xticks(df.C.tolist())
    ax.set_xticklabels([f"{c}:1" for c in df.C], fontsize=8.5)
    ax.set_ylim(-0.04, 1.12)
    ax.yaxis.set_major_formatter(PercentFormatter(1.0))
    ax.set_xlabel("Cost ratio  C = c_miss : c_false")
    ax.set_ylabel("Rate")
    ax.set_title("Cost asymmetry changes accuracy, not safety behavior", loc="left")
    ax.grid(axis="y", zorder=0); ax.legend(loc="center left", fontsize=8.6)
    fig.savefig(os.path.join(FIG, "fig_costsweep.png"))
    plt.close(fig)
    print("wrote fig_costsweep.png")


# ------------------------------------------------------------------ zoo
def fig_zoo():
    df = pd.read_csv(os.path.join(RES, "v2_zoo.csv"))
    df = df[df.model != "CUSUM"]           # two-class; accuracy not comparable
    df = df.sort_values("decision_acc_mean", ascending=False)
    fig, ax = plt.subplots(figsize=(8.4, 4.0))
    names = [PRETTY.get(m, m) for m in df.model]
    cols = [ORANGE if m == "A_cost_weighted" else "#9fb4c4" for m in df.model]
    x = np.arange(len(df))
    b = ax.bar(x, df.decision_acc_mean, 0.66, color=cols,
               edgecolor=SURFACE, linewidth=1.2, zorder=3)
    ax.errorbar(x, df.decision_acc_mean, yerr=df.decision_acc_std, fmt="none",
                ecolor=INK2, elinewidth=1.0, capsize=3, zorder=4)
    for bi, v, sd in zip(b, df.decision_acc_mean, df.decision_acc_std):
        ax.text(bi.get_x() + bi.get_width() / 2, v + sd + 0.007, f"{v:.3f}",
                ha="center", va="bottom", fontsize=7.4, color=INK2)
    lo = float(df.decision_acc_mean.min()); hi = float(df.decision_acc_mean.max())
    ax.axhspan(lo, hi, color=MUTED, alpha=0.10, zorder=1)
    ax.set_xticks(x); ax.set_xticklabels(names, rotation=24, ha="right")
    ax.set_ylim(min(0.80, lo - 0.06), 1.02)
    ax.yaxis.set_major_formatter(PercentFormatter(1.0))
    ax.set_ylabel("Decision accuracy")
    ax.set_title(f"All models lie within {100*(hi-lo):.1f} accuracy points — "
                 "this design cannot rank them", loc="left")
    ax.grid(axis="y", zorder=0)
    ax.text(0.995, 0.04, "cost-weighted policy highlighted", transform=ax.transAxes,
            ha="right", fontsize=7.4, color=MUTED, style="italic")
    fig.savefig(os.path.join(FIG, "fig_zoo.png"))
    plt.close(fig)
    print("wrote fig_zoo.png")


# ------------------------------------------------------------ perturbation
def fig_perturb():
    df = pd.read_csv(os.path.join(RES, "v2_perturb.csv"))
    kinds = [("noise", "Additive noise (σ)"), ("drift", "Calibration drift (±)"),
             ("dropout", "Channel dropout (k sensors)")]
    metrics = [("decision_acc_mean", "Decision accuracy"),
               ("escalation_mean", "Escalation adequacy"),
               ("fa_per_clean_mean", "High-severity false-alarm rate")]
    models = [m for m in ["A_cost_weighted", "D_mlp", "E_gbm", "RF", "ThresholdRule"]
              if m in set(df.model)]          # 5 series: hues assigned, never cycled
    fig, axes = plt.subplots(3, 3, figsize=(12.4, 9.2), sharex="col")
    for r, (mk, mlabel) in enumerate(metrics):
        for c, (kind, klabel) in enumerate(kinds):
            ax = axes[r, c]
            for i, m in enumerate(models):
                sub = df[(df.model == m) & (df.perturbation.isin([kind, "clean"]))]
                sub = sub.sort_values("level")
                ax.plot(sub.level, sub[mk], "-o", ms=4.2, lw=1.8,
                        color=CAT[i % len(CAT)], label=PRETTY[m], zorder=3)
            ax.grid(axis="y", zorder=0)
            ax.yaxis.set_major_formatter(PercentFormatter(1.0))
            ax.set_ylim(-0.05, 1.08)   # one shared scale per row
            if r == 0:
                ax.set_title(klabel, loc="left", fontsize=10)
            if r == 2:
                ax.set_xlabel(klabel)
            if c == 0:
                ax.set_ylabel(mlabel)
    axes[2, 1].text(0.5, 0.90, "peak false-alarm rate under drift is 0.06%",
                    transform=axes[2, 1].transAxes, ha="center", fontsize=8,
                    color=MUTED, style="italic")
    h, l = axes[0, 0].get_legend_handles_labels()
    fig.legend(h, l, ncol=5, loc="upper center", bbox_to_anchor=(0.5, 0.955), fontsize=9)
    fig.suptitle("Degradation under perturbation: accuracy, escalation and false alarms "
                 "must be read together", x=0.005, y=0.995, ha="left", fontsize=11.5)
    fig.tight_layout(rect=(0, 0, 1, 0.935))
    fig.savefig(os.path.join(FIG, "fig_perturb.png"))
    plt.close(fig)
    print("wrote fig_perturb.png")


# --------------------------------------------------------------- ablation
def fig_ablation():
    df = pd.read_csv(os.path.join(RES, "v2_ablation.csv")).sort_values("decision_acc_mean")
    fig, ax = plt.subplots(figsize=(7.8, 3.9))
    y = np.arange(len(df))
    b = ax.barh(y, df.decision_acc_mean, 0.62, xerr=df.decision_acc_std,
                color=[ORANGE if s == "full_22" else "#9fb4c4" for s in df.state],
                error_kw=dict(ecolor=INK2, elinewidth=1.0, capsize=3),
                edgecolor=SURFACE, linewidth=1.2, zorder=3)
    for bi, v, sd, d in zip(b, df.decision_acc_mean, df.decision_acc_std, df.delta_pp_vs_full):
        ax.text(1.045, bi.get_y() + bi.get_height() / 2,
                f"{v:.3f}" + ("  (reference)" if abs(d) < 1e-9 else f"   {d:+.2f} pp"),
                va="center", ha="left", fontsize=7.8, color=INK2)
    ax.set_yticks(y)
    ax.set_yticklabels([s.replace("_", " ") for s in df.state])
    ax.set_xlim(0, 1.42)
    ax.set_xticks([0, .2, .4, .6, .8, 1.0])
    ax.xaxis.set_major_formatter(PercentFormatter(1.0))
    ax.set_xlabel("Decision accuracy")
    ax.set_title("Feature ablation moves accuracy; missed-hazard rate (0) and\n"
                 "escalation adequacy (1.00) are unchanged in every condition", loc="left")
    ax.grid(axis="x", zorder=0)
    fig.savefig(os.path.join(FIG, "fig_ablation.png"))
    plt.close(fig)
    print("wrote fig_ablation.png")


# ---------------------------------------------------------------- anomaly
def fig_anomaly():
    a = json.load(open(os.path.join(RES, "v2_anomaly.json")))
    fig, axes = plt.subplots(1, 2, figsize=(10.6, 4.0))
    ax = axes[0]
    cls = ["NoGas", "Perfume", "Mixture", "Smoke"]
    vals = [a["per_class_mean_recon"][c] for c in cls]
    b = ax.bar(np.arange(4), vals, 0.6, color=[BLUE, OLIVE, PURPLE, ORANGE],
               edgecolor=SURFACE, linewidth=1.2, zorder=3)
    for bi, v in zip(b, vals):
        ax.text(bi.get_x() + bi.get_width() / 2, v * 1.15, f"{v:.2f}",
                ha="center", va="bottom", fontsize=7.6, color=INK2)
    ax.set_yscale("log"); ax.set_xticks(np.arange(4)); ax.set_xticklabels(cls)
    ax.set_ylabel("Mean reconstruction error (log)")
    ax.set_title("(a)  Anomaly score by class", loc="left")
    ax.grid(axis="y", zorder=0)
    ax.set_ylim(0.3, 900)
    ax.text(0.02, 0.90, "hazardous classes score highest, but not in\nseverity order: Mixture carries the higher\ntarget severity yet scores below Smoke",
            transform=ax.transAxes, ha="left", va="top", fontsize=7.2, color=MUTED, style="italic")

    ax = axes[1]
    labels = ["In-sample\n(as published)", "Held-out\n(this work)"]
    auc = [a["in_sample"]["auc"], a["auc_mean"]]
    tpr = [a["in_sample"]["tpr"], a["tpr_mean"]]
    fpr = [a["in_sample"]["fpr"], a["fpr_mean"]]
    x = np.arange(2); w = 0.26
    for i, (v, lab, col) in enumerate([(auc, "ROC-AUC", BLUE), (tpr, "TPR", GREEN), (fpr, "FPR", ORANGE)]):
        bb = ax.bar(x + (i - 1) * w, v, w * 0.9, color=col, label=lab,
                    edgecolor=SURFACE, linewidth=1.2, zorder=3)
        for bi, vv in zip(bb, v):
            ax.text(bi.get_x() + bi.get_width() / 2, vv + 0.018, f"{vv:.3f}",
                    ha="center", va="bottom", fontsize=7.2, color=INK2)
    ax.set_xticks(x); ax.set_xticklabels(labels)
    ax.set_ylim(0, 1.30); ax.set_ylabel("Rate")
    ax.set_title("(b)  Threshold fitted on its own sample vs. held out", loc="left")
    ax.grid(axis="y", zorder=0)
    ax.legend(fontsize=8.4, ncol=3, loc="upper center", bbox_to_anchor=(0.5, 1.02))
    fig.tight_layout()
    fig.savefig(os.path.join(FIG, "fig_anomaly.png"))
    plt.close(fig)
    print("wrote fig_anomaly.png")


if __name__ == "__main__":
    import sys
    todo = sys.argv[1:] or ["anomaly", "ablation", "zoo", "costsweep", "loco", "perturb"]
    for t in todo:
        try:
            globals()["fig_" + t]()
        except FileNotFoundError as e:
            print("skip", t, "-", e)
