# ARXIS revision v6

`ARXIS_Manuscript_v6.md` is the current manuscript. 15 figures, 10 tables.
Sections 4.1 to 4.7 come entirely from the result files in `results_v2/`.

## Change from v5
The hardware-deployment section has been removed in full: no Raspberry Pi
evaluation was performed, so no latency, footprint, quantization or thermal
result is claimed anywhere. Everything that depended on it was rewritten
rather than deleted, in particular the alarm-burden analysis, which is now
expressed per 1,000 clean windows and is independent of any duty cycle.

## Figures (in order of appearance)
| File | Fig. | Shows |
|---|---|---|
| fig_protocol.png     | 1  | corpus layout, held-out block, 20-window embargo |
| fig_architecture.png | 2  | pipeline diagram, advisory boundary marked |
| fig_perception.png   | 3  | thermal confusion matrices + per-class scores |
| fig_anomaly.png      | 4  | per-class anomaly score; in-sample vs held-out point |
| fig_roc.png          | 5  | ROC per seed vs in-sample; score distributions by class |
| fig_zoo.png          | 6  | in-distribution decision accuracy, 10 models |
| fig_actionmatrix.png | 7  | action-selection matrices; action 2 never selected |
| fig_dissociation.png | 8  | in-distribution accuracy vs out-of-distribution safety |
| fig_loco.png         | 9  | leave-one-class-out miss rate (log) and escalation |
| fig_disposition.png  | 10 | alarm / sub-alarm / passive on unseen hazards |
| fig_costsweep.png    | 11 | cost ratio 1:1 to 20:1 |
| fig_ablation.png     | 12 | decision-state feature ablation |
| fig_perturb.png      | 13 | graded noise / drift / dropout, three metrics |
| fig_alarmburden.png  | 14 | alarms per 1,000 clean windows vs EEMUA 191 |
| fig_calibration.png  | 15 | ECE with bootstrap CIs, class-conditional, bin sweep |

## Code (drop into `retrain/`)
safety_metrics.py, new_baselines.py, run_all_v2.py, run_loco_v3.py,
run_calib_actions_v2.py, make_figs_v2.py

Run order: run_all_v2.py, run_loco_v3.py, run_calib_actions_v2.py, make_figs_v2.py

## Superseded
`retrain/results/` and `paper_figures/` came from the earlier pipeline, and the
`paper_figures/` filenames are offset by two relative to their content. Do not
mix the two sets.
