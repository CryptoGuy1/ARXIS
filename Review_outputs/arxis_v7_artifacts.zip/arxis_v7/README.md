# ARXIS revision v7

`ARXIS_Manuscript_v7.md` is the current manuscript. 15 figures, 10 tables,
three appendices. Sections 4.1 to 4.7 come from the result files in results_v2/.

## Changes in v7 (revision-brief pass)
- Action 2 contradiction resolved. Table 3 previously said "Operator
  notification and secondary sensor check" while every metric and every other
  sentence treated actions 1 and 2 as sub-alarm. The evaluation code counts
  escalation as a>=3, so the table was wrong and has been corrected. The design
  question is logged in Appendix C item 1.
- Per-hour alarm figures no longer rest on a [CITATION NEEDED] placeholder.
  The corpus has no timestamp column, so the hourly conversion is now stated
  as an illustration conditioned on an assumed duty cycle, with per-1,000-window
  as the primary quantity.
- "A facility running a hundred detectors would notice inside one shift" removed
  as an unsupported field-performance claim.
- Model subsets per experiment stated explicitly (11 / 8 / 5 / 1).
- MQ table reworded for cross-sensitivity; no selectivity implied.
- Research questions labelled RQ1-RQ4 and mapped to the sections that answer them.
- IEC 61511 wording softened to an architectural rationale, not a claim about
  what the standard permits.
- Novelty claim qualified.
- Zero-count language: "no observed missed hazards" with bounds, not "zero".
- Decision accuracy explicitly labelled as not a safety metric.
- Threshold-rule result guarded against the "simple models are better" reading.
- New Appendix C, Author Verification Items (5 entries).

## Figures (in order)
protocol, architecture, perception, anomaly, roc, zoo, actionmatrix,
dissociation, loco, disposition, costsweep, ablation, perturb, alarmburden,
calibration

## Code (drop into retrain/)
safety_metrics.py, new_baselines.py, run_all_v2.py, run_loco_v3.py,
run_calib_actions_v2.py, make_figs_v2.py
Run order: run_all_v2.py, run_loco_v3.py, run_calib_actions_v2.py, make_figs_v2.py
