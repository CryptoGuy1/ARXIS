# v15: the pre-submission review, worked through

The reviewer's blocker was real, and worse than stated. Everything else on the
list is done except four facts only you hold, which now fail the suite loudly
instead of sitting in the paper as promises.

---

## 1. The Figure 7 mismatch — two defects, not one

**The panel plotted a different fit from the paragraph beside it.** The result
file holds two per-class reconstruction summaries: `per_class_mean_recon`, the
whole-corpus fit, and `per_class_mean_recon_partition`, the partition-local fit
that every number in the paper uses. The prose quoted the partition-local values
(0.023, 0.107, 164.7, 80.6) and cited Fig. 7a; Fig. 7a plotted the whole-corpus
ones (0.74, 1.54, 117.72, 229.25). The figure was showing the leaky fit while
the text described the corrected one — on the very quantity the leakage argument
turns on.

Fig. 7a now plots the partition-local fit with the across-seed standard
deviation, so the panel and the paragraph carry the same four numbers.

**The 0.9928 anomaly AUC is in no result file.** This is the part the reviewer
could not see from outside. Searching every stored result for that value turns
it up only in `v3_leakage.csv`, where it is a *decision accuracy* under the
random-split protocol. The sentence had conflated a decision accuracy with an
anomaly ROC-AUC, and it has been carried unchanged since v11.

The stored whole-corpus anomaly fit is ROC-AUC **0.9622** at FPR **0.0500**.
Against the partition-local 0.9251 ± 0.0618 that is **3.7 points** of
discrimination, not seven, and the false-positive rate **more than doubles**
rather than rising from zero. The paragraph now says exactly that. The claim is
weaker than it was, and it is now the claim the data support.

Panel (b)'s axis label read "In-sample (as published)", which implied the number
came from someone else's publication. It is this study's own earlier fit, and
the labels now say so: "Whole-corpus fit (earlier implementation)" against
"Partition-local fit (this work)".

**Seven gates were added** so none of this can drift again. They assert that the
prose contains the stored values in the form the result file holds them, that
"0.9928" and "no observed false positive" are absent, that the described
direction of the false-positive change matches the file, and that Fig. 7a is
drawn from the partition-local key. Putting the old sentence back makes two of
them fail, which is how I know they work.

## 2. The five-quantity terminology

Three places named three different fives. The Summary said "five-quantity safety
metric set" while the body says decision accuracy is not a safety metric; Table 5
listed accuracy plus four safety-relevant rates; Fig. 1 listed four safety rates
plus alarm burden.

One name and one membership now: a **five-quantity evaluation set**, decision
accuracy beside four safety-relevant rates. Alarm burden is stated as the
false-alarm rate in operational units under Eq. 9, not a sixth quantity — in the
defining section and under Fig. 1's metric bar. Fig. 1's five cells are now
Table 5's five rows, and a gate compares them.

## 3. The both-rates sentence

"Both rates are reported from here on" promised more than the tables deliver.
It now reads that the all-nonhazardous rate is reported as a sensitivity
alongside the primary clean-air rate where it bears on a claim, and that Eq. 8
itself stays NoGas-only.

## 4. A current drift reference

Added to the unknown-gases discussion and verified against the publisher's own
page rather than from memory: Lin, J. and Zhan, X. 2026, *Sensor-Drift
Compensation in Electronic-Nose-Based Gas Recognition Using Knowledge
Distillation*, Informatics 13 (1): 15, doi 10.3390/informatics13010015. It suits
the point being made because it evaluates with repeated randomized trials and
significance testing rather than a single split.

## 5. The repository landing page

The README now opens with a blockquote stating that the paper reproduces from the
tag `v13-submission`, not from the tip of the default branch, with the two
commands that check and rebuild it, and a note that the default branch carries
development material.

## 6. The page proof, which nothing had ever looked at

The review's last item was a visual check of the built document. Doing it turned
up five defects that exist only after the Markdown has become a paginated file,
and that no check in the repository could have caught, because every check ran on
the sources.

**Fig. 5's caption was missing two symbols.** It was written with `$V$` and
`$A$`. Pandoc turns inline TeX into an OMML run, which Word renders and
LibreOffice, Google Docs and several PDF converters drop silently. The caption
read " = value stream;  = advantage stream" in everything but Word. It is now
set in italic like every other symbol in the paper, and a gate rejects inline
TeX anywhere in either source.

**The author line printed its affiliation markers as carets.** `^1,2,\*` is not
superscript in Pandoc, which needs a closing caret, so the title page read
"Nweke^1,2,\*" and ran the two affiliations together on one line. Three
exponents in the body had the same defect. Both are fixed, and a gate requires
every superscript marker to be closed.

**Words were being broken mid-word inside table columns.** Pandoc gives every
column an equal share of the text width, so `Conservative` printed as
"Conservati / ve" and `retrain/run_overlap_isolation.py` as "isolati / o / n"
while a column of four-digit numbers sat half empty. Each column now gets the
width its widest unbreakable word needs, and what is left over is shared out in
proportion to how much text the column carries. Tables are set at 9 pt, as SPE
sets them, stepping down only where a column demands it: one table, the
provenance map with its file paths, is at 7 pt.

**Table rows broke across page boundaries,** so a row's first line sat at the
foot of one page and the rest opened the next. Every row now carries
`w:cantSplit`.

**Fig. 2 was separated from its caption,** image at the foot of page 9 and
caption at the head of page 10. Every figure paragraph now carries `w:keepNext`.

The document build was a pandoc command typed by hand, which is why none of this
was reproducible. It is now `build_docx.py` and `make docx`, and
`check_page_proof.py` reads the built document the way a production editor
would: it builds both documents, renders them, and fails if any word is broken
across a line, if any figure reaches the page at other than 6.50 in, if any table
row can break across a page, if any figure is not bound to its caption, or if
the figure and table captions are not present once each, in order, with every
cross-reference resolving. It runs under `make proof` and inside `make check`.
Putting each defect back makes the matching check fail, which is how I know they
work.

The manuscript is 53 pages, down from 60, entirely from the table work.

One thing this pass could not settle: the 0.126 in right-shift LibreOffice gives
every inline image is a quirk of that renderer, not of the file. The document
declares 1 in margins, a 6.5 in text column and a 6.5 in image, with no indent;
a control document built the same way shifts by the same 0.126 in whatever width
the image is given. Word will place them at the margin.

---

## What is left, and why I did not invent it

Four facts are yours to supply. Rather than leave them as prose promises, each is
now an explicit placeholder that fails `verify_v13.py`:

| Placeholder | Where | What it needs |
|---|---|---|
| `⟨ULTRALYTICS_VERSION⟩` | Appendix A | the exact version used to train the thermal classifier |
| `⟨REPOSITORY_URL⟩` | Data and Code Availability | the public repository URL |
| `⟨COMMIT_SHA⟩` | Data and Code Availability | the commit the `v13-submission` tag points at |
| `⟨ARCHIVE_DOI⟩` | Data and Code Availability | the archival deposit DOI |

The availability statement no longer says a DOI "will be added once minted"; a
gate rejects that wording, because a reproducibility statement that defers its
own identifier is the thing the reviewer objected to.

## State

| Suite | Result |
|---|---|
| `verify_v13.py` | 1,001 checks, 4 failures, all four the placeholders above |
| `self_audit.py` | 974 checks, 0 |
| `test_safety_metrics.py` | 30 assertions, 0 |
| `audit_release.py` | 0 problems |
| `check_figure_text.py` | 23 figures, 0 overlapping pairs, 0 labels outside a box |
| `check_page_proof.py` | 27 checks, 0 |

Supply the four values and the suite goes green.

## One judgement call I did not make for you

Fig. 1 is set in a Times-metric serif to match the model paper. The other
twenty-two figures are sans-serif. Within one paper that is a visible
inconsistency and a production editor may flag it. Moving everything to serif is
a bounded job because the text-overlap checker verifies the result mechanically,
but it touches every figure, so I have left it for you to call.
