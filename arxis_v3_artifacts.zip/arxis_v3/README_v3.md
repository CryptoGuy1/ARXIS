# ARXIS revision v3 — re-run artifacts

Generated 9 Sep 2026. Everything in Sections 4.1-4.6 of `ARXIS_Manuscript_v3.md`
comes from these files.

## New code (drop into `retrain/`)
- `safety_metrics.py`  metric set: missed hazard, escalation adequacy, under-escalation,
                       false alarm per clean window, mean action severity, Clopper-Pearson bounds
- `new_baselines.py`   k-NN, depth-3 threshold rule on raw MQ channels, CUSUM detector
- `run_all_v2.py`      model comparison, cost sweep, perturbation suite, ablation, anomaly eval
- `run_loco_v3.py`     leave-one-class-out with scaling fitted on the 3 training classes only
- `make_figs_v2.py`    Figs. 1-6

Run: `python retrain/run_all_v2.py` then `python retrain/run_loco_v3.py` then
`python retrain/make_figs_v2.py`.

## Results (`results_v2/`)
| File | Contents |
|---|---|
| v2_zoo.csv / v2_zoo_sig.json | 11 models x 5 seeds, full metric set + paired Wilcoxon |
| v2_loco.csv | leave-one-class-out, 8 models x 2 held-out classes, escalation reported |
| v2_costsweep.csv | cost ratio 1:1..20:1 + label-function reference |
| v2_perturb.csv | noise / drift / dropout at graded severity, 6 models |
| v2_ablation.csv | 7 decision-state variants |
| v2_anomaly.json | held-out vs in-sample operating point, per-class scores |

## Superseded
The files in `retrain/results/` were produced on the earlier pipeline and by an
evaluation that omitted escalation and used a per-alert false-alarm denominator.
Do not mix the two sets.

## Corrected pipeline facts
6,324 windows (1,581/class) after dropping class-boundary-straddling windows;
4,980 train / 1,264 test (316/class); embargo G=20; held-out block position varies
with the seed; all scaling fitted on the training partition only.
