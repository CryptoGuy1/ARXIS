# ARXIS revision v4

`ARXIS_Manuscript_v4.md` is the current manuscript. Sections 4.1 to 4.6 come
entirely from the result files in `results_v2/`.

## Figures (figures_v2/, all referenced from the manuscript)
| File | Manuscript | Shows |
|---|---|---|
| fig_protocol.png    | Fig. 1  | corpus layout, held-out block, 20-window embargo |
| fig_anomaly.png     | Fig. 2  | per-class anomaly score; in-sample vs held-out operating point |
| fig_zoo.png         | Fig. 3  | in-distribution decision accuracy, 10 models |
| fig_dissociation.png| Fig. 4  | in-distribution accuracy vs out-of-distribution safety (the money plot) |
| fig_loco.png        | Fig. 5  | leave-one-class-out miss rate (log axis) and escalation |
| fig_disposition.png | Fig. 6  | where hazardous windows go: alarm / sub-alarm / passive |
| fig_costsweep.png   | Fig. 7  | cost ratio 1:1 to 20:1 |
| fig_ablation.png    | Fig. 8  | decision-state feature ablation |
| fig_perturb.png     | Fig. 9  | graded noise / drift / dropout, three metrics |
| fig_alarmburden.png | Fig. 10 | false alarms converted to alarms per hour vs EEMUA 191 |

## Code (drop into `retrain/`)
safety_metrics.py, new_baselines.py, run_all_v2.py, run_loco_v3.py, make_figs_v2.py

Run order: `run_all_v2.py`, then `run_loco_v3.py`, then `make_figs_v2.py`.

## Superseded
Files in `retrain/results/` came from the earlier pipeline and from an evaluation
that omitted escalation and used a per-alert false-alarm denominator. Do not mix
the two sets.
