# Supporting Information

**ARXIS: Safety-Relevant Evaluation of Gas-Hazard Monitoring Models Under Distribution Shift and Sensor Degradation**

Benjamin C. Nweke, Gholamreza Ramezan, Soheil Saraji

This file carries the material referenced from the manuscript body. Nothing here
is a separate result: every number is produced by the same drivers, from the same
result files, under the same protocol, and is checked by the same verification
script. It is here because the components and experiments below do not determine
the paper's safety findings and their full treatment would crowd out the ones
that do.

Objects are numbered S1, S2, S3 and are cited from the body by those labels.

---

## S1 Perception Component

The thermal path is described here in full. It is worth being explicit about why
it sits in supporting information: the decision state of Eq. 1 carries no visual
term, so no safety result in the manuscript depends on any number in this
section, and the component's evaluation is held to a weaker standard than the
sensor path's.

**Training.** Thermal images are classified with YOLOv8n-cls (Jocher et al.
2023), the smallest classification variant in the family. Images are resized to
224 by 224 and the network starts from pretrained weights. Training uses AdamW at
10⁻³ with cosine annealing, weight decay 10⁻⁴, batch size 32 and 50 epochs, with
random flip, rotation and brightness augmentation. The split is 80/20 stratified
over the 6,400 frames. The full thermal set was used, the classifier was trained
and validated on it, and the trained weights are among the released artifacts, so
the perception component reported here is the one the assembled pipeline runs.

**The split, and what it costs.** The sensor-side partitioning discipline was not
carried across to the images. That split is randomized over frames captured
consecutively within a single session, so it is exposed to the same leakage
mechanism the block-wise holdout was built to avoid, and adjacent thermal frames
are close to duplicates. The figure below is an optimistic upper bound rather
than an independent estimate. This leaves the two halves of the pipeline held to
different evidential standards, which is stated in the manuscript's limitations
rather than left to this file. A block-wise re-split of the image set is
outstanding work.

**Results.**

The thermal classifier reached 98.8% top-1 accuracy on 1,280 held-out validation images (**Table S1**). All 15 misclassifications fell on the NoGas and Perfume boundary, so neither hazardous class was confused with a non-hazardous one, which is what matters once the class label is mapped to an action (**Fig. S1**).

| Gas class | Precision | Recall | F1 | Accuracy (%) |
|---|---|---|---|---|
| Mixture | 1.000 | 1.000 | 1.000 | 100.0 |
| NoGas | 0.990 | 0.963 | 0.976 | 96.3 |
| Perfume | 0.972 | 0.991 | 0.981 | 99.1 |
| Smoke | 0.991 | 1.000 | 0.995 | 100.0 |
| Overall | 0.988 | 0.988 | 0.988 | 98.8 |

**Table S1—Perception component, 1,280 held-out validation images.** Obtained under a randomized image split rather than the block-wise protocol used on the sensor side, so read as an optimistic upper bound rather than an independent estimate. These figures are carried over unchanged from the previous version: the thermal classifier is trained outside the sensor pipeline and was not affected by either of the partitioning corrections, and the block-wise re-split of the image set remains outstanding.

![](figures_v2/fig_perception.png)

**Fig. S1—Thermal classifier behavior on 1,280 held-out validation images.** (a) Counts, (b) row-normalized, (c) per-class scores.


---

## S2 Explanation Component

Explanations are generated locally with Gemma 3 1B served through Ollama (Gemma
Team 2025), prompted with the gas class, classification confidence, normalized
anomaly score and threshold, and the selected action, capped at 150 tokens.
Nothing leaves the device.

The component sits off the safety-critical path by construction. The action is
fixed by the decision component before any text is generated, and the generated
text cannot alter it. That separation was deliberate: a fluent explanation
inconsistent with the decision it claims to explain is a hazard in a control room
rather than an aid, and the only structural defense against it is to deny the
generator any influence over the action.

The component is described as part of the system and is evaluated nowhere in this
work. It is not timed, not inspected and not assessed for faithfulness. No result
in the manuscript depends on it, and it should be read as apparatus rather than as
a contribution.

---

## S3 Cost Asymmetry and the Ordinal Objective

The manuscript reports this experiment's conclusions. The sweep, the objective,
the cost matrix and the action-distribution analysis are here.

The loss-weight ratio *C* from Eq. 3 was swept across nine values with everything else fixed (**Table S2**, **Fig. S2**).

| Cost ratio *C* | Decision accuracy | SD | Missed-hazard | Escalation | High-severity FA |
|---|---|---|---|---|---|
| 1:1 (symmetric) | **0.9646** | 0.0252 | 0.0000 | 1.000 | 0.0000 |
| 2:1 | 0.9584 | 0.0317 | 0.0000 | 1.000 | 0.0000 |
| 4:1 | 0.9620 | 0.0292 | 0.0000 | 1.000 | 0.0000 |
| 6:1 | 0.9593 | 0.0310 | 0.0000 | 1.000 | 0.0000 |
| 8:1 (reference) | 0.9630 | 0.0270 | 0.0000 | 1.000 | 0.0000 |
| 10:1 | 0.9631 | 0.0251 | 0.0000 | 1.000 | 0.0000 |
| 12:1 | 0.9573 | 0.0338 | 0.0000 | 1.000 | 0.0000 |
| 16:1 | 0.9241 | 0.0979 | 0.0000 | 1.000 | 0.0000 |
| 20:1 | 0.9090 | 0.0962 | 0.0000 | 1.000 | 0.0000 |
| *Label function* | *1.0000* | *0.0000* | *0.0000* | *1.000* | *0.0000* |

**Table S2—Cost-asymmetry sweep, five seeds per configuration.** The label-function row applies the map of Eq. 2 to the true class label. It reaches the ceiling by construction, consumes the label it is meant to infer, and is not a deployable baseline.

Missed-hazard rate is zero and escalation adequacy is 1.000 at every ratio, the symmetric 1:1 configuration included. Accuracy is highest at 1:1 (0.9646), sits at 0.9630 at the reference 8:1, and falls away past 12:1 to 0.9090 at 20:1, with variance up roughly fourfold. The asymmetry produced no measurable safety benefit at any setting and cost accuracy at the extremes.

The reason looks structural. The target action is a deterministic function of a well-separated class label, and a miss under this definition requires assigning a hazardous window to the class furthest from it in feature space. The miss rate is therefore already on the floor before any weighting is applied. There is nothing for the asymmetry to reshape. That is not evidence against cost-sensitive learning in general, since the literature is clear it works where the error surface is non-trivial (Elkan 2001). What this benchmark shows is narrower: it does not present a sufficiently difficult error surface for a measurable safety benefit from scalar class-level cost weighting to appear.

The reference configuration deserves one more note. *C* = 8:1 is not the accuracy optimum and was originally chosen on test-partition dispersion, which is not a defensible criterion. Re-selecting it needs a validation partition, and the obvious construction fails instructively: a uniformly random validation subset carved from training cannot discriminate between ratios at all, because it inherits exactly the window overlap Experiment 1 measures. Carving the validation band contiguously from the end of each class block instead, with the same embargo, restores discrimination and selects *C* = 6:1 (validation 0.9584, test 0.9397), with 1:1 second at 0.9580 and the reference 8:1 fifth at 0.9551. The reference is not selected under either criterion.

*An ordinal objective, since the evidence points at one.* Eq. 3 prices all wrong actions alike, so under-escalating a hazardous window and over-escalating it cost the same. That is a testable claim, so we tested it. We replaced the sample-weighted cross-entropy with direct minimization of expected cost,

&nbsp;&nbsp;&nbsp;&nbsp;*L*_ord(θ) = (1/*N*) Σₜ Σ_a *p*_θ(*a* | φₜ) · *M*[*g*ₜ, *a*],  ............ (S1)

under a matrix *M* that prices distance and direction along the action ladder. For a hazardous class, silence costs 10, a sub-alarm response 5, and notifying at the wrong tier 1. For clean air, a high-severity alarm costs 4 against 1 for a nuisance action. For the volatile-organic-compound class, silence costs 2 and a high-severity alarm 3. The structure, not the exact values, is what the experiment tests. This is a single untuned matrix, chosen by hand for its shape and run once, offered as a test of a mechanism rather than as a model we are proposing.

It works on the quantity it targets. On the held-out Mixture class the ordinal objective escalates 0.393 ± 0.235 of hazardous windows against 0.245 ± 0.199 for the cost-weighted policy, a relative improvement of about 60% while still recording no observed miss (Table 12 of the manuscript). It is the only change to the objective anywhere in this study that moved escalation adequacy at all. It also costs more than it returns as specified: in-distribution accuracy falls to 0.7472 ± 0.0054, some 21 points below the cost-weighted policy, and expected cost under the matrix the objective itself minimizes rises from 0.0631 to 0.2585. The mechanism is visible in the action distribution, where the model stops emitting *Monitor* for clean air and sends it to *Increase sampling* instead. The matrix prices that error at 1 against 10 for a missed hazard, and the NoGas and Perfume classes overlap precisely where that trade is decided. The result is a system in a permanent state of mildly elevated sampling.

What has been demonstrated is narrow. The mechanism is confirmed: pricing direction along the action ladder moves escalation, where scalar reweighting did not. What has not been demonstrated is a cost matrix worth deploying. A matrix that buys 15 points of escalation on a held-out hazardous class by paying 21 points of accuracy on clean air is not one we would put in front of an operator. A single untuned draw cannot locate the optimum over the space of such matrices. The experiment demonstrates that a directional cost structure can alter escalation behavior. It does not establish an optimal cost matrix, and the row the objective occupies in Tables 9 and 12 should be read as a mechanism result rather than as a deployable policy.

![](figures_v2/fig_costsweep.png)

**Fig. S2—Cost-asymmetry sweep.** Shading is ± 1 SD across five seed-varying partitions.


---

## S4 Confidence Calibration

Confidence matters here because any escalation threshold, and any deferral rule, would be set against it. Four estimators were compared: the raw softmax, MC dropout with 20 passes, temperature scaling, and a five-member deep ensemble built from the same model class and objective as the single model. Temperature is fitted on a calibration split carved out of training, never on the training logits themselves. Expected calibration error uses equal-mass bins because confidence on this corpus piles up near 1 and equal-width bins leave most of the range empty (**Table S3**, **Fig. S3**).

| Estimator | ECE | SD | Bootstrap 95% CI | ECE on hazardous windows | Brier | NLL | Accuracy |
|---|---|---|---|---|---|---|---|
| MC dropout (20) | **0.0185** | 0.0161 | 0.0126 to 0.0286 | 0.0002 | 0.0640 | 0.1185 | 0.9568 |
| Deep ensemble (5) | 0.0219 | 0.0210 | 0.0147 to 0.0320 | 0.0002 | 0.0637 | 0.1226 | 0.9585 |
| Raw softmax | 0.0278 | 0.0226 | 0.0194 to 0.0377 | 0.0001 | 0.0675 | 0.1408 | 0.9578 |
| Temperature scaling | 0.0295 | 0.0222 | 0.0207 to 0.0395 | 0.0000 | 0.0695 | 0.1607 | 0.9578 |

**Table S3—Calibration, five seeds.** ECE with 15 equal-mass bins; intervals from 400 bootstrap resamples per seed.

MC dropout has the lowest point estimate of ECE, but every bootstrap interval overlaps every other, so the four estimators are not separated in this experiment. The lowest point estimate belonged to the deep ensemble before the leakage corrections and to MC dropout after them, which is a further reason not to read an ordering into it. Two observations are more useful than the ordering. First, overall ECE is driven entirely by the non-hazardous classes: restricted to Smoke and Mixture windows every estimator is calibrated to within 0.02%, and temperature scaling to within rounding. The miscalibration lives on the NoGas and Perfume boundary, the same place the perception errors and the anomaly-score overlap live. For a system whose escalation threshold would be set on hazardous-class confidence that is reassuring, and it is invisible in a single pooled ECE number.

Second, temperature scaling made things slightly worse, which is not what the usual account predicts. The fitted temperature is consistently below 1, at 0.787 ± 0.156 across seeds and never above 0.97, meaning the network is under-confident rather than over-confident here, and sharpening an already under-confident distribution moves it away from calibration. We suspect the cost weighting rather than the architecture, but that is a hypothesis not tested in the present study. One methodological point follows with more confidence: temperature must be fitted on a partition the network has not memorized, since fitting it on training logits produces a temperature above 1 and an apparent improvement that does not transfer. The bin sweep in Fig. 19c shows the ordering is stable from 5 to 30 bins.

![](figures_v2/fig_calibration.png)

**Fig. S3—Calibration.** (a) ECE with bootstrap intervals. (b) The same, split into all windows against hazardous windows only. (c) Sensitivity to the number of bins.


---

## S5 Comparator Specifications

Two comparators are not plain supervised classifiers, and the manuscript's
one-line descriptions of them are not enough to reimplement or to judge. Their
full construction is here.

*Conservative Q-learning.* The setting is offline and single-step. The behavior policy is the deterministic target map of Eq. 2, so the behavior action for a window is *a*\*(*g*ₜ) and the offline dataset is exactly the supervised training partition re-read as (*s*, *a*_data, *r*, *s*′) tuples. Coverage is therefore complete over the state space and empty over every non-behavior action, which is the regime the conservative penalty exists for. The reward is the asymmetric reward of Eq. 3's cost structure, with a missed hazard priced at 10 against 1 for a false alarm, and it is a function of (class, action) alone. The discount is γ = 0.99 and the target is a TD(0) bootstrap *r* + γ max\_*a*′ *Q*(*s*′, *a*′), fitted with a smooth L1 loss. The conservative term is the standard CQL(H) penalty, α (logsumexp\_*a* *Q*(*s*, *a*) − *Q*(*s*, *a*_data)) with α = 1.0, which pushes down the value of actions the behavior policy never took. Successor states are the next row in acquisition order within the training partition, and the final row of the partition is masked out because it has no successor. There are no episodes and no terminal states in any meaningful sense: monitoring is a continuing task, each window is one step, and the 0.99 discount over a one-step bootstrap makes the agent close to a myopic cost minimizer. That is what the comparator is, and it is why it tests whether an offline value-based objective beats a cost-weighted supervised one rather than whether reinforcement learning solves monitoring.

*CUSUM.* The statistic is one-sided on the anomaly score, *S*ₜ = max(0, *S*ₜ₋₁ + *x*ₜ − μ₀ − *k*), with μ₀ and σ estimated from the training partition's NoGas windows, a slack of *k* = 0.5σ, and the alarm threshold *h* set at the 99th percentile of the statistic's own path over those training windows. Reset semantics matter for a sequential detector and are stated here rather than left to the code: *S*ₜ is zero at the first window of every evaluation set and is reset to zero at every change of class block, so it is never carried across a block boundary, across the embargo band, or between partitions. Within a block it accumulates normally. An earlier implementation reset only at the start of an evaluation set, which let the block following a hazardous one inherit an already-elevated statistic; the results reported here use the per-block reset.


---

## S6 Reproducing These Results

`make comparison` produces Table S2 and Fig. S2. `make calibration` produces
Table S3 and Fig. S3 together with the perception figures. The verification
script checks every value in this file against the same result files it checks
the manuscript against, so a number here cannot drift from a number there
without the check failing.
