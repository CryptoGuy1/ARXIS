# OnePetro / SPE related work for ARXIS

A sweep of OnePetro for SPE work adjacent to this manuscript, organized by how it bears on the paper rather than by topic.

**How this was gathered, and its limits.** OnePetro's `robots.txt` blocks automated page fetching, so full texts were not read. The SPE Journal Data Science & Engineering Analytics collection listing was read directly in a browser, which is where the exact dates and DOIs below come from. Everything else comes from search result metadata, where volume, issue and first page are read off the OnePetro URL structure (`/SJ/article-abstract/29/03/1540/` is volume 29, issue 3, page 1540) and the year is inferred from the SPE Journal volume sequence.

**Read this as a screening list, not a reference list.** Two things need doing before any of it goes into the manuscript: confirm each record against the publisher page, and read the four Tier 1 papers in full, because the novelty statement in Related Work depends on what they actually measure and I have only seen titles and abstracts. Entries marked **[DSEA-confirmed]** carry a DOI read straight off the collection page and are solid.

---

## Tier 1. Nearest neighbors, and where the novelty claim is decided

These are learned detection or warning systems for safety-relevant events, published in SPE Journal. If the claim that no prior study maps an unfamiliar hazardous condition onto a graded operator-response ladder is going to fail anywhere, it fails here.

| Paper | Venue | Why it matters |
|---|---|---|
| **Autoencoders for Early Kick Detection: Improving Safety in Offshore Oilwell Drilling.** Lima, F. de A.; Copetti, A.; Bertini, L.; de Souza, C. O.; Cardoso, R.; Narcizo, R. B. | SPE Journal, 10 June 2026. `10.2118/231854-PA` **[DSEA-confirmed]** | The single closest paper found. Reconstruction-based anomaly detection for a safety-critical event, framed explicitly around safety, in the exact collection this manuscript targets. Our anomaly component is the same family. **Read first.** It likely establishes what "safety" reporting currently looks like in this venue, which is the gap the paper claims. |
| **Unsupervised Learning–Based Kick Risk Warning with Dynamic Thresholds and Knowledge Embedding** | SPE Journal 30 (11): 6584 (2025) | Dynamic thresholds on an unsupervised warning signal. This is adjacent to Experiment 8's confidence threshold and to the embargoed calibration band. If they set thresholds in-sample, that is a supporting citation for Experiment 1; if off-sample, it is prior art worth acknowledging. **Read second.** |
| **A System to Detect Oilwell Anomalies Using Deep Learning and Decision Diagram Dual Approach** | SPE Journal 29 (03): 1540 (2024) | Detection feeding an explicit decision layer, on the Petrobras 3W benchmark. The closest structural analogue to the perception-to-decision separation, and the nearest thing to an action-level treatment found in SPE. **Read third.** |
| **Development of Oilwell Fault Classifiers Using a Wavelet-Based Multivariable Approach in a Modular Architecture** | SPE Journal 29 (09): 4542 (2024) | Modular fault-classification architecture on multivariable sensor data. Directly comparable in shape to the five-component pipeline, and a precedent for reporting a modular system in SPE Journal. |
| **Leak Detection in Natural Gas Pipelines Based on Unsupervised Reconstruction of Healthy Flow Data.** Liang, J.; Liang, S.; Zhang, H. et al. | SPE Production & Operations 38 (03): 513 (2023) | **Already cited** in the manuscript, as the field-validation support for reconstruction-based anomaly detection. Confirmed present and correctly placed. |

---

## Tier 2. Evaluation practice, which is what this paper is about

The manuscript's contribution is an evaluation methodology, so the useful precedents are papers that criticize or formalize evaluation rather than propose a detector.

| Paper | Venue | Why it matters |
|---|---|---|
| **Review of Stuck Pipe Prediction Methods and Future Directions** | SPE Journal 30 (06): 3334 (2025) | The nearest venue precedent for a paper whose subject is how a class of models is evaluated rather than a new model. Worth reading for how SPE Journal frames a methodology critique, and for whether it names data leakage or split protocol as a problem. If it does, it is a strong citation for Experiment 1. |
| **Enhancing Offshore Drilling Safety: Identification and Integration of Leading Indicators for Loss of Offshore Well Control** | SPE Journal 31 (01): 280 (2026) | Safety indicators selected and integrated for a well-control hazard. The closest SPE Journal work to proposing a metric set for a safety outcome, which is what Table 5 does. |
| **Soft Evidence-Enhanced Object-Oriented Bayesian Network for Process Fault Diagnosis: A Case Study in Oilfield Transfer Station System** | SPE Journal 30 (10): 6294 (2025) | Process fault diagnosis with explicit uncertainty handling, a contrast to the point-estimate practice the paper criticizes. |
| **A Practical Guide to Machine Learning in Petrophysics: Navigating the Chaos** | SPE MEOS 2025 (conference) | A practitioner-facing methodology critique. Likely covers split discipline and overfitting; a supporting citation rather than a competitor. |
| **Machine-Learning for the Prediction of Lost Circulation Events: Time Series Analysis and Model Evaluation** | SPE MEOS 2021 (conference) | Time-series model evaluation in a petroleum setting. Check whether it uses blocked or random splits; either answer is useful to Experiment 1. |
| **Evaluation of Machine Learning Techniques for ESP Diagnosis Using a Synthetic Time Series Dataset** | IPTC 2024 (conference) | Evaluates methods on a synthetic dataset. Relevant precedent for the paper's use of synthetic perturbation, and for how synthetic-data caveats are stated in this literature. |

---

## Tier 3. Alarm behavior and the action level

This is where the eventization work (Tables 14 and 15) and the alarm-burden argument sit. All conference papers, so they support the framing rather than establishing a journal-level precedent.

| Paper | Venue | Why it matters |
|---|---|---|
| **Adaptive Real-Time Machine Learning-Based Alarm System for Influx and Loss Detection** | SPE ATCE 2017 | A learned model whose output is an alarm rather than a class label. Closest prior framing to the action ladder. |
| **Trend Analysis for Calibrated Active System Volume and Differential Flow Significantly Reduces False Positive Kick Alarm During Drilling** | SPE APOG 2024 | Explicitly about false-alarm reduction in a drilling safety context. Supports the alarm-burden motivation with a petroleum-domain example. |
| **Real-time Electrical Submersible Pump Smart Alarms Suite Enabled Through Data Analytics and Edge-based Virtual Flowmeter** | SPE ATCE 2022 | Alarm generation from a learned model at the edge, adjacent to the deployment framing. |
| **Machine Learning Based Operator-…** (SPE-229248-MS) | SPE ADIP 2025 | Operator-facing learned system. Worth checking for how operator load is quantified, if at all. |

---

## Tier 4. Gas and pipeline monitoring in SPE Journal, as venue-fit evidence

None of these is a methodological competitor. They matter because they establish that SPE Journal publishes learned monitoring work on gas and pipeline hazards, which is the argument for the paper's fit.

| Paper | Venue |
|---|---|
| **Oil and Gas Pipeline Intrusion Event Classification Method Based on GhostNet-SE.** Yi, B.; Han, J.; Cao, Z. et al. | SPE Journal 31 (07): 4365 (2026). `10.2118/233764-PA` **[DSEA-confirmed]** |
| **Third-Party Damage Monitoring Technology for Long-Distance Natural Gas Pipelines Based on EEMD** | SPE Journal 30 (09): 5225 (2025) |
| **On the Use of Low-Frequency Distributed Acoustic Sensing Data for In-Well Monitoring and Well Integrity: Qualitative Interpretation** | SPE Journal 28 (03): 1517 (2023) |
| **Detecting Pipeline Leaks Using a Novel Data-Driven Statistical Methodology with Earth Mover's Distance** | SPE ATCE 2025 (conference) |
| **A Deep Learning Model for Leakage Identification in Multiphase Flow Systems** | SPE ATCE 2025 (conference) |
| **Leak Detection in Carbon Sequestration Projects Using Machine Learning Methods: Cranfield Site, Mississippi** | SPE ATCE 2020 (conference) |

---

## Tier 5. The explanation layer

| Paper | Venue | Why it matters |
|---|---|---|
| **Modular Framework Integrating Large Language Models with Drilling Hazard Detection Systems to Provide Operational Context-Informed Interpretations and Recommended Actions** | SPE ATCE 2025 (conference) | Structurally the same arrangement as the reasoning component: a language model placed downstream of a hazard detector, emitting interpretations and recommended actions. Worth reading for whether they put the model upstream or downstream of the action decision, since the manuscript's architectural argument is that it must be downstream. A genuine citation for Supplementary Section S2. |

---

## Tier 6. Generalization and transfer

| Paper | Venue | Why it matters |
|---|---|---|
| **Transfer Learning with Prior Data-Driven Models from Multiple Unconventional Fields** | SPE Journal 28 (05): 2385 (2023) | Generalization across data collected under different conditions. Adjacent to the class-exclusion framing, though the mechanism differs. |
| **Transfer Learning with Recurrent Neural Networks for Long-Term Production Forecasting in Unconventional Reservoirs** | SPE Journal 27 (04): 2425 (2022) | Same, for temporal models. |

---

## What this sweep says about the novelty claim

Nothing found contradicts the Related Work statement. Across the SPE literature the pattern is consistent with what the manuscript already asserts about the gas-recognition literature: detection and classification performance is what gets reported, and where an action or alarm appears it is a binary annunciation rather than a graded ladder with a boundary inside it. No paper found separates passive silence from sub-alarm routing from alarm-grade notification, and none evaluates on a hazardous class withheld from training.

Three qualifications on that.

The claim rests on titles and abstracts. The four Tier 1 papers need reading in full before the Related Work paragraph is final, particularly the kick-risk-warning paper, because dynamic thresholding on an unsupervised signal is close enough to Experiment 8 that its threshold-fitting procedure matters to us either way.

There is a venue-fit argument available that the manuscript does not currently make. The DSEA collection carries learned pipeline-intrusion classification, autoencoder-based kick detection and oilwell anomaly detection, so a reviewer asking why an evaluation-methodology paper belongs in this collection has a ready answer in the collection's own contents.

And the Review of Stuck Pipe Prediction paper is the one to read for positioning rather than for citation. It is the nearest thing in SPE Journal to a paper whose subject is how a field evaluates itself, and how it argues its way into the venue is directly useful.

---

## Suggested additions to Related Work

Four, at most, and each for a stated reason rather than for coverage:

1. **Lima et al. (2026)**, for the sentence about reconstruction-based anomaly detection in safety-critical monitoring, alongside the existing Malhotra and Liang citations. It puts a same-venue, same-year example behind the claim.
2. **The kick-risk-warning paper (SPE J 30 (11))**, in the paragraph about thresholds, if reading confirms where its thresholds are fitted.
3. **The oilwell-anomaly decision-diagram paper (SPE J 29 (03))**, in the paragraph stating that no reviewed study maps an unfamiliar class onto a graded response ladder. Naming the closest case and saying precisely how it differs is stronger than the current unnamed assertion.
4. **The LLM drilling-hazard framework (ATCE 2025)**, in Supplementary Section S2, for the architectural point about keeping the generator downstream of the action.

Adding all four costs roughly 90 words in a section already at its word band, so two of them would have to displace something.
