"""Overlap analysis: shingled n-gram matching against every source on disk.

This is not a plagiarism service. It is an exact-and-near-match detector run
against the texts this manuscript was actually written near: the SPE paper used
as a structural template, and the author's own earlier drafts. Those are where
copied language would plausibly come from, so they are where to look first.
"""
import re, sys, json
from collections import Counter

def norm(t):
    t = re.sub(r"!\[\]\([^)]*\)", " ", t)
    t = re.sub(r"https?://\S+", " ", t)
    t = re.sub(r"[^A-Za-z ]+", " ", t.lower())
    return re.sub(r"\s+", " ", t).strip()

def body_only(t):
    """Drop the reference list: matching citations are not copied prose."""
    for marker in ("## References", "\nReferences\n"):
        if marker in t:
            t = t[:t.index(marker)]
    return t

def shingles(words, n):
    return Counter(tuple(words[i:i+n]) for i in range(len(words) - n + 1))

def compare(name, a_words, b_words, n):
    A, B = shingles(a_words, n), shingles(b_words, n)
    shared = A & B
    tot = sum(A.values())
    hit = sum(shared.values())
    return dict(source=name, n=n, manuscript_ngrams=tot, matching=hit,
                pct=100.0 * hit / max(tot, 1),
                examples=[" ".join(k) for k, _ in shared.most_common(6)])

def longest_common_run(a, b):
    """Longest run of consecutive words appearing in both."""
    bset = set()
    best, bestseq = 0, ""
    for n in range(6, 60):
        S = {tuple(b[i:i+n]) for i in range(len(b) - n + 1)}
        found = None
        for i in range(len(a) - n + 1):
            if tuple(a[i:i+n]) in S:
                found = " ".join(a[i:i+n]); break
        if found is None:
            break
        best, bestseq = n, found
    return best, bestseq

MS = norm(body_only(open("ARXIS_Manuscript_v10_SPE.md").read())).split()
SOURCES = {
    "SPE-219771 (structural template)": norm(body_only(open("model_paper.txt").read())).split(),
    "own earlier draft v9":             norm(body_only(open("ARXIS_Manuscript_v9.md").read())).split(),
    "own earlier draft v5":             norm(body_only(open("ARXIS_Manuscript_v5.md").read())).split(),
    "own earlier draft v3":             norm(body_only(open("ARXIS_Manuscript_v3.md").read())).split(),
}
print(f"manuscript body: {len(MS):,} words\n")
out = []
for name, src in SOURCES.items():
    print(f"=== {name}  ({len(src):,} words) ===")
    for n in (5, 8, 12):
        r = compare(name, MS, src, n)
        out.append(r)
        print(f"  {n:2d}-gram overlap: {r['pct']:6.2f}%  ({r['matching']:,} of {r['manuscript_ngrams']:,})")
    L, seq = longest_common_run(MS, src)
    print(f"  longest shared run: {L} words")
    if L >= 6:
        print(f"    \"{seq[:150]}\"")
    ex = compare(name, MS, src, 8)["examples"]
    if ex:
        print("  sample 8-gram matches:")
        for e in ex[:4]:
            print(f"    \"{e}\"")
    print()
json.dump(out, open("textcheck_overlap.json", "w"), indent=1)
