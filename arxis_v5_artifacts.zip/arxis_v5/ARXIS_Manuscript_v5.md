# Zero Missed Hazards Is Not a Safety Claim: Evaluating Machine-Learning Gas-Hazard Monitoring Beyond Accuracy

**Benjamin C. Nweke**^a,b,\*, **Gholamreza Ramezan**^b, **Soheil Saraji**^a

^a Subsurface Energy and Digital Innovation Center (SEDI), Department of Energy and Petroleum Engineering, University of Wyoming, 1000 E. University Ave., Laramie, WY 82071, USA
^b Fides Innova Labs, Vancouver, BC, Canada

\* Corresponding author: bnweke@uwyo.edu

*Prepared for submission to SPE Journal, Data Science and Engineering Analytics.*

*Suggested running head:* Zero Missed Hazards Is Not a Safety Claim

> **Note on this version.** Every number in Sections 4.1 through 4.7 comes from a complete
> re-execution of the experiment programme, run on a corrected data pipeline: windows that
> straddle a class boundary are discarded, all scaling is fitted on the training partition
> only, and the position of the held-out block moves with the run seed. These results replace
> the earlier draft's tables rather than supplementing them. Section 4.8 (edge hardware) and
> the perception figures in Section 4.1 could not be re-run, and we say so where they appear.

---

## Summary

A fixed gas detector at a wellpad or a compressor station will generate far more abnormal indications in a week than anyone can act on. That is the practical problem. Knowing which gas is present matters less than knowing what to do about it, and the evidence available at the moment of decision is usually partial, sometimes stale, and occasionally wrong. Machine-learning work on gas detection is nevertheless ranked almost entirely by classification accuracy, which says nothing about the two quantities that decide whether a monitoring system is safe to install: how often a hazard draws no response at all, and how often clean air draws a high-severity one.

We evaluated an edge-deployable monitoring pipeline (thermal-image classification, normal-only anomaly scoring, cost-sensitive action assignment, and a locally generated natural-language explanation) against a broader metric set. The benchmark is the public MultimodalGasData corpus (Narkhede et al. 2022), split by a leakage-controlled block-wise holdout with a 20-window embargo. One caveat needs stating up front: the corpus contains incense smoke, alcohol-based vapor and a mixture of the two, not hydrocarbons. What follows characterizes evaluation methodology on a representative metal-oxide array. It is not a field performance estimate, and we would resist anyone reading it as one.

Eleven models were trained under a single protocol: tree ensembles, kernel methods, feedforward and recurrent networks, offline reinforcement learning, a depth-3 threshold rule, and classical sequential change detection. Four things came out of it.

In distribution, the metric set does not separate anything. Ten multiclass models sit inside 4.7 accuracy points of one another (0.930 to 0.977), a spread this design cannot resolve, and every one of them except gradient boosting records zero missed hazards, escalation adequacy of 1.000, and zero high-severity false alarms. A three-level decision tree on seven raw sensor readings matches all of them on safety behavior.

Hold one hazardous class out of training, though, and the same models spread across two orders of magnitude. A multilayer perceptron missed 9.49% of unseen Smoke windows (95% Clopper-Pearson upper bound 10.05%) where four other models were bounded at 0.038%. Nothing in the in-distribution table anticipates that, and the correlation between in-distribution accuracy and out-of-distribution miss rate is essentially absent (Pearson r = +0.12).

The more uncomfortable finding concerns the miss metric itself. On unseen Mixture, seven of eight models were bounded below 2.9% on missed hazards and would pass any review conducted on that basis. Their escalation adequacy ranged from 0.5% to 100%, a factor of about 198. A support-vector classifier missed 0.03% of hazardous windows while escalating 0.5% of them, answering roughly 99.5% with "increase sampling" or "request verification." No operator is notified by either action, and the miss metric scores the whole thing as success.

Cost asymmetry, swept from 1:1 to 20:1, changed neither missed-hazard rate (zero throughout) nor escalation adequacy (1.000 throughout), and cost accuracy above 6:1. On a benchmark this separable there appears to be no error surface for a safety objective to reshape.

Under graded sensor loss three distinct failure modes appear, and each single metric certifies a different model as safe. With all seven channels removed, the cost-weighted policy and the threshold rule hold zero misses and full escalation by alarming on everything, reaching a 100% false-alarm rate, which at the 0.5 Hz sampling cadence works out to 1,800 alarms per hour from one detector. Gradient boosting holds zero false alarms and misses 60% of hazards. Losing a single sensor of seven is already enough to take the cost-weighted policy from zero to about 211 alarms per hour while leaving the random forest untouched.

Our conclusion is narrower than a claim about any particular model. Missed-hazard rate with a confidence bound, escalation adequacy, false-alarm burden expressed in alarm-management units, and the degradation of all three under sensor loss and drift should be reported together, because on this corpus each of them taken alone picks a different winner.

**Keywords:** gas-hazard monitoring; safety-relevant evaluation; cost-sensitive learning; distribution shift; alarm management; edge deployment; anomaly detection; explainable AI

---

## 1. Introduction

Serious process-safety incidents are rarely preceded by silence. The warning is usually there, spread across several indications, and simply never converted into action in time. In the eleven minutes before the Milford Haven refinery explosion the control-room operator received 275 alarms (Goel et al. 2017). Sensing was not the failure. Turning what was sensed into a decision was.

The same shape of problem shows up at upstream and midstream facilities. Wellpads, tank batteries, compressor stations and gas plants carry fixed point-gas detectors, often low-cost metal-oxide-semiconductor (MOX) elements, feeding alarm systems that in a good many installations already run at or above the long-term average rates industry guidance treats as manageable for a single operator (EEMUA 2013; ISA 2016). Add to that the growing obligation to find and act on fugitive hydrocarbon release, where the response is at once a safety action and an emissions action. In both settings the operational question is not really "what gas is this." It is closer to "what should be done in the next minute, and how sure do we need to be before doing it."

Machine learning has been applied heavily to the first question and hardly at all to the second. Gas-detection models get ranked by classification accuracy, and on the established benchmarks that ranking has flattened out: reported accuracies on the corpus used here run from roughly 93% to 99.7% across more than ten peer-reviewed studies (Narkhede et al. 2021; Faleh and Kachouri 2023; El Barkani et al. 2024; Sharma et al. 2024; Zhang and Zhang 2025). Once a benchmark saturates, small differences between leading methods stop carrying information about deployment. The interesting question becomes what the accuracy number is failing to see.

### 1.1 A symmetric metric on an asymmetric problem

Monitoring errors are not interchangeable, and no single scalar orders them sensibly:

- A hazardous condition that draws no response gives up the whole intervention window.
- A hazardous condition that draws a sub-alarm response, say increased sampling or a request for verification, keeps part of that window but notifies nobody. It is not the same as a correct escalation, although a miss metric will treat it as though it were.
- A clean condition that draws a high-severity response spends operator attention, and at sufficient rate it degrades the alarm system that later hazards depend on (Laberge et al. 2014).
- A hazardous condition that draws the wrong high-severity response is, in most operating regimes, almost as good as the right one.

A model ranked first on accuracy can be ranked last on any of these, and the accuracy table gives no hint of which. We had assumed going in that the differences would be modest. They were not.

### 1.2 What is settled and what is not

Most of the component technology is mature. Reconstruction-based sequence models trained only on normal operation have been the default unsupervised approach to multivariate sensor anomaly detection since Malhotra et al. (2016), with field-validated applications in natural-gas pipeline monitoring (Liang et al. 2024). Vision models classify thermal and optical gas signatures fast enough for embedded hardware (Korjani et al. 2024; Jocher et al. 2023). Cost-sensitive learning has a clean formal account of unequal error costs (Elkan 2001). Fusing thermal imagery with MOX arrays improves classification relative to either alone (Narkhede et al. 2021, 2022). Compact language models make local explanation feasible without sending monitoring data off site (Dehnaw et al. 2024).

What is not settled is how any of this behaves when ranked by something other than accuracy. Four questions in particular:

1. Does accuracy-ranked model selection survive a missed-hazard criterion?
2. Do models that agree in distribution still agree when the hazard is one they were never trained on? That matters, because a detector in service will eventually meet a release it has not seen.
3. Is missed-hazard rate itself enough, or can it be satisfied by under-response that a miss count never registers?
4. Do any of these behaviors survive the arithmetic, memory and thermal limits of the cheap hardware these systems actually run on?

### 1.3 What we contribute

**An evaluation protocol.** A leakage-controlled block-wise holdout with an explicit embargo and a seed-varying block position; a five-level action target that keeps missed hazard, under-escalation and high-severity false alarm apart; leave-one-class-out (LOCO) evaluation against an unseen hazard; a graded perturbation suite covering additive noise, calibration drift and channel loss at five to seven severities; and Clopper-Pearson bounds on every zero count. As far as we can tell this combination has not been applied to a MOX gas-detection benchmark before.

**Evidence that accuracy ranking says little about safety behavior.** Ten multiclass models spanning very different inductive biases span 4.7 accuracy points in distribution, are indistinguishable there on every safety metric we report, and then separate by more than two orders of magnitude on missed-hazard rate once the hazard is unseen.

**Evidence that missed-hazard rate is necessary but not sufficient.** On an unseen hazardous class, models with miss rates bounded below 2.9% differ by roughly 198 times in escalation adequacy, and the group with the lowest miss rates contains both the best and among the worst escalators.

**Two negative results, reported rather than buried.** Cost asymmetry produced no measurable change in missed-hazard rate or escalation adequacy at any ratio from 1:1 to 20:1, and hurt accuracy past 6:1. Separately, a deterministic label-function reference hits the accuracy ceiling by construction, which means any benefit from a learned policy on this corpus has to come from degraded conditions rather than nominal ones.

**Comparators a facility would recognize.** A depth-3 decision tree on seven raw sensor channels and a CUSUM sequential detector run under the identical protocol, so the learned models are measured against something closer to current practice than to another neural network.

We are not claiming to advance the classification state of the art here, and we are not convinced that would be worth doing. The benchmark is saturated. What remains open is what the saturated numbers miss.

---

## 2. Background and Related Work

### 2.1 Detection, and the gap between an indication and a decision

Gas-hazard detection rests on a well-developed base of hardware and software methods (Murvay and Silea 2012; Adegboye et al. 2019). On the hardware side, distributed acoustic and fiber-optic sensing, vapor sensing and negative-pressure-wave detection. On the software side, real-time transient modeling, mass balance, statistical analysis and model-based diagnostics (Zhang et al. 2013; Bustnes et al. 2011). These have improved identification and localization considerably, and their weak spot is usually uneven performance under real operating conditions rather than any absence of capability (Han and Kim 2014).

For our argument a different limitation matters more. All of them stop at a leak indication, a location estimate or a concentration estimate. Those outputs are necessary for loss prevention, but they are not response decisions, and the literature evaluating them does not ask whether the downstream response would have been adequate.

### 2.2 Anomaly scores as evidence, not verdicts

Since Malhotra et al. (2016), reconstruction-based sequence models trained only on normal operation have been the standard unsupervised route to multivariate sensor anomaly detection, and they have been used in pipeline monitoring with field validation (Liang et al. 2024). Their appeal for safety work is obvious: no labeled examples of every hazardous condition are needed.

An anomaly score is still an intermediate quantity, though. It says behavior has departed from baseline. It does not say what to do, and nothing about the training procedure calibrates it to hazard severity. Any use of such a score inside a safety path carries an obligation to show that it ranks hazard monotonically, and the literature rarely discharges that obligation. We test it directly in Section 4.1, and the answer is only a partial yes.

### 2.3 A saturated benchmark

MultimodalGasData pairs thermal frames with a seven-channel MOX array, and the original work showed that fusing the two beats either alone (Narkhede et al. 2021, 2022). It has since become a standard benchmark, and the reported accuracies have converged: 97.0% (Narkhede et al. 2021), 93.0% (Faleh and Kachouri 2023), 91.7% (El Barkani et al. 2024), 99.7% (Sharma et al. 2024), 99.7% (Zhang and Zhang 2025).

Two features of that literature bear on what follows. First, those figures appear to be computed on random splits over overlapping sliding windows drawn from a single recording session. Dennler et al. (2022) showed on a similarly structured MOX corpus that this conflates recording time with class identity, and flagged a sizeable body of published work for re-evaluation; Vergara et al. (2012) had already documented how far MOX response drifts over long horizons. Second, and more to the point, none of these studies reports a safety-relevant quantity. Not missed-hazard rate, not escalation adequacy, not false-alarm burden, not behavior under sensor loss. The benchmark has saturated on a metric that does not discriminate deployment fitness.

### 2.4 Cost-sensitive learning

That error costs are unequal, and that classifiers ought to be trained accordingly, has had a clean formal treatment since Elkan (2001), and cost-sensitive reweighting is now routine practice. What gets reported far less often is whether a given asymmetry actually moved the specific error it was introduced to suppress. Section 4.4 runs that test and returns a negative answer, one we suspect generalizes to any saturated, well-separated benchmark.

### 2.5 Coordination layers and operator-facing explanation

Systems that coordinate several specialized models toward a larger task have been applied in the energy sector to well-construction assistance, completions optimization and enterprise modeling (Sabbagh et al. 2024; Santiago et al. 2025; Jessen and Roshchin 2025). Those are analytical and advisory settings rather than real-time monitoring, and their evaluation criteria differ accordingly.

Explanation matters for operator-facing safety systems because trust, review and post-incident accountability all depend on it. It also brings a hazard of its own. A language model can produce an explanation that reads fluently and does not match the decision it claims to explain, which in a control room is worse than offering nothing. Our response to that is architectural, and we describe it in Section 3.3.

### 2.6 Where this study sits

**Table 1** lists representative prior work with the evaluation gap each leaves open.

| Study | Area | Contribution | Evaluation gap addressed here |
|---|---|---|---|
| Malhotra et al. (2016) | Anomaly detection | Reconstruction-error scoring for multivariate streams | Score not calibrated to hazard severity; no response mapping |
| Liang et al. (2024) | Anomaly detection | Field-validated normal-only leak detection | Stops at detection; downstream response unevaluated |
| Korjani et al. (2024) | Computer vision | High detection rates on optical gas imaging | Degraded-sensing behavior not treated as a safety metric |
| Narkhede et al. (2021, 2022) | Multimodal sensing | Thermal and MOX fusion improves classification; public corpus | Classification accuracy only; random split over overlapping windows |
| Sharma et al. (2024); Zhang and Zhang (2025) | Multimodal classification | State-of-the-art accuracy on this corpus | No missed-hazard, escalation, false-alarm or degradation reporting |
| Dennler et al. (2022) | Benchmark methodology | Shows drift-induced leakage in MOX benchmarks | Motivates, but does not supply, a safety-relevant metric set |
| Elkan (2001) | Cost-sensitive learning | Formal account of unequal error costs | Effectiveness on a saturated benchmark untested |
| Sabbagh et al. (2024) | Multi-agent systems | Coordination improves answer quality | Analytical workflow, not real-time monitoring |

**Table 1. Representative prior work and the evaluation gap each leaves open.**

Our contribution lives in that right-hand column. It is not a new architecture. It is evidence about what the usual evaluation of these architectures fails to reveal.

---

## 3. Methodology

### 3.1 Corpus and preprocessing

The public MultimodalGasData corpus (Narkhede et al. 2022; Mendeley Data, CC BY 4.0) pairs a seven-channel MQ-series MOX array with synchronized 206 by 156 thermal frames from a Seek Compact camera. There are 6,400 labeled samples in four classes of 1,600: clean air (NoGas), incense smoke (Smoke), alcohol-based deodorant vapor (Perfume), and a smoke and vapor mixture (Mixture). **Table 2** lists the array.

| Sensor | Primary detection target |
|---|---|
| MQ-2 | LPG, butane, methane, smoke |
| MQ-3 | Alcohol, ethanol, vapors |
| MQ-5 | LPG, natural gas |
| MQ-6 | LPG, butane, iso-butane |
| MQ-7 | Carbon monoxide |
| MQ-8 | Hydrogen |
| MQ-135 | Air-quality indicators (NH₃, benzene, NOₓ, CO₂) |

**Table 2. MQ sensor array composition and primary detection targets.**

Two properties of the corpus shaped everything downstream, and we would rather state them here than tuck them into a limitations section.

The analytes are laboratory surrogates. Incense smoke and alcohol-based vapor exercise the MOX transduction mechanism, the cross-sensitivity structure of the array, and its baseline drift, all of which a facility detector meets in service. They do not establish detection performance for methane or anything heavier. Every result below characterizes evaluation methodology on a representative MOX array.

The four classes were recorded as four contiguous blocks inside a single session of roughly 90 minutes. Within-session baseline drift is therefore confounded with class identity, which is exactly the structure Dennler et al. (2022) showed inflates reported accuracy on MOX benchmarks under a randomized split. The split we use is a response to that, not a housekeeping choice.

**Windowing.** Seven-channel readings were formed into sliding windows of length 20, each labeled by its final reading. Windows spanning a class boundary are discarded, so no window mixes two classes. That leaves **6,324 windows, 1,581 per class**.

**Split.** Consecutive windows share 19 of 20 raw rows, so a random split drops near-duplicates into both partitions. A plain sequential split is no better, because the corpus is block-ordered by class. We use a block-wise holdout instead: inside each class block a contiguous 20% forms the test partition, separated from the training segments by an embargo of *G* = 20 windows, so no training window shares a raw row with any test window (Fig. 1). The position of the held-out block moves with the run seed, which means the dispersion we report includes data-partition variance and not just model-initialization variance (Bouthillier et al. 2021). The result is **4,980 training and 1,264 test windows, 316 per class**. Feature scaling and anomaly normalization are fitted on the training partition only, then applied without refitting.

![](figures_v2/fig_protocol.png)

**Fig. 1. Corpus layout and the leakage-controlled split.** Each class occupies a contiguous block of 1,581 windows. A contiguous 20% is held out, with a 20-window embargo on each side, and the position of that block is drawn from the run seed.

### 3.2 The monitoring pipeline

The pipeline, which we call ARXIS, has five parts. At each inference cycle it takes a thermal image *I*ₜ and a sensor window **X**ₜ ∈ ℝ^(20×7) and returns a safety action *a*ₜ ∈ {0, …, 4} plus an explanation *E*ₜ. A **perception** component classifies the thermal image. An **anomaly** component scores the sensor window by reconstruction error against a normal-only model. A **coordination** component assembles the decision state. A **decision** component maps that state to an action. A **reasoning** component writes the operator-facing explanation.

The pipeline is advisory, and we want to be explicit about that. It sits in the alarm-management and operator-support layer and does not actuate anything. The action labeled *Emergency Shutdown* is a recommendation that the operator start the facility's existing ESD procedure. It does not command a trip. The safety instrumented function stays independent, deterministic and separately verified, which keeps the arrangement consistent with the independence requirement of layer-of-protection analysis and with the fact that no established certification pathway exists for a learned component inside a safety instrumented function under IEC 61511 (IEC 2016). All results below were obtained with the pipeline in that position, and removing it entirely leaves the facility's protective function intact. We treat this as a design requirement rather than a caveat. A single learned component selecting across both the alarm layer and the shutdown layer would collapse two protection layers into one common-cause element, and we do not see a defensible way around that.

![](figures_v2/fig_architecture.png)

**Fig. 2. The pipeline.** Thermal evidence reaches the perception and explanation paths but never the decision state, and the language model sits downstream of an action it cannot alter.

| Action | Label | Operational response |
|---|---|---|
| 0 | Monitor | Routine monitoring, no operator notification |
| 1 | Increase sampling | Elevated scan frequency and event logging |
| 2 | Request verification | Operator notification and secondary sensor check |
| 3 | Raise alarm | Automated alarm, incident logging, field dispatch |
| 4 | Emergency shutdown | Recommend initiating the facility ESD procedure |

**Table 3. Safety-action space.** Actions 3 and 4 are alarm-grade: they put a notification in front of an operator. Actions 1 and 2 do not.

### 3.3 Component models

**Perception.** Thermal images are classified with YOLOv8n-cls (Jocher et al. 2023), picked for its speed and footprint on embedded hardware: images resized to 224 by 224, pretrained initialization, AdamW at 10⁻³ with cosine annealing, weight decay 10⁻⁴, batch size 32, 50 epochs, with random flip, rotation and brightness augmentation, on an 80/20 stratified split of the 6,400 frames. That split is randomized over frames captured consecutively within a single session, so it is exposed to the same leakage mechanism the sensor-side holdout was built to avoid. Adjacent thermal frames are close to duplicates. Treat the perception accuracy below as an optimistic upper bound, then, rather than a performance estimate. The image corpus was not available when this revision was prepared, so the split could not be corrected (Appendix A).

**Anomaly detection.** An LSTM autoencoder with a single-layer encoder and decoder, hidden dimension 32 and a linear output, trained on NoGas windows only, following Malhotra et al. (2016). The mean reconstruction error over the full 20-step window is the anomaly score. The threshold τ is the 95th percentile of reconstruction error on NoGas training windows only, and evaluation is on held-out windows (Section 4.1). That distinction turns out to matter a great deal.

**Coordination.** The 22-dimensional decision state is

&nbsp;&nbsp;&nbsp;&nbsp;φₜ = [ ρ̃ₜ , **X**ₜ[−1,:] , **δ**ₜ , **σ**ₜ ] ∈ ℝ²² .................................................(1)

with ρ̃ₜ the normalized anomaly score, **X**ₜ[−1,:] the current seven-channel reading, **δ**ₜ the per-sensor change across the window, and **σ**ₜ the per-sensor standard deviation. There is no visual term in the state. Thermal evidence feeds the perception and explanation paths, not the action.

**Decision.** A feedforward network with a dueling value and advantage head (Wang et al. 2016), mapping φₜ to five action scores, trained by cost-weighted cross-entropy. Not by reinforcement learning, despite the architecture's provenance. Target actions come from a deterministic map *a*\*(·) from class to acceptable action set: NoGas to {0}, Smoke to {3}, Mixture to {4}, Perfume to {1, 2}. Each sample carries a loss weight *w*(*g*ₜ) equal to *c*_miss for hazardous classes and *c*_false otherwise, with *C* = *c*_miss / *c*_false. The objective is

&nbsp;&nbsp;&nbsp;&nbsp;*L*(θ) = − (1/*N*) Σₜ *w*(*g*ₜ) · log *p*_θ( *a*\*(*g*ₜ) | φₜ ) ..................................(2)

where *p*_θ is the softmax over action scores. The deployed configuration uses *C* = 8:1, and Section 4.4 sweeps the rest.

Two consequences of Eq. 2 bound what can honestly be claimed from any of this, and a reader will derive them anyway, so we may as well.

The target action is a deterministic function of the class label. Decision accuracy comes out as four-class classification accuracy composed with a fixed map, not a separate quantity measured on a separate task. What differs between the "decision" framing and the "classification" framing is the error metric, not the task, and the error metric is what this paper is about.

A rule that applies *a*\*(·) to the true label reaches 100% decision accuracy by construction. Such a rule consumes the very label it is supposed to infer, so it is not deployable. Where it appears below we call it a label-function reference, never a baseline. The deployable version of the same idea is the depth-3 threshold rule described next.

**Reasoning.** Explanations are generated locally with Gemma 3 1B served through Ollama (Google DeepMind 2025), prompted with the gas class, classification confidence, normalized anomaly score and threshold, and the selected action, capped at 150 tokens. Nothing leaves the device. The explanation is advisory and sits off the safety-critical path: the action is fixed by the decision component and the generated text cannot change it. That separation was deliberate, on the reasoning that a fluent explanation inconsistent with the decision is a hazard in a control room rather than an aid. As it happens, Section 4.8 shows the latency arithmetic forbids putting a language model in the decision path anyway. The safety argument and the timing budget landed in the same place, which was convenient but not planned.

### 3.4 Comparators

Eleven models, one protocol. The cost-weighted policy of Eq. 2; an unweighted network of identical topology; a multilayer perceptron (256-256-128); cost-sensitive gradient boosting (300 trees); an RBF support-vector classifier; a random forest (300 trees); a recurrent network over K = 10 consecutive states; conservative Q-learning with a TD(0) bootstrap and a conservative penalty on non-behavior actions; k-nearest neighbours with k = 5; a threshold rule, meaning a depth-3 decision tree restricted to the seven raw current-sensor channels, which is interpretable, deployable and about as close to current practice as we could make it; and CUSUM (Page 1954), a one-sided cumulative-sum detector on the anomaly score, with μ₀ and σ estimated from NoGas training windows and the decision threshold set on the training partition. CUSUM is two-class by construction and cannot separate Smoke from Mixture, so its decision accuracy is not comparable with the rest. Its missed-hazard rate and escalation adequacy are.

### 3.5 The metric set

Five quantities rather than one. This set is the methodological proposal.

**Decision accuracy.** The share of test windows assigned an action in *a*\*(*g*ₜ). Reported for continuity with prior work, not as a safety metric.

**Missed-hazard rate.** This is the share of hazardous windows, Smoke and Mixture together, assigned the passive *Monitor* action. Only *a* = 0 counts. Assigning a hazardous window to *Raise Alarm* when *Emergency Shutdown* was the target is not a miss, because an operator still gets notified. The limitation is that assigning a hazardous window to *Increase Sampling* or *Request Verification* is also not a miss, even though nobody is notified. Section 4.3 shows that this is not an academic worry, which is why the next metric exists.

**Escalation adequacy.** Here we count the share of hazardous windows assigned an alarm-grade action (*a* ≥ 3), which is what decides whether an operator hears about the hazard. We also report under-escalation, the share receiving *a* ∈ {1, 2}.

**High-severity false-alarm rate.** The share of clean windows that gets assigned *a* ≥ 3. Worth noting that the project's original evaluation code divided false alarms by the number of alerts rather than the number of clean windows; the two agree only at zero, which is why the discrepancy went unnoticed. Everything here uses the per-clean-window definition, and Section 4.7 converts it into alarm burden per hour, since a bare rate is not comparable with the envelopes an operator actually works inside (EEMUA 2013; ISA 2016).

**Bounds on every zero.** An observed zero is not a demonstrated zero. All zero-count claims carry a one-sided 95% Clopper-Pearson upper bound (Clopper and Pearson 1934). Pooled across five seeds this study sees 3,160 hazardous and 1,580 clean test windows, so a zero supports "at most 0.095%" and "at most 0.189%" respectively. Getting below 10⁻³ would need something like 2,995 consecutive zero-miss observations, which puts the usual "0.0000" in a table into perspective.

### 3.6 Protocol and statistics

Five seeds (42, 1337, 7, 2024, 99), each with its own block position, determinism guards on, single-threaded execution.

One constraint deserves emphasis because it is easy to trip over. With *n* = 5 paired seeds the two-sided Wilcoxon signed-rank test has a minimum attainable *p*-value of 2^(1−n) = 0.0625. No comparison in this design can reach α = 0.05 at any effect size whatsoever. We assert no significance-based ranking as a result, and would ask readers not to infer one. Paired *p*-values appear in the tables for completeness, with that constraint stated beside them. Getting to a properly powered comparison would take many more randomized runs varying seed, split, augmentation and hyperparameter draw, together with an equivalence analysis over a region of practical equivalence (Benavoli et al. 2017; Bouthillier et al. 2021). We flag it as work still to do rather than pretending otherwise.

### 3.7 Edge deployment setup

The edge study asks whether the decision path fits a practical sampling interval on modest industrial-IoT hardware. It is a benchmark replay on edge hardware, not a live field deployment, and we would not want it read as one. The platform is a Raspberry Pi 4 Model B (Cortex-A72, 8 GB RAM) on 64-bit Raspberry Pi OS Bookworm, with Python 3.11, PyTorch 2.3 CPU, ONNX Runtime 1.18 and Ultralytics YOLOv8 8.2. The reasoning component runs locally through Ollama with a 4-bit-quantized Gemma 3 1B model. The test partition streams from local storage at 0.5 Hz, a 2,000 ms sampling interval, inside which the deployable decision path has to finish.

---

## 4. Results

### 4.1 Component behavior

**Perception.** The thermal classifier reached 98.8% top-1 accuracy on 1,280 held-out validation images at 0.78 ms mean inference latency (**Table 4**), with perfect recall for Smoke and Mixture. The 15 misclassifications all sat on the NoGas and Perfume boundary.

| Gas class | Precision | Recall | F1 | Accuracy (%) |
|---|---|---|---|---|
| Mixture | 1.000 | 1.000 | 1.000 | 100.0 |
| NoGas | 0.990 | 0.963 | 0.976 | 96.3 |
| Perfume | 0.972 | 0.991 | 0.981 | 99.1 |
| Smoke | 0.991 | 1.000 | 0.995 | 100.0 |
| Overall | 0.988 | 0.988 | 0.988 | 98.8 |

**Table 4. Perception component, 1,280 held-out validation images.** Obtained under a randomized image split (Section 3.3), so read as an optimistic upper bound.

![](figures_v2/fig_perception.png)

**Fig. 3. Perception behavior, replotted from the reported results.** Every error sits on the NoGas and Perfume boundary. Neither hazardous class is ever confused with a non-hazardous one, which is the part that matters for the action mapping.

**Anomaly detection.** Two questions were open here, and both had been left unanswered in the earlier draft.

*Does the score track hazard?* Mean reconstruction error by class comes out at NoGas 0.736, Perfume 1.543, Mixture 117.72 and Smoke 229.25 (Fig. 2a). Hazardous conditions separate from benign ones by two orders of magnitude, so the score is usable as a hazard indicator. It is not monotone in target severity, though: Mixture carries the higher target action, *Emergency Shutdown*, yet scores well below Smoke. The score is best read as evidence of abnormality rather than as a severity estimate, and no result in this paper leans on it being the latter.

*Was the published operating point out of sample?* Apparently not. Recomputing the threshold as the 95th percentile of all NoGas windows and evaluating on those same windows reproduces AUC 0.962 at exactly 5.000% false-positive rate, which is the nominal value a 95th-percentile threshold returns on the sample that defined it. Fit τ on NoGas training windows only and evaluate on held-out windows and the picture changes: **ROC-AUC 0.9928 ± 0.0053, TPR 0.7363 ± 0.0949, FPR 0.0000 ± 0.0000** across five seeds (Fig. 2b). Discrimination and false positives both improve, sensitivity drops by about seven points. The corrected numbers are the ones to use.

![](figures_v2/fig_anomaly.png)

**Fig. 4. Anomaly component.** (a) Mean reconstruction error by class, log scale. (b) Operating point with the threshold fitted on its own sample, against the threshold fitted on training windows and evaluated on held-out windows.

![](figures_v2/fig_roc.png)

**Fig. 5. Anomaly detector in detail.** (a) ROC curves, one per seed for the held-out evaluation, against the in-sample curve, with both operating points marked. (b) Score distributions by class on a log axis. The gap between the benign pair and the hazardous pair is close to two decades, while NoGas and Perfume overlap substantially, which is where the residual errors come from.

### 4.2 In distribution, eleven models look identical

All models trained on the same partition with the same five seeds, evaluated on the same holdout (**Table 5**, Fig. 3).

| Model | Decision accuracy | SD | Missed-hazard | 95% CP bound | Escalation | High-severity FA | Wilcoxon *p* vs. cost-weighted |
|---|---|---|---|---|---|---|---|
| Random forest | **0.9769** | **0.0086** | 0.0000 | ≤ 0.095% | 1.000 | 0.0000 | 0.1875 |
| Recurrent (LSTM) | 0.9680 | 0.0231 | 0.0000 | ≤ 0.095% | 1.000 | 0.0000 | 0.8125 |
| Gradient boosting | 0.9634 | 0.0211 | 0.0098 | ≤ 1.322% | 0.990 | 0.0000 | 1.0000 |
| **Cost-weighted policy** | 0.9623 | 0.0214 | 0.0000 | ≤ 0.095% | 1.000 | 0.0000 | reference |
| Multilayer perceptron | 0.9612 | 0.0110 | 0.0000 | ≤ 0.095% | 1.000 | 0.0000 | 0.8125 |
| Unweighted network | 0.9562 | 0.0386 | 0.0000 | ≤ 0.095% | 1.000 | 0.0000 | 1.0000 |
| k-nearest neighbours | 0.9521 | 0.0295 | 0.0000 | ≤ 0.095% | 1.000 | 0.0000 | 0.1250 |
| Support vector classifier | 0.9511 | 0.0190 | 0.0000 | ≤ 0.095% | 1.000 | 0.0000 | 0.4375 |
| Conservative Q-learning | 0.9438 | 0.0485 | 0.0000 | ≤ 0.095% | 1.000 | 0.0000 | 0.3750 |
| **Threshold rule** (depth-3) | 0.9297 | 0.0295 | 0.0000 | ≤ 0.095% | 1.000 | 0.0000 | 0.1875 |
| CUSUM (two-class) | 0.4994\* | 0.0004 | 0.0013 | ≤ 0.289% | 0.999 | 0.0000 | 0.0625 |

**Table 5. Model comparison on the block-wise holdout, five seed-varying partitions.** Pooled *n* = 3,160 hazardous and 1,580 clean test windows. \*CUSUM emits only actions 0 and 3, so its decision accuracy is not comparable; its safety columns are. The minimum attainable two-sided *p* at *n* = 5 is 0.0625, so nothing in the last column can reach α = 0.05.

Three things stand out.

The ten multiclass models span 4.7 accuracy points, from 0.9297 to 0.9769. Highest point accuracy and lowest variance belong to the random forest. The cost-weighted policy sits fourth. What we did not expect is that the depth-3 threshold rule on seven raw sensor channels lands only 3.3 points behind the best learned model and within one standard deviation of four of them.

More striking, the safety metrics do not discriminate at all in distribution. Ten of eleven models record exactly zero missed hazards, escalation adequacy of 1.000, and zero high-severity false alarms. Gradient boosting is the lone exception at 0.0098. Taken at face value, a facility could install a three-level decision tree and see identical safety behavior to any deep model we tested, which is not the conclusion we set out to reach.

And no ranking is asserted, because the design cannot support one. The smallest observed *p* is 0.0625 (CUSUM), which is the minimum attainable value rather than evidence of anything. What Table 5 supports is the weaker statement that these models are not distinguishable in distribution. That happens to be the premise for everything after it.

![](figures_v2/fig_zoo.png)

**Fig. 6. Decision accuracy on the block-wise holdout,** mean ± SD across five seed-varying partitions. The shaded band spans the full range of model means.

Looking at where the actions actually land (Fig. 7) makes the saturation concrete. Every model sends essentially all Smoke windows to *Raise Alarm* and all Mixture windows to *Emergency Shutdown*, and the only visible spread is on the NoGas and Perfume boundary, where models split between *Monitor* and *Increase sampling* in slightly different proportions.

One detail there deserves a mention, since it is a property of the action space rather than of any model. **Action 2, *Request Verification*, is never selected by any model, on any seed.** The target map sends Perfume to action 1, so action 2 is never a training target and cannot be scored correct. The five-level ladder is, in practice, a four-level one. Whether action 2 should exist at all, and what condition ought to generate it (high predictive uncertainty would be the obvious candidate), is a design question the current setup never has to answer.

![](figures_v2/fig_actionmatrix.png)

**Fig. 7. Action-selection matrices in distribution,** averaged over five seeds. Rows are gas classes, columns are actions. The empty *Request Verification* column is the same in every panel.

### 4.3 Out of distribution, the picture falls apart

Each hazardous class was withheld in turn, models retrained on the remaining three, then evaluated on every window of the withheld class. Feature scaling and anomaly normalization were fitted on the three training classes only, so no statistic of the withheld class leaks into training. (Our first pass fitted the scaler on all four, and we caught it only on a re-read; the numbers below are from the corrected run.) Held-out decision accuracy is zero by construction, since withholding a class removes its target action from the training label set and the model simply cannot emit it. What the model does instead is the interesting part. **Table 6** and Figs. 8 to 10 report it.

| Held-out | Model | Missed-hazard | 95% CP bound | **Escalation (a ≥ 3)** | **Under-escalation (a ∈ {1,2})** |
|---|---|---|---|---|---|
| Smoke | Cost-weighted policy | 0.0000 | ≤ 0.038% | 1.000 ± 0.000 | 0.000 |
| Smoke | Gradient boosting | 0.0000 | ≤ 0.038% | 1.000 ± 0.000 | 0.000 |
| Smoke | Random forest | 0.0000 | ≤ 0.038% | 1.000 ± 0.000 | 0.000 |
| Smoke | Threshold rule | 0.0000 | ≤ 0.038% | 1.000 ± 0.000 | 0.000 |
| Smoke | Unweighted network | 0.0001 | ≤ 0.060% | 0.9999 ± 0.0003 | 0.000 |
| Smoke | Support vector classifier | 0.0042 | ≤ 0.558% | 0.928 ± 0.023 | 0.068 |
| Smoke | k-nearest neighbours | 0.0116 | ≤ 1.383% | 0.943 ± 0.005 | 0.045 |
| Smoke | **Multilayer perceptron** | **0.0949** | **≤ 10.047%** | 0.902 ± 0.130 | 0.003 |
| Mixture | Cost-weighted policy | 0.0000 | ≤ 0.038% | **0.226 ± 0.209** | **0.774** |
| Mixture | Gradient boosting | 0.0000 | ≤ 0.038% | **1.000 ± 0.000** | 0.000 |
| Mixture | Random forest | 0.0000 | ≤ 0.038% | **0.990 ± 0.010** | 0.010 |
| Mixture | Support vector classifier | 0.0003 | ≤ 0.080% | **0.005 ± 0.008** | **0.995** |
| Mixture | Unweighted network | 0.0004 | ≤ 0.098% | **0.215 ± 0.215** | 0.785 |
| Mixture | Multilayer perceptron | 0.0070 | ≤ 0.870% | **0.242 ± 0.121** | 0.751 |
| Mixture | k-nearest neighbours | 0.0254 | ≤ 2.854% | **0.205 ± 0.072** | 0.770 |
| Mixture | Threshold rule | 0.2487 | ≤ 25.683% | 0.564 ± 0.399 | 0.188 |

**Table 6. Leave-one-class-out evaluation.** *n* = 1,581 windows per class per seed; bounds pooled over 7,905 evaluations. Scaling fitted on the three training classes only.

**In-distribution accuracy does not order out-of-distribution missed-hazard rate.** On withheld Smoke the multilayer perceptron, which sat fifth of ten by point accuracy in Table 5 and was statistically indistinguishable from everything else there, assigns the passive *Monitor* action to 9.49% of unseen hazardous windows, with a 95% bound of 10.05%. Four other models are bounded at 0.038%. That is a separation of more than two orders of magnitude, entirely invisible in Table 5, and the rank correlation between the two is close to nil (Pearson r = +0.12 for missed hazard on unseen Smoke, r = +0.36 for escalation on unseen Mixture, Fig. 8). No accuracy-based selection procedure would have steered a team away from the failing model.

![](figures_v2/fig_dissociation.png)

**Fig. 8. In-distribution accuracy against out-of-distribution safety.** Each point is one model. If accuracy carried information about safety behavior these panels would show a trend, and they do not.

**Missed-hazard rate is not enough on its own, and this is the sharper of the two results.** On withheld Mixture, seven of eight models are bounded below 2.9% on missed hazards and would pass any review conducted on that number. Their escalation adequacy runs from 0.5% to 100%, a factor of about 198. The support-vector classifier misses 0.03% of unseen hazardous windows while escalating 0.5% of them, which means it answers roughly 99.5% of the most hazardous class in the corpus with *Increase Sampling* or *Request Verification*. The miss metric records that as a clean sheet. The cost-weighted policy escalates 22.6% and under-escalates 77.4%. Gradient boosting, carrying none of the pipeline's safety machinery, escalates all of them.

Which metric you pick, rather than which model you pick, is what decides whether a model looks safe. A metric set reporting missed-hazard rate alone would rank the support-vector classifier above gradient boosting on this evidence, and would be wrong by a factor of 198 on the quantity that decides whether anyone is notified.

Worth noting as well: the two models that escalate fully on both unseen hazards are tree ensembles, and the deployable threshold rule fails safe on unseen Smoke while failing badly on unseen Mixture at 24.87% (bound 25.68%). No comparator is uniformly best. That is itself an argument for reporting the full set rather than picking a favourite metric and defending it.

![](figures_v2/fig_loco.png)

**Fig. 9. Leave-one-class-out behavior.** (a) Missed-hazard rate on a logarithmic axis. A linear axis compresses a 9.49% failure into visual equivalence with a 0.03% one, which is how the earlier version of this figure hid the result. (b) Escalation adequacy, mean ± SD over five seeds.

![](figures_v2/fig_disposition.png)

**Fig. 10. Where hazardous windows actually go.** Each bar decomposes the response to an unseen hazardous class into alarm-grade, sub-alarm and passive. The support-vector column under held-out Mixture is almost entirely sub-alarm, and its missed-hazard rate is 0.0003.

### 4.4 Cost asymmetry moves accuracy and nothing else

The loss-weight ratio *C* from Eq. 2 was swept across nine values with everything else fixed (**Table 7**, Fig. 11).

| Cost ratio *C* | Decision accuracy | SD | Missed-hazard | Escalation | High-severity FA |
|---|---|---|---|---|---|
| 1:1 (symmetric) | 0.9562 | 0.0386 | 0.0000 | 1.000 | 0.0000 |
| 2:1 | 0.9532 | 0.0418 | 0.0000 | 1.000 | 0.0000 |
| 4:1 | 0.9570 | 0.0390 | 0.0000 | 1.000 | 0.0000 |
| 6:1 | **0.9655** | 0.0272 | 0.0000 | 1.000 | 0.0000 |
| 8:1 (deployed) | 0.9623 | 0.0214 | 0.0000 | 1.000 | 0.0000 |
| 10:1 | 0.9589 | 0.0338 | 0.0000 | 1.000 | 0.0000 |
| 12:1 | 0.9533 | 0.0346 | 0.0000 | 1.000 | 0.0000 |
| 16:1 | 0.9427 | 0.0463 | 0.0000 | 1.000 | 0.0000 |
| 20:1 | 0.8389 | 0.1189 | 0.0000 | 1.000 | 0.0000 |
| *Label function* | *1.0000* | *0.0000* | *0.0000* | *1.000* | *0.0000* |

**Table 7. Cost-asymmetry sweep, five seeds per configuration.** The label-function row applies *a*\*(·) to the true class label. It reaches the ceiling by construction, consumes the label it is meant to infer, and is not a deployable baseline.

Missed-hazard rate is zero and escalation adequacy is 1.000 at every ratio, the symmetric 1:1 configuration included. Accuracy climbs to a maximum of 0.9655 at 6:1, sits at 0.9623 at the deployed 8:1, then falls away to 0.8389 at 20:1, twelve points below the peak with variance up roughly fourfold.

So the asymmetry produced no measurable safety benefit here and, past 6:1, cost accuracy. The reason looks structural rather than accidental. Because the target action is a deterministic function of a well-separated class label, and because a miss under this definition requires assigning a hazardous window to the class furthest from it in feature space, the miss rate is already sitting on the floor before any weighting is applied. There is nothing for the asymmetry to reshape.

We would not read that as evidence against cost-sensitive learning in general. The literature is clear that it works where the error surface is non-trivial (Elkan 2001). What this benchmark shows is that it cannot demonstrate the effect, and by extension that no saturated, well-separated benchmark can. Validating a safety objective seems to need either a corpus where hazardous and benign states genuinely overlap, or a metric under which sub-alarm responses carry cost. Section 4.3 supplies the second, and under it the cost-weighted policy is not the leader.

One more thing about the deployed configuration. C = 8:1 is not the accuracy optimum, and it was originally chosen on test-partition dispersion, which is not a defensible selection criterion. Re-selecting on a validation split is on the list in Appendix A.

![](figures_v2/fig_costsweep.png)

**Fig. 11. Cost-asymmetry sweep.** Shading is ± 1 SD across five seed-varying partitions.

### 4.5 Ablating the state moves accuracy and leaves safety alone

The decision state was ablated by feature group with the architecture and protocol held fixed (**Table 8**, Fig. 12).

| Decision state | *d* | Decision accuracy | SD | Δ vs. full | Missed-hazard | Escalation |
|---|---|---|---|---|---|---|
| Full state | 22 | 0.9612 | 0.0110 | reference | 0.0000 | 1.000 |
| Without per-sensor σ | 15 | 0.9601 | 0.0357 | −0.11 pp | 0.0000 | 1.000 |
| Without anomaly score | 21 | 0.9574 | 0.0206 | −0.38 pp | 0.0000 | 1.000 |
| Without per-sensor δ | 15 | 0.9399 | 0.0413 | −2.14 pp | 0.0000 | 1.000 |
| Without δ and σ | 8 | 0.8875 | 0.0730 | −7.37 pp | 0.0000 | 1.000 |
| Current readings only | 7 | 0.8845 | 0.0764 | −7.67 pp | 0.0000 | 1.000 |
| Anomaly score only | 1 | 0.7513 | 0.1349 | −21.00 pp | 0.0000 | 1.000 |

**Table 8. Decision-state ablation, five seeds.**

Temporal features carry the accuracy. Dropping both δ and σ costs 7.37 points, and a single anomaly score on its own still manages 75.1%, which surprised us. But missed-hazard rate stays at zero and escalation adequacy stays at 1.000 in every condition, including the one-dimensional state. No feature group in this decision state changes in-distribution safety behavior at all.

That is another instance of the same trap. An ablation reported on accuracy alone would seem to identify which features "drive safety behavior," and it would be measuring something else entirely.

![](figures_v2/fig_ablation.png)

**Fig. 12. Decision-state ablation.** Bars are mean ± SD decision accuracy. Missed-hazard rate and escalation adequacy are constant across every condition.

### 4.6 Under degradation, three distinct failure modes

Six models were put through additive noise (σ = 0.1 to 0.5), calibration drift (gain and baseline shift of ±10% to ±50%) and channel dropout (*k* = 1 to 7 of 7 sensors), each at graded severity, with all three safety metrics reported (**Table 9**, Figs. 13 and 14).

| Condition | Model | Decision acc. | Missed-hazard | Escalation | High-severity FA | Alarms h⁻¹ |
|---|---|---|---|---|---|---|
| Clean | Cost-weighted | 0.962 | 0.0000 | 1.000 | 0.0000 | ≤ 3.4\* |
| Clean | Random forest | 0.977 | 0.0000 | 1.000 | 0.0000 | ≤ 3.4\* |
| Clean | Threshold rule | 0.930 | 0.0000 | 1.000 | 0.0000 | ≤ 3.4\* |
| Drift ±50% | Cost-weighted | 0.916 | 0.0000 | 1.000 | 0.0006 | 1.1 |
| Drift ±50% | Multilayer perceptron | 0.927 | 0.0003 | 0.999 | 0.0000 | 0 |
| Drift ±50% | Gradient boosting | 0.876 | **0.0775** | 0.890 | 0.0000 | 0 |
| Noise σ = 0.5 | Cost-weighted | 0.843 | 0.0000 | 1.000 | 0.1342 | 242 |
| Noise σ = 0.5 | Random forest | 0.889 | 0.0000 | 1.000 | 0.0063 | 11 |
| Dropout *k* = 1 | Cost-weighted | 0.883 | 0.0000 | 1.000 | 0.1171 | **211** |
| Dropout *k* = 1 | Threshold rule | 0.723 | 0.0000 | 1.000 | 0.2000 | **360** |
| Dropout *k* = 1 | Random forest | 0.974 | 0.0000 | 1.000 | 0.0000 | 0 |
| Dropout *k* = 3 | Cost-weighted | 0.793 | 0.0000 | 0.992 | 0.1532 | 276 |
| Dropout *k* = 3 | Multilayer perceptron | 0.851 | 0.0218 | 0.975 | 0.0234 | 42 |
| Dropout *k* = 7 | Cost-weighted | 0.318 | 0.0000 | 1.000 | **1.0000** | **1,800** |
| Dropout *k* = 7 | Threshold rule | 0.250 | 0.0000 | 1.000 | **1.0000** | **1,800** |
| Dropout *k* = 7 | Random forest | 0.355 | 0.0000 | 1.000 | 0.6000 | 1,080 |
| Dropout *k* = 7 | Multilayer perceptron | 0.332 | **0.5266** | 0.473 | 0.2000 | 360 |
| Dropout *k* = 7 | Gradient boosting | 0.381 | **0.6000** | 0.400 | 0.0000 | 0 |

**Table 9. Selected perturbation results**, with the full sweep in Fig. 13. Alarm burden is the false-alarm rate at the 0.5 Hz cadence, so rate times 1,800 windows per hour, per detector. \*The clean-condition burden is the Clopper-Pearson upper bound on an observed zero, not a point estimate.

Three failure modes separate cleanly, and no single metric tells them apart.

*Fail-loud.* The cost-weighted policy and the threshold rule hold zero missed hazards and full escalation right through complete sensor loss, and they do it by escalating everything. False-alarm rate reaches 1.000, which is 1,800 high-severity alarms per hour from one detector. Under EEMUA (2013) that is a hazard, not a safe failure. On the missed-hazard metric alone it is a perfect score.

*Fail-silent.* Gradient boosting keeps its false-alarm rate at zero throughout and misses 60% of hazards at *k* = 7, escalation collapsing to 0.400. On the false-alarm metric alone, also a perfect score.

*Graceful, then brittle.* The random forest holds zero misses, full escalation and no false alarms out to *k* = 3, then jumps to a 60% false-alarm rate by *k* = 7.

The number that matters operationally is the first onset rather than the endpoint. Losing one sensor of seven takes the cost-weighted policy from zero to about 211 high-severity alarms per hour per detector, and the threshold rule to 360, while the random forest is unaffected (Fig. 14). A facility running a hundred detectors would notice within the shift. Neither an accuracy table nor a missed-hazard table would have predicted it.

We should add that below roughly 60% accuracy none of these models is doing the job in any useful sense. "Zero missed hazards" at 31.8% accuracy is a statement about how a model fails, not about whether it is fit for service.

![](figures_v2/fig_perturb.png)

**Fig. 13. Graded perturbation suite.** Rows share a scale so the panels can be compared. Peak false-alarm rate under drift is 0.06%.

![](figures_v2/fig_alarmburden.png)

**Fig. 14. False-alarm rate expressed as alarm burden.** The dashed line is the EEMUA 191 long-term average envelope for a whole operator position. Two models cross it after a single sensor is lost.

### 4.7 Calibration

Confidence matters here because any escalation threshold, and any deferral rule, would be set against it. Four estimators were compared on the corrected pipeline: the raw softmax, MC dropout with 20 passes, temperature scaling, and a five-member deep ensemble built from the same model class and objective as the single model rather than from a different one. Temperature is fitted on a calibration split carved out of training, never on the training logits themselves, and ECE uses equal-mass bins because confidence on this corpus piles up near 1 and equal-width bins leave most of the range empty (**Table 10**, Fig. 15).

| Estimator | ECE | SD | Bootstrap 95% CI | ECE on hazardous windows | Brier | NLL | Accuracy |
|---|---|---|---|---|---|---|---|
| Deep ensemble (5) | **0.0162** | 0.0129 | 0.0107 to 0.0253 | 0.0002 | 0.0552 | 0.1082 | 0.9663 |
| MC dropout (20) | 0.0222 | 0.0184 | 0.0150 to 0.0320 | 0.0002 | 0.0613 | 0.1145 | 0.9619 |
| Raw softmax | 0.0244 | 0.0187 | 0.0166 to 0.0342 | 0.0002 | 0.0628 | 0.1397 | 0.9628 |
| Temperature scaling | 0.0263 | 0.0194 | 0.0178 to 0.0358 | 0.0000 | 0.0640 | 0.1560 | 0.9628 |

**Table 10. Calibration, five seeds.** ECE with 15 equal-mass bins; intervals from 400 bootstrap resamples per seed.

The ensemble comes out lowest and every bootstrap interval overlaps every other, so we would not rank the four with any confidence. Two observations seem more useful than the ordering.

The first is that **overall ECE is driven entirely by the non-hazardous classes**. Restricted to Smoke and Mixture windows, every estimator is calibrated to within 0.02%, and temperature scaling to within rounding. The miscalibration lives on the NoGas and Perfume boundary, which is the same place the perception errors and the anomaly-score overlap live. For a system whose escalation threshold would be set on hazardous-class confidence, that is reassuring, and it is invisible in a single pooled ECE number.

The second is that **temperature scaling made things slightly worse**, which is not what the usual account predicts. The fitted temperature is consistently below 1, at 0.839 ± 0.044 across seeds and never above 0.89, meaning the network is under-confident rather than over-confident on this corpus. Sharpening an already under-confident distribution moves it away from calibration. We suspect this is a consequence of the cost weighting rather than anything about the architecture, though we have not tested that, and an earlier version of this experiment fitted the temperature on training logits and reported the opposite ranking. The bin-count sweep in Fig. 15c shows the ordering is stable from 5 to 30 bins, so the result is at least not an artifact of the binning choice.

![](figures_v2/fig_calibration.png)

**Fig. 15. Calibration.** (a) ECE with bootstrap intervals. (b) The same, split into all windows against hazardous windows only. (c) Sensitivity to the number of bins.

### 4.8 Edge deployment

**Table 11** gives latency, footprint and safety behavior across four configurations. These are carried over from the original hardware campaign and were not re-run for this revision, for the plain reason that the Pi was not available.

| Configuration | Size (MB) | Mean latency (ms) | P99 (ms) | Decision acc. (%) | Missed-hazard | High-severity FA |
|---|---|---|---|---|---|---|
| Desktop CPU, float32 | 8.74 | 5.8 | 9.6 | 94.44 | 0.0000 | 0.0000 |
| Pi 4, float32, synchronous | 8.74 | 14,738 | 24,202 | 94.36 | 0.0000 | 0.0000 |
| Pi 4, INT8, synchronous | 4.19 | 14,675 | 24,028 | 93.97 | 0.0000 | 0.0032 |
| Pi 4, INT8, asynchronous reasoning | 4.19 | **235** | 413 | 93.97 | 0.0000 | 0.0032 |

**Table 11. Edge deployment on a Raspberry Pi 4 against a 2,000 ms sampling budget.**

![](figures_v2/fig_edge.png)

**Fig. 16. Edge behavior.** (a) Latency by configuration on a log axis against the 2,000 ms budget. (b) The sustained run, with clock and latency indexed to their pre-throttle values, since the two quantities share no natural scale.

Explanation has to come off the decision path. Synchronous local explanation produces a mean end-to-end latency of 14,738 ms against a 2,000 ms budget, a factor of seven over, on hardware that is otherwise entirely adequate: the decision network itself runs in 1.07 ms. Move explanation off the critical path and quantize to INT8 and the deployable path drops to 235 ms mean, 413 ms at P99. The general point travels beyond this system. In a monitoring context a language model's job is to explain a decision already taken, never to help take it, and the timing budget enforces what the safety argument in Section 3.3 already required.

Quantization carries a safety cost that is small but real. INT8 halves the footprint from 8.74 to 4.19 MB and introduces one high-severity false alarm across 316 clean windows, a rate of 0.0032 with a 95% upper bound of 1.49%. Where zero high-severity false alarms is a hard requirement, the decision network can stay in floating point while the larger perception model is quantized. The decision network is not what makes the footprint.

The conversion from rate to burden is, on our reading, the single most useful reframing available to work of this kind. A rate is not comparable with the envelopes an operator works inside, so convert it. At 0.5 Hz one detector processes 1,800 windows per hour, which puts the INT8 point estimate at roughly 5.8 high-severity alarms per hour from a single instrument under continuous clean-air operation. From one detector, that is already close to the long-term average EEMUA (2013) treats as the limit of manageability for an entire operator position. The float32 configuration saw no false alarm at all, but its 95% upper bound of 0.944% corresponds to as much as 17 alarms per hour, again per detector. "Zero false alarms in 316 windows" sounds strong and, put into the units an alarm-management engineer uses, is not yet evidence of anything acceptable. Getting there needs observation counts one to two orders of magnitude larger than anything reported here.

Sustained operation narrows the margin more than a short benchmark suggests. Over a 36-minute passively cooled run the processor reached its 80 °C throttle point after about 24 minutes, dropping the clock from 1,500 to 1,234 MHz and raising median latency from 420 to 640 ms. The decision path stayed inside budget, but the margin more than halved through an effect no five-minute test would have surfaced.

### 4.9 Standing relative to prior work on this corpus

Published classification accuracies on MultimodalGasData run from 93% to 99.7%, and the decision accuracies here sit below most of them. We would rather say that plainly than let a reviewer discover it, because the comparison is not like-for-like in either direction and both directions matter.

Against us: our evaluation uses a block-wise holdout with an explicit embargo, discards boundary-straddling windows, moves the partition with the seed, and fits all scaling on the training partition. The published comparisons appear to use randomized splits over overlapping windows from a single recording session, which is the protocol Dennler et al. (2022) showed conflates recording time with class identity. The figures are not directly comparable, and the direction of the bias is known even if its size on this particular corpus is not.

In our favour: the quantities differ. A classification error and an action error do not carry the same operational weight. Confusing two hazardous classes preserves the need to escalate; assigning a hazardous window to *Monitor* gives up the intervention window. For a like-for-like recognition comparison the relevant number is the thermal classifier's 98.8%, subject to the split caveat in Section 3.3.

Either way, we are not claiming an accuracy advantage and nothing in the contribution rests on one.

---

## 5. Discussion

### 5.1 The dissociation, and where its boundary sits

The central result is a dissociation with a fairly sharp edge to it. In distribution, ten model families spanning tree ensembles, kernel methods, feedforward and recurrent networks, offline reinforcement learning and a three-level decision tree are indistinguishable on every metric we report. Not just accuracy: 4.7 points separate best from worst, which this design cannot resolve, and all but one record zero missed hazards, full escalation and zero false alarms. A facility choosing among them on in-distribution evidence has no basis for choosing at all, including no basis for preferring a deep model to a decision tree.

Out of distribution the same models separate by more than two orders of magnitude on missed-hazard rate and by roughly 198 times on escalation adequacy, and the orderings do not carry across. The model that fails safe on one unseen hazard under-escalates on another. The two that escalate fully on both are tree ensembles carrying none of the pipeline's safety machinery. The deployable threshold rule is perfect on one unseen hazard and among the worst on the other.

For practice the implication is direct enough. A team selecting a gas-monitoring model on benchmark accuracy, which is what the published literature on this corpus encourages, gets no information about how the chosen model will behave on a release it has not seen. That is the condition the model will eventually face, and on this evidence it is the only condition in which these models differ at all.

There is a counter-reading worth taking seriously. One could argue that LOCO is an unfairly severe test, since no fielded system is asked to classify a gas absent from its training set, and that the in-distribution agreement is the operationally relevant finding. We are not persuaded, mostly because a MOX array in a facility meets cross-sensitivities and interferent mixtures that were not in anyone's training set fairly routinely. But the objection is reasonable, and a reader who takes it seriously would draw a narrower conclusion from our results than we do.

### 5.2 Why missed-hazard rate is not enough

Having established that accuracy is the wrong metric, the obvious substitute is missed-hazard rate. Our LOCO results suggest that substitution is insufficient in a specific way.

A miss metric that counts only the fully passive response scores a hazardous window answered with *Request Verification* as a success. On withheld Mixture, seven of eight models satisfy that metric, all bounded below 2.9% at 95% confidence, while escalating anywhere from 0.5% to 100% of the same windows. An operator running the support-vector configuration would hear nothing for about 99.5% of windows of the most hazardous class in the corpus, and the safety metric would report a clean run.

This looks to us like the most transferable finding here, and it is not specific to gas monitoring. Wherever a graded response hierarchy is learned, a metric defined on the most extreme failure can be satisfied by systematic under-response one rung above it. The fix is to define the metric at the operationally meaningful threshold, which here is whether an operator gets notified, rather than at the worst conceivable outcome.

Section 4.6 shows the mirror-image trap just as clearly. Under complete sensor loss the cost-weighted policy and the threshold rule score perfectly on missed hazard and escalation by escalating everything, at 1,800 alarms per hour per detector. Gradient boosting scores perfectly on false alarms by missing 60% of hazards. Each of the three metrics, taken alone, certifies a different model as safe. Only together do they describe what the system is actually doing.

### 5.3 What the cost asymmetry did, and what it did not

The sweep returns no effect on missed-hazard rate or escalation adequacy at any ratio from 1:1 to 20:1, with an accuracy penalty above 6:1. That is worth sitting with rather than setting aside, because the asymmetric objective was the mechanism by which the pipeline was supposed to be safe.

The explanation appears structural, and it generalizes: on a saturated, well-separated benchmark a safety objective cannot really be validated, because the unsafe behavior it exists to suppress does not occur in the first place. Showing that a cost asymmetry works needs either a corpus where hazardous and benign states genuinely overlap, or a metric under which sub-alarm responses carry cost. Section 4.3 supplies the second, and there the cost-weighted policy escalates 22.6% of unseen Mixture windows against gradient boosting's 100%.

A fair question at this point is what the learned policy contributes at all. On this evidence, in nominal conditions, nothing a depth-3 decision tree does not contribute, at 3.3 fewer accuracy points and identical safety behavior. Its advantages are narrow and specific: full escalation on unseen Smoke where the perceptron misses 9.49%, and zero missed hazards under 50% calibration drift where gradient boosting misses 7.75%. Each of those is bought with a false-alarm cost under sensor loss that the tree ensembles do not pay. We would rather present it that way than as a general improvement.

There is a further point about the objective itself that we think matters more than the sweep. Eq. 2 weights samples by class hazard but treats all incorrect actions identically. Under-escalating a hazardous window to *Request Verification* and over-escalating it to *Emergency Shutdown* incur exactly the same loss. That is not a cost asymmetry in the sense the safety argument needs, and it is the most plausible mechanical explanation we have for the escalation behavior in Section 4.3. An ordinal objective, or a full cost matrix in which both distance and direction along the action ladder carry cost, is the design the evidence points toward. We have not tested it, and it would be the first thing we would try next.

### 5.4 What this means for deployment

Three conclusions held across every configuration, and they are probably the most portable engineering content here.

Language models belong outside the decision path. The safety argument and the latency arithmetic converge on the same answer: a 14.7 s synchronous path against a 2 s budget is not a tuning problem, and a model that could change an action it cannot be verified to justify would be a hazard even if it ran instantly.

Quantization and sensor-loss behavior are alarm-management decisions rather than modeling decisions. INT8 introduced about 5.8 alarms per hour per detector; losing one sensor of seven introduced 211. Whether either is tolerable is a judgment about operator load, and it cannot be made from an accuracy table.

Qualification has to be sustained, and it has to include sensor loss. A 36-minute run halved the latency margin through thermal throttling alone, and single-channel dropout, which is the most likely fault a fixed detector will actually experience, separates models that look identical on every clean-condition metric.

### 5.5 What we are not claiming

None of this establishes that the pipeline detects hydrocarbons, since the corpus contains none. None of it establishes that any model here is fit for service: the largest observation count supporting any zero-count claim is 7,905 evaluations, which bounds a miss rate at 0.038% and no lower. Nothing here validates the coordination and explanation components, which are apparatus, are not experimentally isolated, and support no result we report. And the models are not ranked, because the design cannot rank them.

What the study does support is narrower and, we think, more useful: the evaluation conventions of this literature are not fit for the purpose the literature claims for them, and a metric set costing a few extra columns per experiment reverses model-selection decisions on this corpus.

---

## 6. Limitations and Threats to Validity

**Analyte validity.** Incense smoke, alcohol-based vapor and a mixture of the two. These are surrogates. Nothing here establishes detection performance for methane or heavier hydrocarbons, and external validity to petroleum facility monitoring is argued from the shared MOX transduction mechanism rather than shown.

**Single session, single device.** All 6,400 samples come from one acquisition session on one device. Sensor ageing, device-to-device variability, seasonal ambient swings, wind, hydraulic transients and long-term drift are all absent. Cross-session and cross-device validation is the most important experiment still outstanding.

**Statistical power.** Five paired seeds cannot resolve differences at α = 0.05 under a Wilcoxon signed-rank test whose minimum attainable two-sided *p* at *n* = 5 is 0.0625. No ranking among the models is asserted, and none should be read in.

**Metric scope.** Missed-hazard rate counts only the fully passive action, which is why escalation adequacy is reported beside it. A graded expected-cost formulation over a full action-distance cost matrix would be better, and we did not attempt one.

**Perception split.** The thermal-image split is randomized over consecutive frames from one session, so it is exposed to the leakage mechanism the sensor-side protocol excludes. The image corpus was unavailable when this revision was prepared, so it could not be corrected. 98.8% is an optimistic upper bound and no conclusion here rests on it.

**Anomaly severity ordering.** The anomaly score separates hazardous from benign conditions by two orders of magnitude but is not monotone in target severity, since Mixture scores below Smoke. Read it as evidence of abnormality only.

**Edge measurements not re-run.** Section 4.8 comes from the original hardware campaign on the earlier data pipeline. Its decision-accuracy figures are not directly comparable with Sections 4.2 to 4.7, though the latency, footprint and thermal measurements are unaffected by the pipeline change.

**Modality scope.** The action policy consumes sensor dynamics and the anomaly score only. Visual evidence informs the perception and explanation paths, not the action.

**Coordination layer.** The components that coordinate, critique and supervise the pipeline are apparatus, are not experimentally isolated, and no claim depends on them.

**Perturbation realism.** Drift is modeled as a per-channel gain and baseline shift applied at test time, and dropout as channel zeroing. Neither reproduces the temporal character of real MOX ageing, and a reviewer would be right to treat the drift results as indicative rather than predictive.

---

## 7. Conclusions

We evaluated an edge-deployable gas-monitoring pipeline against a broader metric set than accuracy alone, on a public MOX benchmark of laboratory surrogates, under a leakage-controlled block-wise holdout with seed-varying partitions.

1. **In distribution the metric set does not discriminate.** Ten multiclass models spanning very different inductive biases lie within 4.7 accuracy points, and all but one record zero missed hazards, escalation adequacy of 1.000 and zero high-severity false alarms. A depth-3 decision tree on seven raw sensor channels matches every learned model on all three safety metrics.

2. **Out of distribution, accuracy ranking carries almost no information about safety.** Withholding one hazardous class separates the same models by more than two orders of magnitude on missed-hazard rate, 9.49% against a 0.038% bound, with a correlation to in-distribution accuracy of r = +0.12.

3. **Missed-hazard rate is necessary and not sufficient.** On a second unseen hazardous class, seven of eight models are bounded below 2.9% on missed hazards while escalating between 0.5% and 100% of the same windows, a factor of about 198 on the quantity that decides whether an operator is notified, and invisible to a miss metric that counts only the passive action.

4. **A cost-asymmetric objective produced no measurable safety benefit** at any ratio from 1:1 to 20:1, and degraded accuracy above 6:1. Where hazardous and benign states are well separated and the target action is a deterministic function of the class, there appears to be no error surface for a safety objective to reshape.

5. **Under graded sensor loss three distinct failure modes appear, and each single metric certifies a different model as safe.** Fail-loud models reach a 100% false-alarm rate, or 1,800 alarms per hour per detector, while scoring perfectly on missed hazard. Fail-silent models hold zero false alarms while missing 60% of hazards. Losing one sensor of seven moves the cost-weighted policy from zero to 211 alarms per hour and leaves the random forest untouched.

Put together, these results argue for reporting missed-hazard rate with a confidence bound, escalation adequacy, false-alarm burden in alarm-management units, and the degradation of all three under graded sensor loss and drift, alongside accuracy rather than instead of it. On the evidence here an evaluation reporting accuracy alone would have said nothing useful about any of these behaviors, and each safety metric taken on its own would have picked a different model.

Where we would go next, roughly in order: cross-session and cross-device validation; evaluation on a corpus containing a controlled hydrocarbon release; an ordinal or cost-matrix objective that prices under-escalation and over-escalation differently; class-conditional conformal prediction (Angelopoulos and Bates 2023) to turn observed zero-miss counts into distribution-free coverage guarantees on the hazardous class; and a properly powered comparison over many randomized runs with an equivalence analysis (Benavoli et al. 2017; Bouthillier et al. 2021).

---

## Nomenclature

| Symbol | Definition |
|---|---|
| *a* | safety action, *a* ∈ {0, 1, 2, 3, 4} |
| *a*\*(·) | acceptable target-action map from gas class to action set |
| *C* | cost ratio, *C* = *c*_miss / *c*_false |
| *c*_miss, *c*_false | loss weights for hazardous and non-hazardous training samples |
| *E*ₜ | operator-facing explanation at cycle *t* |
| *G* | embargo length between training and test partitions, in windows |
| *g*ₜ | ground-truth gas class for window *t* |
| *h* | CUSUM decision threshold |
| *I*ₜ | thermal image at cycle *t* |
| *k* | number of sensor channels removed (dropout severity) |
| *L*(θ) | cost-weighted cross-entropy objective, Eq. 2 |
| *N* | number of training samples |
| *n* | number of observations or paired runs |
| *p*_θ | action probability distribution under parameters θ |
| *S*ₜ | CUSUM statistic at step *t* |
| **X**ₜ | seven-channel sensor window, **X**ₜ ∈ ℝ^(20×7) |
| **δ**ₜ | per-sensor change across the window |
| θ | model parameters |
| μ₀ | CUSUM baseline mean, estimated on NoGas training windows |
| ρ̃ₜ | normalized reconstruction-error anomaly score |
| **σ**ₜ | per-sensor standard deviation across the window |
| σ | additive-noise standard deviation (Section 4.6) |
| τ | anomaly detection threshold |
| φₜ | 22-dimensional decision state, Eq. 1 |

**Subscript.** *t*, inference cycle or window index.

**Abbreviations.** CP, Clopper-Pearson; ECE, expected calibration error; ESD, emergency shutdown; FA, false alarm; LOCO, leave-one-class-out; MOX, metal-oxide semiconductor; ROC-AUC, area under the receiver operating characteristic curve; SD, standard deviation; SIS, safety instrumented system; VOC, volatile organic compound.

---

## Acknowledgments

This work was supported by the Subsurface Energy and Digital Innovation Center (SEDI) at the University of Wyoming. The MultimodalGasData corpus is used under CC BY 4.0, and we thank Narkhede et al. for putting it in the public domain.

## Author Contributions

**B. C. Nweke:** conceptualization, methodology, software, investigation, formal analysis, data curation, visualization, writing of the original draft. **G. Ramezan:** conceptualization, methodology, writing, review and editing. **S. Saraji:** conceptualization, supervision, project administration, resources, writing, review and editing.

## Declaration of Competing Interest

The authors declare no known competing financial interests or personal relationships that could have appeared to influence the work reported here.

## Data and Code Availability

The MultimodalGasData corpus is publicly available (Narkhede et al. 2022) under CC BY 4.0. Experiment drivers, the safety-metric module, the additional baselines, model checkpoints and the result files behind Tables 5 to 10 are available from the corresponding author. See Appendix B.

---

## References

Adegboye, M. A., Fung, W. K., and Karnik, A. 2019. Recent Advances in Pipeline Monitoring and Oil Leakage Detection Technologies: Principles and Approaches. *Sensors* 19 (11): 2548. https://doi.org/10.3390/s19112548.

Angelopoulos, A. N. and Bates, S. 2023. Conformal Prediction: A Gentle Introduction. *Foundations and Trends in Machine Learning* 16 (4): 494–591. [CITATION NEEDED, verify volume and pagination]

Benavoli, A., Corani, G., Demšar, J. et al. 2017. Time for a Change: A Tutorial for Comparing Multiple Classifiers Through Bayesian Analysis. *Journal of Machine Learning Research* 18 (77): 1–36.

Bouthillier, X., Delaunay, P., Bronzi, M. et al. 2021. Accounting for Variance in Machine Learning Benchmarks. *Proc., Machine Learning and Systems (MLSys)* 3: 747–769. [CITATION NEEDED, verify pagination]

Bustnes, T. E., Rousselet, M., and Berland, S. 2011. Leak Detection Performance of a Commercial Real-Time Transient Model. Paper presented at the PSIG Annual Meeting, Napa Valley, California, 24–27 May. PSIG-1114.

Clopper, C. J. and Pearson, E. S. 1934. The Use of Confidence or Fiducial Limits Illustrated in the Case of the Binomial. *Biometrika* 26 (4): 404–413. https://doi.org/10.1093/biomet/26.4.404.

Dehnaw, A. M., Manie, Y. C., Yao, C.-K. et al. 2024. Deep Neural Network Optimization for Efficient Gas Detection Systems in Edge Intelligence Environments. *Processes* 12 (12): 2638. [CITATION NEEDED, verify author list and issue]

Dennler, N., Rastogi, S., Fonollosa, J. et al. 2022. Drift in a Popular Metal Oxide Sensor Dataset Reveals Limitations for Gas Classification Benchmarks. *Sensors and Actuators B: Chemical* 361: 131668. [CITATION NEEDED, verify volume and article number]

EEMUA. 2013. *Alarm Systems: A Guide to Design, Management and Procurement*, third edition. EEMUA Publication 191. London: Engineering Equipment and Materials Users Association.

El Barkani, M., Benamar, N., Talei, H. et al. 2024. Gas Leakage Detection Using Tiny Machine Learning. *Electronics* 13 (23): 4768. https://doi.org/10.3390/electronics13234768.

Elkan, C. 2001. The Foundations of Cost-Sensitive Learning. *Proc., 17th International Joint Conference on Artificial Intelligence (IJCAI)*, Seattle, Washington, 4–10 August, 973–978.

Faleh, R. and Kachouri, A. 2023. A Hybrid Deep Convolutional Neural Network-Based Electronic Nose for Pollution Detection. *Chemometrics and Intelligent Laboratory Systems* 237: 104825. https://doi.org/10.1016/j.chemolab.2023.104825.

Goel, P., Datta, A., and Mannan, M. S. 2017. Industrial Alarm Systems: Challenges and Opportunities. *Journal of Loss Prevention in the Process Industries* 50: 23–36. https://doi.org/10.1016/j.jlp.2017.09.001.

Google DeepMind. 2025. Gemma 3 Technical Report. [CITATION NEEDED, cite the Gemma 3 report with correct year and identifier]

Han, P. and Kim, M. 2014. Optimizing Leak Detection Performance. Paper presented at the PSIG Annual Meeting, Baltimore, Maryland, 6–9 May. PSIG-1407.

IEC. 2016. *Functional Safety, Safety Instrumented Systems for the Process Industry Sector, Part 1*, IEC 61511-1:2016. Geneva: International Electrotechnical Commission.

ISA. 2016. *Management of Alarm Systems for the Process Industries*, ANSI/ISA-18.2-2016. Research Triangle Park, North Carolina: International Society of Automation.

Jessen, H. and Roshchin, M. 2025. Agentic AI Revolution Across Oil and Gas Value Streams. Paper SPE-229240-MS presented at ADIPEC. [CITATION NEEDED, verify location and dates]

Jocher, G., Chaurasia, A., and Qiu, J. 2023. YOLOv8 by Ultralytics. https://github.com/ultralytics/ultralytics.

Korjani, M., Conley, D., and Smith, M. 2024. Temporal Deep Learning Image Processing Model for Natural Gas Leak Detection Using OGI Camera. Paper OTC-34756-MS presented at the Offshore Technology Conference Asia. [CITATION NEEDED, verify location and dates]

Laberge, J. C., Bullemer, P., Tolsma, M. et al. 2014. Addressing Alarm Flood Situations in the Process Industries Through Alarm Summary Display Design and Alarm Response Strategy. *International Journal of Industrial Ergonomics* 44 (3): 395–406. https://doi.org/10.1016/j.ergon.2013.11.008.

Liang, J., Liang, S., Zhang, H. et al. 2024. Leak Detection in Natural Gas Pipelines Based on Unsupervised Reconstruction of Healthy Flow Data. *SPE Prod & Oper* 38 (3): 513–526. [CITATION NEEDED, verify pagination, SPE paper number and DOI. The earlier draft cited this as SPE Journal; it appeared in SPE Production & Operations]

Malhotra, P., Ramakrishnan, A., Anand, G. et al. 2016. LSTM-Based Encoder-Decoder for Multi-Sensor Anomaly Detection. arXiv:1607.00148 (preprint, submitted 1 July 2016).

Murvay, P.-S. and Silea, I. 2012. A Survey on Gas Leak Detection and Localization Techniques. *Journal of Loss Prevention in the Process Industries* 25 (6): 966–973. https://doi.org/10.1016/j.jlp.2012.05.010.

Narkhede, P., Walambe, R., Mandaokar, S. et al. 2021. Gas Detection and Identification Using Multimodal Artificial Intelligence Based Sensor Fusion. *Applied System Innovation* 4 (1): 3. https://doi.org/10.3390/asi4010003.

Narkhede, P., Walambe, R., Chandel, P. et al. 2022. MultimodalGasData: Multimodal Dataset for Gas Detection and Classification. *Data* 7 (8): 112. https://doi.org/10.3390/data7080112.

Page, E. S. 1954. Continuous Inspection Schemes. *Biometrika* 41 (1/2): 100–115. https://doi.org/10.1093/biomet/41.1-2.100.

Sabbagh, V. B., Lima, C. B. C., and Xexéo, G. 2024. Comparative Analysis of Single and Multiagent Large Language Model Architectures. *SPE J.* 29 (12): 6869–6884. [CITATION NEEDED, verify issue and SPE paper number]

Santiago, C. J. S., Shumaker, N., and Weir, A. 2025. Integrating Data-Driven Insights with Domain Expertise Using Agentic Conversational Analytics. Paper SPE-228143-MS presented at the SPE Annual Technical Conference and Exhibition. [CITATION NEEDED, verify location and dates]

Sharma, A., Kumar, R., Singh, P. et al. 2024. Gas Detection and Classification Using Multimodal Data Based on Federated Learning. *Sensors* 24 (18): 5904. https://doi.org/10.3390/s24185904. [CITATION NEEDED, verify author list]

Vergara, A., Vembu, S., Ayhan, T. et al. 2012. Chemical Gas Sensor Drift Compensation Using Classifier Ensembles. *Sensors and Actuators B: Chemical* 166–167: 320–329. https://doi.org/10.1016/j.snb.2012.01.074.

Wang, Z., Schaul, T., Hessel, M. et al. 2016. Dueling Network Architectures for Deep Reinforcement Learning. *Proc., 33rd International Conference on Machine Learning (ICML)*, New York City, 19–24 June, 1995–2003.

Zhang, E. and Zhang, E. 2025. Gas Pipeline Leakage Detection Based on Multiple Multimodal Deep Feature Selections and Optimized Deep Forest Classifier. *Frontiers in Environmental Science* 13: 1569621. [CITATION NEEDED, verify article number]

Zhang, J., Hoffman, A., Murphy, K. et al. 2013. Review of Pipeline Leak Detection Technologies. Paper presented at the PSIG Annual Meeting, Prague, Czech Republic, 16–19 April. PSIG-1303.

---

## Appendix A. Items Still Requiring Author Action

This appendix is a working list and is not intended for publication. Everything else in the manuscript is backed by a result file generated for this revision.

**A.1 Cannot be resolved without data not currently on disk.**

1. *Perception split (Section 3.3, Table 4).* `data/Thermal Camera Images` is empty in the working tree, and the only frames present anywhere are 83 Mixture images (one of them zero bytes) in a partial download folder. The randomized image split therefore could not be replaced with a block-wise one. Restore the images, re-split block-wise, re-report. If accuracy falls, that is a reportable result and it supports the paper's own argument rather than undermining it.
2. *Edge deployment (Section 4.8, Table 11).* Needs the Raspberry Pi 4. The latency, footprint and thermal figures are hardware measurements and stand as they are. The decision-accuracy column was produced on the earlier data pipeline and is not comparable with Sections 4.2 to 4.7, so the replay should be re-run on the corrected pipeline with escalation adequacy and alarm burden added to each row.

**A.2 Recommended before submission.**

3. Re-select the deployed cost ratio on a held-out validation split rather than on test-partition dispersion (Section 4.4).
4. Implement and evaluate an ordinal or cost-matrix objective that prices under-escalation and over-escalation differently (Section 5.3). This is where the paper's own evidence points and is probably the strongest single addition available.
5. Reliability diagrams for the four calibration estimators. Section 4.7 reports ECE with adaptive bins, bootstrap intervals, a bin sweep, class-conditional ECE, Brier score and NLL, but not the diagrams themselves.
6. Raise the run count from 5 to at least 29 randomized runs and add an equivalence analysis over a region of practical equivalence, so a positive claim of practical equivalence can be made instead of a disclaimer about power (Section 3.6).
7. Reconcile the false-alarm denominator across the codebase. `retrain/metrics.py` divides false alarms by the number of alerts; this manuscript divides by the number of clean windows. They agree only at zero, and only the latter converts to alarm burden.
8. Resolve every `[CITATION NEEDED]` in the reference list, and confirm that Liang et al. (2024) is cited to *SPE Production & Operations* rather than SPE Journal.

**A.3 Terminology, resolved here but needing author sign-off.** The earlier draft described the decision component as trained by offline reward-shaped reinforcement learning, with an asymmetric reward, ε-greedy action selection, replay episodes, cumulative reward and a Huber loss. The model behind every number in this paper is trained by cost-weighted cross-entropy against targets from the deterministic map *a*\*(·), as set out in Section 3.3 and Eq. 2. The description here is the correct one. All reinforcement-learning language and the associated training-dynamics figure have been removed, and this correction should carry explicit sign-off from all three authors.

---

## Appendix B. Reproducibility

**Pipeline.** Windows of length 20 formed over the raw corpus, with windows spanning a class boundary discarded, giving 6,324 windows at 1,581 per class. The anomaly feature is the mean reconstruction error of the full 20-step window under the pretrained NoGas autoencoder. The block-wise holdout reserves a contiguous 20% of each class block for test, separated from both training segments by a 20-window embargo, with the held-out block's position drawn from the run seed. Feature standardization and anomaly-percentile normalization are fitted on the training partition only. In the leave-one-class-out experiment they are fitted on the three training classes only, so no statistic of the withheld class enters training.

**Protocol.** Five seeds (42, 1337, 7, 2024, 99), each with its own partition. PyTorch determinism guards enabled, single-threaded execution. Every experiment in Sections 4.1 to 4.7 was executed in a single uninterrupted run for this revision.

**Artifacts.** `retrain/safety_metrics.py` (metric set and Clopper-Pearson bounds); `retrain/new_baselines.py` (k-NN, threshold rule, CUSUM); `retrain/run_all_v2.py` (model comparison, cost sweep, perturbation, ablation, anomaly evaluation); `retrain/run_loco_v3.py` (leave-one-class-out with three-class scaling); `retrain/run_calib_actions_v2.py` (calibration, action-selection matrices, ROC curves); `retrain/make_figs_v2.py` (Figs. 1 to 16). Results in `retrain/results_v2/`: `v2_zoo.csv`, `v2_zoo_sig.json`, `v2_loco.csv`, `v2_costsweep.csv`, `v2_perturb.csv`, `v2_ablation.csv`, `v2_anomaly.json`, `v2_calibration.csv`, `v2_calibration_perseed.csv`, `v2_calibration_binsweep.csv`, `v2_action_matrix.csv`, `v2_roc.json`.

**Figure palette.** Categorical colors were checked against colorblind-separation, chroma, lightness and contrast criteria. The green and orange pair sits in the marginal separation band, so every categorical mark also carries a direct value label as a second channel of encoding.
