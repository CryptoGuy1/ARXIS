# ARXIS revision v5

`ARXIS_Manuscript_v5.md` is the current manuscript. Sections 4.1 to 4.7 come
entirely from the result files in `results_v2/`. 16 figures, 11 tables.

## Figures (all referenced from the manuscript, in order)
| File | Fig. | Shows |
|---|---|---|
| fig_protocol.png     | 1  | corpus layout, held-out block, 20-window embargo |
| fig_architecture.png | 2  | pipeline block diagram, advisory boundary marked |
| fig_perception.png   | 3  | thermal confusion matrices + per-class scores |
| fig_anomaly.png      | 4  | per-class anomaly score; in-sample vs held-out operating point |
| fig_roc.png          | 5  | ROC curves per seed vs in-sample; score distributions by class |
| fig_zoo.png          | 6  | in-distribution decision accuracy, 10 models |
| fig_actionmatrix.png | 7  | action-selection matrices; action 2 is never selected |
| fig_dissociation.png | 8  | in-distribution accuracy vs out-of-distribution safety |
| fig_loco.png         | 9  | leave-one-class-out miss rate (log axis) and escalation |
| fig_disposition.png  | 10 | alarm / sub-alarm / passive breakdown on unseen hazards |
| fig_costsweep.png    | 11 | cost ratio 1:1 to 20:1 |
| fig_ablation.png     | 12 | decision-state feature ablation |
| fig_perturb.png      | 13 | graded noise / drift / dropout, three metrics |
| fig_alarmburden.png  | 14 | false alarms as alarms per hour vs EEMUA 191 |
| fig_calibration.png  | 15 | ECE with bootstrap CIs, class-conditional, bin sweep |
| fig_edge.png         | 16 | latency by configuration; sustained thermal run |

## Code (drop into `retrain/`)
safety_metrics.py, new_baselines.py, run_all_v2.py, run_loco_v3.py,
run_calib_actions_v2.py, make_figs_v2.py

Run order: `run_all_v2.py`, `run_loco_v3.py`, `run_calib_actions_v2.py`,
then `make_figs_v2.py`.

## Results (results_v2/)
v2_zoo.csv, v2_zoo_sig.json, v2_loco.csv, v2_costsweep.csv, v2_perturb.csv,
v2_ablation.csv, v2_anomaly.json, v2_calibration.csv,
v2_calibration_perseed.csv, v2_calibration_binsweep.csv,
v2_action_matrix.csv, v2_roc.json

## Superseded
Files in `retrain/results/` and the figures in `paper_figures/` came from the
earlier pipeline. `paper_figures/` filenames are also offset by two relative to
their content. Do not mix the two sets.
