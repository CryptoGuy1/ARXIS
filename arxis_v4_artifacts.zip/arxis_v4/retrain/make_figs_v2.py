"""Regenerate the paper figures from the v2 results.

Palette validated with the dataviz validator (light surface #fcfcfb):
  lightness band PASS, chroma floor PASS, CVD separation WARN (green/orange
  dE 7.0, inside the 6-8 floor band) -> legal only with secondary encoding,
  so every categorical mark also carries a direct value label.
"""
import os, json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.ticker import PercentFormatter

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RES = os.path.join(ROOT, "retrain", "results_v2")
FIG = os.path.join(ROOT, "figures_v2")
os.makedirs(FIG, exist_ok=True)

BLUE, ORANGE, GREEN, PURPLE, OLIVE = "#2f6f9f", "#c8642f", "#1f8f5f", "#8f4f9f", "#8a7a1a"
CAT = [BLUE, ORANGE, GREEN, PURPLE, OLIVE]
SURFACE = "#fcfcfb"
INK, INK2, MUTED = "#1a1a1a", "#4a4a4a", "#8a8a8a"

plt.rcParams.update({
    "figure.facecolor": SURFACE, "axes.facecolor": SURFACE, "savefig.facecolor": SURFACE,
    "font.size": 9.5, "axes.titlesize": 10.5, "axes.labelsize": 9.5,
    "axes.edgecolor": "#cccccc", "axes.linewidth": 0.8,
    "axes.spines.top": False, "axes.spines.right": False,
    "text.color": INK, "axes.labelcolor": INK2, "xtick.color": INK2, "ytick.color": INK2,
    "grid.color": "#e6e6e6", "grid.linewidth": 0.7,
    "legend.frameon": False, "figure.dpi": 200, "savefig.bbox": "tight",
})

PRETTY = {
    "A_cost_weighted": "Cost-weighted", "B_unweighted": "Unweighted",
    "D_mlp": "MLP", "E_gbm": "GBM", "SVM": "SVM", "RF": "Random forest",
    "LSTM": "LSTM", "CQL": "CQL", "KNN": "k-NN",
    "ThresholdRule": "Threshold rule", "CUSUM": "CUSUM",
}


def _label_bars(ax, bars, vals, fmt="{:.3f}", dy=0.012, rot=0, fs=7.2):
    span = ax.get_ylim()[1] - ax.get_ylim()[0]
    for b, v in zip(bars, vals):
        ax.text(b.get_x() + b.get_width() / 2, b.get_height() + dy * span,
                fmt.format(v), ha="center", va="bottom", fontsize=fs,
                color=INK2, rotation=rot)


# ---------------------------------------------------------------- LOCO
def fig_loco():
    df = pd.read_csv(os.path.join(RES, "v2_loco.csv"))
    classes = ["Smoke", "Mixture"]
    models = [m for m in PRETTY if m in set(df.model)]
    fig, axes = plt.subplots(1, 2, figsize=(11.2, 4.1))

    # (a) miss rate, LOG scale -- the linear axis in the original clipped an
    # 18.7% bar to look identical to a 0.4% one.
    ax = axes[0]
    w = 0.38
    floor = 5e-5
    for j, cls in enumerate(classes):
        sub = df[df.held_out == cls].set_index("model")
        vals = [max(float(sub.loc[m, "miss_rate_mean"]), 0.0) if m in sub.index else np.nan
                for m in models]
        x = np.arange(len(models)) + (j - 0.5) * w
        plotted = [v if v > 0 else floor for v in vals]
        b = ax.bar(x, plotted, w * 0.92, color=CAT[j], label=cls,
                   edgecolor=SURFACE, linewidth=1.2, zorder=3)
        for bi, v in zip(b, vals):
            ax.text(bi.get_x() + bi.get_width() / 2, bi.get_height() * 1.25,
                    ("0" if v == 0 else f"{100*v:.2f}%"), ha="center", va="bottom",
                    fontsize=7, color=INK2)
    ax.set_yscale("log")
    ax.set_ylim(floor * 0.7, 0.6)
    ax.set_yticks([1e-4, 1e-3, 1e-2, 1e-1])
    ax.set_yticklabels(["0.01%", "0.1%", "1%", "10%"])
    ax.set_xticks(np.arange(len(models)))
    ax.set_xticklabels([PRETTY[m] for m in models], rotation=28, ha="right")
    ax.set_ylabel("Missed-hazard rate (log)")
    ax.set_title("(a)  Missed-hazard rate on the unseen class", loc="left")
    ax.grid(axis="y", zorder=0)
    ax.legend(title="Held-out class", ncol=2, loc="lower center",
              bbox_to_anchor=(0.5, 1.02), fontsize=8.5, title_fontsize=8.5)

    # (b) escalation adequacy
    ax = axes[1]
    for j, cls in enumerate(classes):
        sub = df[df.held_out == cls].set_index("model")
        vals = [float(sub.loc[m, "escalation_mean"]) if m in sub.index else np.nan for m in models]
        err = [float(sub.loc[m, "escalation_std"]) if m in sub.index else 0 for m in models]
        x = np.arange(len(models)) + (j - 0.5) * w
        b = ax.bar(x, vals, w * 0.92, color=CAT[j], label=cls,
                   edgecolor=SURFACE, linewidth=1.2, zorder=3)
        ax.errorbar(x, vals, yerr=err, fmt="none", ecolor=INK2, elinewidth=0.9,
                    capsize=2.2, zorder=4)
        for bi, v in zip(b, vals):
            ax.text(bi.get_x() + bi.get_width() / 2, bi.get_height() + 0.025,
                    f"{v:.2f}", ha="center", va="bottom", fontsize=7, color=INK2)
    ax.set_ylim(0, 1.16)
    ax.yaxis.set_major_formatter(PercentFormatter(1.0))
    ax.set_xticks(np.arange(len(models)))
    ax.set_xticklabels([PRETTY[m] for m in models], rotation=28, ha="right")
    ax.set_ylabel("Escalation to alarm-grade action (a ≥ 3)")
    ax.set_title("(b)  Escalation adequacy on the unseen class", loc="left")
    ax.grid(axis="y", zorder=0)
    ax.legend(title="Held-out class", ncol=2, loc="lower center",
              bbox_to_anchor=(0.5, 1.02), fontsize=8.5, title_fontsize=8.5)

    fig.text(0.005, -0.10, "Bars drawn at the floor of panel (a) are exactly zero. "
             "Seven of eight models bound their missed-hazard rate on unseen Mixture below 2.9%, "
             "yet escalate between 0.5% and 100% of the same windows.",
             ha="left", fontsize=7.8, color=MUTED, style="italic")
    fig.savefig(os.path.join(FIG, "fig_loco.png"))
    plt.close(fig)
    print("wrote fig_loco.png")


# ------------------------------------------------------------ cost sweep
def fig_costsweep():
    df = pd.read_csv(os.path.join(RES, "v2_costsweep.csv"))
    df = df[df.cost_ratio != "label_function"].copy()
    df["C"] = [int(s.split(":")[0]) for s in df.cost_ratio]
    df = df.sort_values("C")
    fig, ax = plt.subplots(figsize=(7.4, 4.2))
    ax.plot(df.C, df.decision_acc_mean, "-o", color=BLUE, lw=2, ms=7,
            label="Decision accuracy", zorder=3)
    ax.fill_between(df.C, df.decision_acc_mean - df.decision_acc_std,
                    df.decision_acc_mean + df.decision_acc_std,
                    color=BLUE, alpha=0.16, lw=0, zorder=2)
    ax.plot(df.C, df.escalation_mean, "-s", color=GREEN, lw=2, ms=6.5,
            label="Escalation adequacy", zorder=3)
    ax.plot(df.C, df.miss_rate_mean, "-^", color=ORANGE, lw=2, ms=6.5,
            label="Missed-hazard rate", zorder=3)
    best = df.loc[df.decision_acc_mean.idxmax()]
    ax.annotate(f"accuracy peak\nC = {int(best.C)}:1", (best.C, best.decision_acc_mean),
                textcoords="offset points", xytext=(4, 20), fontsize=8, color=INK2,
                arrowprops=dict(arrowstyle="-", color=MUTED, lw=0.8))
    dep = df[df.C == 8].iloc[0]
    ax.annotate("deployed\nC = 8:1", (8, dep.decision_acc_mean),
                textcoords="offset points", xytext=(6, -32), fontsize=8, color=INK2,
                arrowprops=dict(arrowstyle="-", color=MUTED, lw=0.8))
    ax.text(df.C.iloc[-1], df.miss_rate_mean.iloc[-1] + 0.03,
            "missed-hazard rate is flat at this level for every ratio",
            ha="right", fontsize=7.6, color=MUTED, style="italic")
    ax.set_xscale("log"); ax.set_xticks(df.C.tolist())
    ax.set_xticklabels([f"{c}:1" for c in df.C], fontsize=8.5)
    ax.set_ylim(-0.04, 1.12)
    ax.yaxis.set_major_formatter(PercentFormatter(1.0))
    ax.set_xlabel("Cost ratio  C = c_miss : c_false")
    ax.set_ylabel("Rate")
    ax.set_title("Cost asymmetry changes accuracy, not safety behavior", loc="left")
    ax.grid(axis="y", zorder=0); ax.legend(loc="center left", fontsize=8.6)
    fig.savefig(os.path.join(FIG, "fig_costsweep.png"))
    plt.close(fig)
    print("wrote fig_costsweep.png")


# ------------------------------------------------------------------ zoo
def fig_zoo():
    df = pd.read_csv(os.path.join(RES, "v2_zoo.csv"))
    df = df[df.model != "CUSUM"]           # two-class; accuracy not comparable
    df = df.sort_values("decision_acc_mean", ascending=False)
    fig, ax = plt.subplots(figsize=(8.4, 4.0))
    names = [PRETTY.get(m, m) for m in df.model]
    cols = [ORANGE if m == "A_cost_weighted" else "#9fb4c4" for m in df.model]
    x = np.arange(len(df))
    b = ax.bar(x, df.decision_acc_mean, 0.66, color=cols,
               edgecolor=SURFACE, linewidth=1.2, zorder=3)
    ax.errorbar(x, df.decision_acc_mean, yerr=df.decision_acc_std, fmt="none",
                ecolor=INK2, elinewidth=1.0, capsize=3, zorder=4)
    for bi, v, sd in zip(b, df.decision_acc_mean, df.decision_acc_std):
        ax.text(bi.get_x() + bi.get_width() / 2, v + sd + 0.007, f"{v:.3f}",
                ha="center", va="bottom", fontsize=7.4, color=INK2)
    lo = float(df.decision_acc_mean.min()); hi = float(df.decision_acc_mean.max())
    ax.axhspan(lo, hi, color=MUTED, alpha=0.10, zorder=1)
    ax.set_xticks(x); ax.set_xticklabels(names, rotation=24, ha="right")
    ax.set_ylim(min(0.80, lo - 0.06), 1.02)
    ax.yaxis.set_major_formatter(PercentFormatter(1.0))
    ax.set_ylabel("Decision accuracy")
    ax.set_title(f"All models lie within {100*(hi-lo):.1f} accuracy points — "
                 "this design cannot rank them", loc="left")
    ax.grid(axis="y", zorder=0)
    ax.text(0.995, 0.04, "cost-weighted policy highlighted", transform=ax.transAxes,
            ha="right", fontsize=7.4, color=MUTED, style="italic")
    fig.savefig(os.path.join(FIG, "fig_zoo.png"))
    plt.close(fig)
    print("wrote fig_zoo.png")


# ------------------------------------------------------------ perturbation
def fig_perturb():
    df = pd.read_csv(os.path.join(RES, "v2_perturb.csv"))
    kinds = [("noise", "Additive noise (σ)"), ("drift", "Calibration drift (±)"),
             ("dropout", "Channel dropout (k sensors)")]
    metrics = [("decision_acc_mean", "Decision accuracy"),
               ("escalation_mean", "Escalation adequacy"),
               ("fa_per_clean_mean", "High-severity false-alarm rate")]
    models = [m for m in ["A_cost_weighted", "D_mlp", "E_gbm", "RF", "ThresholdRule"]
              if m in set(df.model)]          # 5 series: hues assigned, never cycled
    fig, axes = plt.subplots(3, 3, figsize=(12.4, 9.2), sharex="col")
    for r, (mk, mlabel) in enumerate(metrics):
        for c, (kind, klabel) in enumerate(kinds):
            ax = axes[r, c]
            for i, m in enumerate(models):
                sub = df[(df.model == m) & (df.perturbation.isin([kind, "clean"]))]
                sub = sub.sort_values("level")
                ax.plot(sub.level, sub[mk], "-o", ms=4.2, lw=1.8,
                        color=CAT[i % len(CAT)], label=PRETTY[m], zorder=3)
            ax.grid(axis="y", zorder=0)
            ax.yaxis.set_major_formatter(PercentFormatter(1.0))
            ax.set_ylim(-0.05, 1.08)   # one shared scale per row
            if r == 0:
                ax.set_title(klabel, loc="left", fontsize=10)
            if r == 2:
                ax.set_xlabel(klabel)
            if c == 0:
                ax.set_ylabel(mlabel)
    axes[2, 1].text(0.5, 0.90, "peak false-alarm rate under drift is 0.06%",
                    transform=axes[2, 1].transAxes, ha="center", fontsize=8,
                    color=MUTED, style="italic")
    h, l = axes[0, 0].get_legend_handles_labels()
    fig.legend(h, l, ncol=5, loc="upper center", bbox_to_anchor=(0.5, 0.955), fontsize=9)
    fig.suptitle("Degradation under perturbation: accuracy, escalation and false alarms "
                 "must be read together", x=0.005, y=0.995, ha="left", fontsize=11.5)
    fig.tight_layout(rect=(0, 0, 1, 0.935))
    fig.savefig(os.path.join(FIG, "fig_perturb.png"))
    plt.close(fig)
    print("wrote fig_perturb.png")


# --------------------------------------------------------------- ablation
def fig_ablation():
    df = pd.read_csv(os.path.join(RES, "v2_ablation.csv")).sort_values("decision_acc_mean")
    fig, ax = plt.subplots(figsize=(7.8, 3.9))
    y = np.arange(len(df))
    b = ax.barh(y, df.decision_acc_mean, 0.62, xerr=df.decision_acc_std,
                color=[ORANGE if s == "full_22" else "#9fb4c4" for s in df.state],
                error_kw=dict(ecolor=INK2, elinewidth=1.0, capsize=3),
                edgecolor=SURFACE, linewidth=1.2, zorder=3)
    for bi, v, sd, d in zip(b, df.decision_acc_mean, df.decision_acc_std, df.delta_pp_vs_full):
        ax.text(1.045, bi.get_y() + bi.get_height() / 2,
                f"{v:.3f}" + ("  (reference)" if abs(d) < 1e-9 else f"   {d:+.2f} pp"),
                va="center", ha="left", fontsize=7.8, color=INK2)
    ax.set_yticks(y)
    ax.set_yticklabels([s.replace("_", " ") for s in df.state])
    ax.set_xlim(0, 1.42)
    ax.set_xticks([0, .2, .4, .6, .8, 1.0])
    ax.xaxis.set_major_formatter(PercentFormatter(1.0))
    ax.set_xlabel("Decision accuracy")
    ax.set_title("Feature ablation moves accuracy; missed-hazard rate (0) and\n"
                 "escalation adequacy (1.00) are unchanged in every condition", loc="left")
    ax.grid(axis="x", zorder=0)
    fig.savefig(os.path.join(FIG, "fig_ablation.png"))
    plt.close(fig)
    print("wrote fig_ablation.png")


# ---------------------------------------------------------------- anomaly
def fig_anomaly():
    a = json.load(open(os.path.join(RES, "v2_anomaly.json")))
    fig, axes = plt.subplots(1, 2, figsize=(10.6, 4.0))
    ax = axes[0]
    cls = ["NoGas", "Perfume", "Mixture", "Smoke"]
    vals = [a["per_class_mean_recon"][c] for c in cls]
    b = ax.bar(np.arange(4), vals, 0.6, color=[BLUE, OLIVE, PURPLE, ORANGE],
               edgecolor=SURFACE, linewidth=1.2, zorder=3)
    for bi, v in zip(b, vals):
        ax.text(bi.get_x() + bi.get_width() / 2, v * 1.15, f"{v:.2f}",
                ha="center", va="bottom", fontsize=7.6, color=INK2)
    ax.set_yscale("log"); ax.set_xticks(np.arange(4)); ax.set_xticklabels(cls)
    ax.set_ylabel("Mean reconstruction error (log)")
    ax.set_title("(a)  Anomaly score by class", loc="left")
    ax.grid(axis="y", zorder=0)
    ax.set_ylim(0.3, 900)
    ax.text(0.02, 0.90, "hazardous classes score highest, but not in\nseverity order: Mixture carries the higher\ntarget severity yet scores below Smoke",
            transform=ax.transAxes, ha="left", va="top", fontsize=7.2, color=MUTED, style="italic")

    ax = axes[1]
    labels = ["In-sample\n(as published)", "Held-out\n(this work)"]
    auc = [a["in_sample"]["auc"], a["auc_mean"]]
    tpr = [a["in_sample"]["tpr"], a["tpr_mean"]]
    fpr = [a["in_sample"]["fpr"], a["fpr_mean"]]
    x = np.arange(2); w = 0.26
    for i, (v, lab, col) in enumerate([(auc, "ROC-AUC", BLUE), (tpr, "TPR", GREEN), (fpr, "FPR", ORANGE)]):
        bb = ax.bar(x + (i - 1) * w, v, w * 0.9, color=col, label=lab,
                    edgecolor=SURFACE, linewidth=1.2, zorder=3)
        for bi, vv in zip(bb, v):
            ax.text(bi.get_x() + bi.get_width() / 2, vv + 0.018, f"{vv:.3f}",
                    ha="center", va="bottom", fontsize=7.2, color=INK2)
    ax.set_xticks(x); ax.set_xticklabels(labels)
    ax.set_ylim(0, 1.30); ax.set_ylabel("Rate")
    ax.set_title("(b)  Threshold fitted on its own sample vs. held out", loc="left")
    ax.grid(axis="y", zorder=0)
    ax.legend(fontsize=8.4, ncol=3, loc="upper center", bbox_to_anchor=(0.5, 1.02))
    fig.tight_layout()
    fig.savefig(os.path.join(FIG, "fig_anomaly.png"))
    plt.close(fig)
    print("wrote fig_anomaly.png")




# ======================= additional figures (v3) =======================
CRIT, WARN_, GOOD = "#a83226", "#bf8a12", "#1f7a52"   # status palette, validated


def fig_protocol():
    """Schematic of the corpus layout and the block-wise holdout."""
    fig, ax = plt.subplots(figsize=(10.4, 3.2))
    classes = ["NoGas", "Smoke", "Mixture", "Perfume"]
    n = 1581
    for i, c in enumerate(classes):
        y = 3 - i
        ax.add_patch(plt.Rectangle((0, y - 0.32), n, 0.64, color="#dfe6ec",
                                   ec=SURFACE, lw=1.5, zorder=2))
        start = int(0.42 * n)
        ax.add_patch(plt.Rectangle((start - 20, y - 0.32), 20, 0.64, color=WARN_,
                                   ec=SURFACE, lw=1.0, zorder=3))
        ax.add_patch(plt.Rectangle((start, y - 0.32), int(0.20 * n), 0.64, color=BLUE,
                                   ec=SURFACE, lw=1.0, zorder=3))
        ax.add_patch(plt.Rectangle((start + int(0.20 * n), y - 0.32), 20, 0.64, color=WARN_,
                                   ec=SURFACE, lw=1.0, zorder=3))
        ax.text(-30, y, c, ha="right", va="center", fontsize=9.5, color=INK)
    ax.annotate("held-out block\n(20%, position drawn from the run seed)",
                (int(0.52 * n), 3.42), ha="center", fontsize=8, color=INK2)
    from matplotlib.patches import Patch
    ax.legend(handles=[Patch(color="#dfe6ec", label="training windows"),
                       Patch(color=WARN_, label="20-window embargo"),
                       Patch(color=BLUE, label="held-out test windows")],
              ncol=3, loc="lower center", bbox_to_anchor=(0.5, -0.52), fontsize=8.5)
    ax.set_xlim(-300, n + 30); ax.set_ylim(-0.55, 4.15)
    ax.set_xticks([0, 400, 800, 1200, 1581])
    ax.set_xlabel("window index within each class block (1,581 windows per class)")
    ax.set_yticks([]); ax.spines["left"].set_visible(False); ax.spines["bottom"].set_visible(False)
    ax.set_title("Corpus layout and the leakage-controlled split", loc="left")
    fig.savefig(os.path.join(FIG, "fig_protocol.png")); plt.close(fig)
    print("wrote fig_protocol.png")


def fig_dissociation():
    """In-distribution accuracy against out-of-distribution safety."""
    z = pd.read_csv(os.path.join(RES, "v2_zoo.csv")).set_index("model")
    l = pd.read_csv(os.path.join(RES, "v2_loco.csv"))
    fig, axes = plt.subplots(1, 2, figsize=(11.0, 4.3))
    for ax, (cls, ycol, ylab, logy) in zip(
            axes, [("Smoke", "miss_rate_mean", "Missed-hazard rate on unseen Smoke", True),
                   ("Mixture", "escalation_mean", "Escalation adequacy on unseen Mixture", False)]):
        sub = l[l.held_out == cls]
        xs, ys, names = [], [], []
        for _, r in sub.iterrows():
            if r.model in z.index:
                xs.append(z.loc[r.model, "decision_acc_mean"]); ys.append(r[ycol]); names.append(PRETTY[r.model])
        floor = 8e-5
        yp = [max(v, floor) if logy else v for v in ys]
        ax.scatter(xs, yp, s=64, color=BLUE, edgecolor=SURFACE, linewidth=1.2, zorder=3)
        order = np.argsort(yp)
        for rank, idx in enumerate(order):          # alternate offsets to declutter
            dx, dy = (8, 4) if rank % 2 == 0 else (8, -11)
            if names[idx] in ("Random forest", "GBM"):
                dx, dy = (-8, 6); ha = "right"
            else:
                ha = "left"
            ax.annotate(names[idx], (xs[idx], yp[idx]), textcoords="offset points",
                        xytext=(dx, dy), fontsize=7.8, color=INK2, ha=ha)
        if logy:
            ax.set_yscale("log"); ax.set_ylim(floor * 0.6, 0.4)
            ax.set_yticks([1e-4, 1e-3, 1e-2, 1e-1]); ax.set_yticklabels(["0 (floor)", "0.1%", "1%", "10%"])
        else:
            ax.set_ylim(-0.06, 1.14); ax.yaxis.set_major_formatter(PercentFormatter(1.0))
        r = np.corrcoef(xs, ys)[0, 1]
        ax.set_xlim(0.921, 0.990)
        ax.xaxis.set_major_formatter(PercentFormatter(1.0))
        ax.set_xlabel("In-distribution decision accuracy")
        ax.set_ylabel(ylab)
        ax.set_title(f"Pearson r = {r:+.2f}", loc="left", fontsize=9.5, color=INK2)
        ax.grid(zorder=0)
    fig.suptitle("In-distribution accuracy does not order out-of-distribution safety",
                 x=0.005, ha="left", fontsize=11.5)
    fig.tight_layout(rect=(0, 0, 1, 0.95))
    fig.savefig(os.path.join(FIG, "fig_dissociation.png")); plt.close(fig)
    print("wrote fig_dissociation.png")


def fig_disposition():
    """Where hazardous windows actually go: Monitor / sub-alarm / alarm-grade."""
    l = pd.read_csv(os.path.join(RES, "v2_loco.csv"))
    models = [m for m in PRETTY if m in set(l.model)]
    fig, axes = plt.subplots(1, 2, figsize=(11.4, 4.3), sharey=True)
    for ax, cls in zip(axes, ["Smoke", "Mixture"]):
        sub = l[l.held_out == cls].set_index("model")
        miss = np.array([sub.loc[m, "miss_rate_mean"] for m in models])
        und = np.array([sub.loc[m, "under_escalation_mean"] for m in models])
        esc = np.array([sub.loc[m, "escalation_mean"] for m in models])
        x = np.arange(len(models))
        ax.bar(x, esc, 0.62, color=GOOD, label="Alarm-grade (a ≥ 3)", ec=SURFACE, lw=1.4, zorder=3)
        ax.bar(x, und, 0.62, bottom=esc, color=WARN_, label="Sub-alarm (a ∈ {1,2})", ec=SURFACE, lw=1.4, zorder=3)
        ax.bar(x, miss, 0.62, bottom=esc + und, color=CRIT, label="Monitor (a = 0)", ec=SURFACE, lw=1.4, zorder=3)
        for xi, e, u in zip(x, esc, und):
            if e > 0.06:
                ax.text(xi, e / 2, f"{e:.2f}", ha="center", va="center", fontsize=7.4, color="white")
            if u > 0.10:
                ax.text(xi, e + u / 2, f"{u:.2f}", ha="center", va="center", fontsize=7.4, color="white")
        ax.set_xticks(x); ax.set_xticklabels([PRETTY[m] for m in models], rotation=28, ha="right")
        ax.set_ylim(0, 1.03); ax.yaxis.set_major_formatter(PercentFormatter(1.0))
        ax.set_title(f"Held-out {cls}", loc="left")
        ax.grid(axis="y", zorder=0)
    axes[0].set_ylabel("Share of hazardous windows")
    h, lb = axes[0].get_legend_handles_labels()
    fig.legend(h[::-1], lb[::-1], ncol=3, loc="upper center", bbox_to_anchor=(0.5, 0.955), fontsize=9)
    fig.suptitle("What actually happens to a hazardous window the model has never seen",
                 x=0.005, y=0.995, ha="left", fontsize=11.5)
    fig.tight_layout(rect=(0, 0, 1, 0.90))
    fig.savefig(os.path.join(FIG, "fig_disposition.png")); plt.close(fig)
    print("wrote fig_disposition.png")


def fig_alarmburden():
    """False-alarm rate expressed as alarms per hour per detector."""
    p = pd.read_csv(os.path.join(RES, "v2_perturb.csv"))
    models = [m for m in ["A_cost_weighted", "D_mlp", "E_gbm", "RF", "ThresholdRule"] if m in set(p.model)]
    fig, ax = plt.subplots(figsize=(8.6, 4.6))
    for i, m in enumerate(models):
        sub = p[(p.model == m) & (p.perturbation.isin(["dropout", "clean"]))].sort_values("level")
        y = np.maximum(sub.fa_per_clean_mean.values * 1800.0, 0.05)
        ax.plot(sub.level, y, "-o", ms=5.5, lw=2, color=CAT[i], label=PRETTY[m], zorder=3)
    ax.axhline(6, color=CRIT, lw=1.6, ls="--", zorder=4)
    ax.text(0.06, 2.0, "EEMUA 191 long-term average envelope for an\nentire operator position (about 6 alarms h⁻¹)",
            ha="left", va="center", fontsize=8, color=CRIT)
    ax.set_yscale("log"); ax.set_ylim(0.04, 4000)
    ax.set_yticks([0.1, 1, 6, 10, 100, 1000])
    ax.set_yticklabels(["0 (floor)", "1", "6", "10", "100", "1,000"])
    ax.set_xlabel("Sensor channels removed (k of 7)")
    ax.set_ylabel("High-severity alarms per hour, per detector (log)")
    ax.set_title("One lost sensor is enough to swamp an operator", loc="left")
    ax.grid(axis="y", zorder=0); ax.legend(fontsize=8.6, loc="lower right", ncol=2)
    fig.savefig(os.path.join(FIG, "fig_alarmburden.png")); plt.close(fig)
    print("wrote fig_alarmburden.png")


if __name__ == "__main__":
    import sys
    todo = sys.argv[1:] or ["protocol", "anomaly", "zoo", "dissociation", "loco", "disposition", "costsweep", "ablation", "perturb", "alarmburden"]
    for t in todo:
        globals()["fig_" + t]()
