"""Fig. 3, rebuilt as an acquisition schematic rather than a block diagram.

The supervisor's note on the previous version was that the paper leans on
box-and-arrow diagrams where a picture of the actual measurement would say more.
This replaces the pipeline flowchart with three panels that show the thing being
measured, the data it produces, and what does and does not enter the quantity the
decision component reads.

Panel (a) is a schematic of the acquisition arrangement as the corpus authors
describe it: a seven-element MQ array and a Seek Compact thermal camera observing
the same scene, logged together every 2 s. It is a drawing, not a photograph of
the rig, and it carries no dimension that the corpus does not state.

Panel (b) is real. Twenty consecutive rows of the released corpus, one Smoke
episode, all seven channels, which is exactly the window X_t the pipeline reads.

Panel (c) is the decision state of Eq. 1, drawn as the 22 cells it actually has,
grouped 7 / 7 / 7 / 1. The thermal branch has no cell in it, which is the one
structural fact the old Fig. 3 existed to convey.

    python3 -m retrain.make_fig_setup
"""
import os
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, Rectangle, Circle, FancyArrowPatch, Polygon

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FIG = os.path.join(ROOT, "figures_v2")
DATA = os.path.join(ROOT, "data", "Gas_Sensors_Measurements.csv")

BLUE, ORANGE, GREEN, PURPLE, OLIVE = "#2f6f9f", "#c8642f", "#1f8f5f", "#8f4f9f", "#8a7a1a"
SURFACE = "#fcfcfb"
INK, INK2, MUTED = "#1a1a1a", "#4a4a4a", "#8a8a8a"
CHAN = ["MQ2", "MQ3", "MQ5", "MQ6", "MQ7", "MQ8", "MQ135"]

plt.rcParams.update({
    "figure.facecolor": SURFACE, "axes.facecolor": SURFACE, "savefig.facecolor": SURFACE,
    "font.size": 10.5, "axes.labelsize": 10.5,
    "xtick.labelsize": 9.5, "ytick.labelsize": 9.5,
    "axes.edgecolor": "#cccccc", "axes.linewidth": 0.8,
    "axes.spines.top": False, "axes.spines.right": False,
    "text.color": INK, "axes.labelcolor": INK2, "xtick.color": INK2, "ytick.color": INK2,
    "grid.color": "#e6e6e6", "grid.linewidth": 0.7,
    "legend.frameon": False, "figure.dpi": 300, "savefig.bbox": "tight",
})


def panel_setup(ax):
    """Schematic of the arrangement the corpus describes. Not to scale."""
    ax.set_xlim(0, 10)
    ax.set_ylim(0, 6.6)
    ax.axis("off")

    ax.add_patch(FancyBboxPatch((0.35, 1.25), 9.3, 4.55,
                                boxstyle="round,pad=0.05,rounding_size=0.2",
                                fc="#ffffff", ec="#c4c4c4", lw=1.1, zorder=1))
    ax.text(0.62, 5.48, "test enclosure, ambient laboratory conditions",
            fontsize=8.6, color=MUTED, va="center", zorder=6)

    ax.add_patch(Rectangle((1.30, 1.62), 0.80, 0.40, fc="#ded9cf", ec="#b9b2a4",
                           lw=0.9, zorder=3))
    ax.text(1.70, 1.50, "source", fontsize=8.4, color=INK2, ha="center",
            va="top", zorder=6)
    for k, (w, a) in enumerate(zip([0.22, 0.30, 0.38, 0.46], [0.40, 0.31, 0.23, 0.15])):
        y = np.linspace(2.05, 4.90, 140)
        x = 1.70 + w * np.sin(1.5 * y + 0.6 * k) * (y - 2.05) / 2.85
        ax.plot(x, y, color=ORANGE, lw=1.5, alpha=a, zorder=2, solid_capstyle="round")
    ax.text(2.42, 4.92, "analyte released into still air", fontsize=8.4,
            color=ORANGE, ha="left", va="center", zorder=6)

    bx, by = 4.20, 1.72
    ax.add_patch(FancyBboxPatch((bx, by), 2.35, 0.95,
                                boxstyle="round,pad=0.03,rounding_size=0.08",
                                fc="#e7eef5", ec=BLUE, lw=1.2, zorder=3))
    for i in range(7):
        cx = bx + 0.24 + i * 0.31
        ax.add_patch(Circle((cx, by + 0.58), 0.105, fc="#ffffff", ec=BLUE, lw=1.0, zorder=4))
        ax.add_patch(Circle((cx, by + 0.58), 0.045, fc=BLUE, ec="none", zorder=5))
    ax.text(bx + 1.17, by + 0.21, "7 MQ elements", fontsize=8.2, color=BLUE,
            ha="center", va="center", zorder=6)
    ax.text(bx + 1.17, by - 0.14, "MOX array", fontsize=9.0, color=INK2,
            ha="center", va="top", zorder=6)

    cx0, cy0 = 7.55, 3.55
    ax.add_patch(Polygon([[cx0 - 0.20, cy0 + 0.41], [2.95, cy0 + 1.30],
                          [2.95, cy0 - 1.10]], closed=True, fc=PURPLE, alpha=0.07,
                         ec="none", zorder=2))
    ax.add_patch(FancyBboxPatch((cx0, cy0), 1.25, 0.82,
                                boxstyle="round,pad=0.03,rounding_size=0.1",
                                fc="#f0e9f3", ec=PURPLE, lw=1.2, zorder=4))
    ax.add_patch(Circle((cx0 - 0.02, cy0 + 0.41), 0.20, fc="#ffffff", ec=PURPLE,
                        lw=1.2, zorder=5))
    ax.add_patch(Circle((cx0 - 0.02, cy0 + 0.41), 0.09, fc=PURPLE, ec="none", zorder=6))
    ax.text(cx0 + 0.62, cy0 - 0.10, "thermal camera", fontsize=9.0, color=INK2,
            ha="center", va="top", zorder=6)
    ax.text(cx0 + 0.62, cy0 + 1.00, "206 x 156 frame", fontsize=8.2, color=PURPLE,
            ha="center", va="bottom", zorder=6)

    ax.text(5.0, 0.72, "both channels logged together once every 2 s",
            fontsize=8.8, color=INK2, ha="center", va="center", zorder=6)

    ax.text(0.0, 6.35, "(a)", fontsize=11, color=INK, fontweight="bold", va="center")


def panel_window(ax):
    """Twenty real consecutive rows of one Smoke episode: the window X_t."""
    df = pd.read_csv(DATA)
    seg = df[df["Gas"] == "Smoke"].iloc[120:140]
    t = np.arange(20)
    for i, c in enumerate(CHAN):
        v = seg[c].to_numpy(dtype=float)
        ax.plot(t, v, lw=1.35, color=plt.cm.viridis(i / 6.0 * 0.82 + 0.05),
                marker="o", ms=2.3, label=c)
    ax.set_xlabel("step within the window, 2 s apart")
    ax.set_ylabel("raw sensor reading")
    ax.set_xticks([0, 5, 10, 15, 19])
    ax.grid(axis="y", alpha=0.6)
    ax.legend(ncol=4, fontsize=7.6, loc="upper left", bbox_to_anchor=(0.0, 1.30),
              handlelength=1.3, columnspacing=1.0, handletextpad=0.4)
    ax.text(-0.14, 1.34, "(b)", fontsize=11, color=INK, fontweight="bold",
            transform=ax.transAxes, va="center")
    ax.text(0.985, 0.04, r"$X_t \in \mathbb{R}^{20\times 7}$", transform=ax.transAxes,
            fontsize=10, color=INK2, ha="right", va="bottom")


def panel_state(ax):
    """The 22 cells of Eq. 1, and the one branch that contributes none of them."""
    ax.set_xlim(0, 10)
    ax.set_ylim(0, 4.3)
    ax.axis("off")

    groups = [("current reading", 7, BLUE), ("per-sensor delta", 7, GREEN),
              ("per-sensor SD", 7, OLIVE), ("normalized anomaly", 1, ORANGE)]
    x0_all = 0.55
    x = x0_all
    y, w, h, gap = 2.85, 0.30, 0.55, 0.22
    for name, n, col in groups:
        gx0 = x
        for _ in range(n):
            ax.add_patch(Rectangle((x, y), w, h, fc=col, alpha=0.20, ec=col, lw=0.9))
            x += w + 0.042
        gx1 = x - 0.042
        ax.text((gx0 + gx1) / 2, y - 0.14, name, fontsize=8.3, color=INK2,
                ha="center", va="top")
        x += gap
    x_end = x - gap
    ax.text(x0_all, y + h + 0.26, r"decision state $\varphi_t \in \mathbb{R}^{22}$",
            fontsize=10.5, color=INK, va="bottom")

    tw = 2.75
    ax.add_patch(FancyBboxPatch((x0_all, 0.55), tw, 0.72,
                                boxstyle="round,pad=0.04,rounding_size=0.1",
                                fc="#f0e9f3", ec=PURPLE, lw=1.1))
    ax.text(x0_all + tw / 2, 0.91, "thermal image  $I_t$", fontsize=9.6,
            color=INK2, ha="center", va="center")
    ax.annotate("", xy=(x0_all + tw / 2, 2.05), xytext=(x0_all + tw / 2, 1.33),
                arrowprops=dict(arrowstyle="-", color=PURPLE, lw=1.3,
                                linestyle=(0, (3, 2))))
    ax.plot([x0_all + tw / 2], [2.17], marker="x", ms=10, mew=2.2, color=PURPLE)
    ax.text(x0_all + tw / 2 + 0.22, 2.17, "contributes no cell", fontsize=8.8,
            color=PURPLE, ha="left", va="center")

    ladder = ["0 Monitor", "1 Sample", "2 Verify", "3 Alarm", "4 ESD assess"]
    lx = x_end - 4.95
    for i, lab in enumerate(ladder):
        xx = lx + i * 0.99
        ax.add_patch(Rectangle((xx, 0.62), 0.86, 0.34,
                               fc=plt.cm.YlOrRd(0.18 + 0.62 * i / 4.0), ec="none"))
        ax.text(xx + 0.43, 0.79, lab, fontsize=8.4, color="#2a2a2a",
                ha="center", va="center")
    ax.text(lx + 2.47, 1.34, "action $a_t$, one rung of five", fontsize=9.6,
            color=INK, ha="center", va="bottom")
    ax.add_patch(FancyArrowPatch(((x0_all + x_end) / 2, 2.62),
                                 (lx + 2.47, 1.66),
                                 connectionstyle="arc3,rad=-0.10",
                                 arrowstyle="-|>", mutation_scale=12,
                                 color="#9a9a9a", lw=1.2))
    ax.text((x0_all + x_end) / 2 + 0.18, 2.20, "all 22 cells", fontsize=8.6,
            color=MUTED, ha="left", va="center")

    ax.text(0.0, 4.05, "(c)", fontsize=11, color=INK, fontweight="bold", va="center")


def main():
    fig = plt.figure(figsize=(11.5, 6.6))
    gs = fig.add_gridspec(2, 2, height_ratios=[1.18, 0.82], width_ratios=[1.04, 1.0],
                          hspace=0.40, wspace=0.22)
    ax_a = fig.add_subplot(gs[0, 0])
    ax_b = fig.add_subplot(gs[0, 1])
    ax_c = fig.add_subplot(gs[1, :])
    panel_setup(ax_a)
    panel_window(ax_b)
    panel_state(ax_c)
    out = os.path.join(FIG, "fig_setup.png")
    fig.savefig(out)
    plt.close(fig)
    print("wrote", out)


if __name__ == "__main__":
    main()
