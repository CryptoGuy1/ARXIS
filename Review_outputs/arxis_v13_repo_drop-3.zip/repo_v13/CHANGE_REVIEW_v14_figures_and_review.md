# What changed, and why

Three things this round: the figures, Fig. 1, and the numbers the critical review
flagged. The review was written against an earlier build, so two of its points no
longer apply: it praises the ARXIS title you asked to have removed, and it argues
for keeping the Fig. 3 you asked to have cut.

---

## Figures

**They were too small because they were drawn too big.** Word places an image at
the text width. The result figures were authored at 11.5 in, so Word halved them
and every label with them. Two other things compounded it: a tight bounding box
grows to contain anything that overflows a canvas, so one unwrapped footnote took
the leave-one-class-out figure from 6.90 in to 12.16 in; and no figure carried an
explicit placement width, so Pandoc capped them all at 5.83 in.

All 19 result figures are now drawn at 6.90 in and every figure is placed at
6.50 in, the full text width of a Letter page with 1 in margins. Base type is up
from 9.5 pt to 11 pt, which lands near 10.4 pt on the page, deliberately above
the 7 to 9 pt the model papers use, because these are read on screen.

**Figs. 5 to 9 and 12, which you named.** The alarm-boundary rule in Figs. 5 and
6 had its label sitting on the rung above it and on the box beside it; both now
have a clear band of their own, and Fig. 6's long boundary sentence is short
enough to sit inside the ladder, with the wording it carried already in the
body. Fig. 7's key sat on the top tick label. Fig. 8's key was wider than its
panel and its two callouts were one line-height apart. Fig. 9's protocol key
covered the panel title and is now set across the figure. Fig. 12 is described
below.

**Figs. 13 to 17, from the round before.** Three needed more than a type change.
Fig. 13 is now stacked, one panel per row: two panels across the page left about
a quarter inch per model, and an upright value label is wider than the gap
between the two bars of a pair, so the labels collided. Fig. 15 has two-line row
labels. Fig. 17 is set smaller in the cells and wider in the row labels. Figs. 14
and 16 needed only the larger type.

The supporting-information figures got the same treatment. The perception and
calibration figures are now two rows rather than three columns, for the same
reason as Fig. 13.

**Two defects surfaced while doing this.**

`spe_style.use_style` writes matplotlib's global rcParams, so whether a result
figure came out with the small diagram font depended on whether a block diagram
happened to be drawn earlier in the same run. Figures rendered differently
depending on call order. The diagrams now draw inside an `rc_context`, and
regenerating the set in reverse order reproduces every file byte for byte.

In the disposition figure the white value labels were wider than the bars they
sat in, so the parts outside the coloured segment were white on near-white and
invisible. They are upright now, and values that were never legible are legible.

### Overlapping text, checked by machine

Twenty-four figures is more than anyone re-reads by eye after every
regeneration, and reading them by eye is how the overlaps you found got shipped.
`check_figure_text.py` renders every figure and tests every pair of text
elements in it for real overlap. Two details make it trustworthy: it
reconstructs the true rotated box of each label rather than testing the
axis-aligned extent, so rotated tick labels that sit clear of one another on the
diagonal are not flagged; and it drops tick labels for ticks outside the axis
limits, which matplotlib keeps alive and which otherwise appear as phantom
collisions.

It found eleven figures with overlapping text on its first run, including four I
had not caught by eye. All twenty-four are clean now. The check runs under
`make figtext`, is part of `make check`, and `verify_v13.py` fails if it fails.
I confirmed it works by putting an overlap back into Fig. 10 and watching it be
reported.

A second check was added after you found "4  Recommend ESD assessment" running
out of its box in Fig. 6: a label centred in a box must stay inside it. The box
it belongs to is the smallest visible patch containing its centre, so a panel
frame is never mistaken for it, and a value label that merely happens to sit on
a bar is not checked. It caught the Fig. 6 overflow and one more I had not seen,
in Fig. 5.

The underlying fix is that those boxes are no longer sized by eye. `text_width`
measures a laid-out string in the axes' own units and `fit_fontsize` returns the
largest type at which every label fits a given width. Fig. 6 now derives its
ladder width and the position of the metric block from the measured text, and
Fig. 1 sizes its comparator, regime and metric boxes the same way. Putting the
old hard-coded width back makes the check fail, which is how I know it works.

One more fix is worth naming. Fig. 12 placed its point labels by comparing
display pixels against offsets in points, so two markers a fifth of an inch
apart tested as far enough and printed on top of each other. Labels are now
placed by their own rectangles, trying the right of the marker, then the left,
then higher and lower, with a bounds check that keeps them inside the axes.

Four gates were added in all: every figure must be authored between 6.4 and
7.2 in and placed at an explicit 6.50 in; no figure may have ink in its
outermost pixel rows, which is the signature of a label cut off at the canvas
edge; no figure may have overlapping text; and no label may sit outside the box
it is centred in.

**One figure retired.** `fig_edge`, a latency and thermal-throttling chart, was
generated but cited nowhere in either document, and the Limitations section
states plainly that no hardware evaluation was carried out, so a figure
asserting measured device timings had no place in the release. It is deleted and
gated absent, as `fig_architecture` was. Say the word if you want it back; the
driver is recoverable.

---

## Fig. 1

Rebuilt around the four frames you sent, one per class, in hazard order with the
action each maps to and span arrows marking where the hazard boundary falls. The
seven-channel MOX window sits beside them, labelled as the only evidence the
decision component receives. Below that are the protocol, the eleven comparators
and the evaluation regimes.

The frames are labelled NoGas, Perfume, Smoke, Mixture on the physical reading of
their temperature scales, which is what you confirmed: the uniform 72 to 73 °F
frame with no structure is clean air, the cold evaporating plume is the
deodorant, the 101 to 356 °F source is the burning incense, and the warm plume
with cool spots is the mixture. They do not match any of the three Mixture frames
in the local copy of the dataset, so identification is by physics, not by file.

---

## Numbers the review flagged

Each is corrected and tied to its result file by a gate, so it cannot drift back.

| Was | Is | Source |
|---|---|---|
| Table 16: "misses 60% of hazards" at total sensor loss | 19.5% | `v2_perturb.csv`, dropout *k* = 7. The 60% appears to be its escalation figure of 0.605 |
| Conclusions: one lost channel "left the random forest untouched" | moves to 7 per 1,000 | The Results section already said "moves only to 7.0", so the paper contradicted itself |
| Summary: a miss-rate-only review "would favor" a model | would treat the two as interchangeable | The body says that column clears both and separates neither |
| Cross-references to "Proposed Method" | Methodology | That heading no longer exists |
| Table A-1 seed sets point at Table 6 | point at the protocol paragraph | Table 6 is the research-question map |

Also settled: the false-alarm denominator is declared where the metric is defined,
with the all-nonhazardous rate named as its sensitivity; the reject-option result
is labelled as the alarm-mapped case and quotes measured rates instead of "which
no facility would accept"; the Introduction no longer implies fixed detectors are
usually MOX; the IEC 61511 claim is softened to a dependency between protection
layers; the EEMUA line is off Fig. 16, because that figure is a budget for a whole
operator position and the axis is one detector; Table 14 says its hourly rates are
averaged across the five partitions rather than pooled; the Limitations paragraph
says windows are not pooled and the worst partition is reported, but that within a
partition the binomial still treats windows as nominal opportunities; and the
30-run comparison states what varies per model family and that the tuning budget
is equal.

Table 1 is condensed so it stops wrapping across pages. Table 10 groups the six
comparators that agree to four decimal places on every column into one row,
twenty-two rows down to seventeen; that grouping is generated against the result
file and checked for maximality, because a hand-typed grouping is how the Table 15
error got in last time.

---

## State

| Suite | Result |
|---|---|
| `verify_v13.py` | 981 checks, 1 deliberate failure |
| `self_audit.py` | 965 checks, 0 |
| `test_safety_metrics.py` | 30 assertions, 0 |
| `audit_release.py` | 0 problems |
| `check_figure_text.py` | 23 figures, 0 overlapping pairs, 0 labels outside a box |

The one failure is the `⟨ULTRALYTICS_VERSION⟩` placeholder in Appendix A. It stays
failing until you supply the version string from the training environment.

Still open: the Zenodo DOI and the release commit SHA, and a literature sweep
through 2026.
