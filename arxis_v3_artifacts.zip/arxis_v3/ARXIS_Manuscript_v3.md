# Safety-Relevant Evaluation of Machine-Learning Gas-Hazard Monitoring at the Edge: Accuracy Rankings Do Not Predict Missed-Hazard or Escalation Behavior

**Benjamin C. Nweke**^a,b,\*, **Gholamreza Ramezan**^b, **Soheil Saraji**^a

^a Subsurface Energy and Digital Innovation Center (SEDI), Department of Energy and Petroleum Engineering, University of Wyoming, 1000 E. University Ave., Laramie, WY 82071, USA
^b Fides Innova Labs, Vancouver, BC, Canada

\* Corresponding author: bnweke@uwyo.edu

*Prepared for submission to SPE Journal — Data Science and Engineering Analytics.*

> **Version note.** Every quantitative result in Sections 4.1–4.6 comes from a complete
> re-execution of the experiment programme performed for this revision, on the corrected
> data pipeline (boundary-straddling windows dropped, scaling fitted on the training
> partition only, split position varying with the seed). These results supersede the
> earlier draft's tables. Section 4.7 (edge deployment) and Section 4.1's perception
> figures could not be re-run and are carried forward with their original caveats; both
> are flagged in Appendix A.

---

## Summary

Fixed gas detection at wellpads, tank batteries, compressor stations, and gas-processing facilities produces far more abnormal indications than an operator can act on. The engineering difficulty is rarely the absence of a signal; it is deciding, under degraded and ambiguous evidence, which indication warrants which response. Machine-learning studies of gas detection are ranked almost universally by classification accuracy — a metric that is silent on the two quantities that determine whether a monitoring system is safe to field: how often a hazard draws no response, and how often clean conditions draw a high-severity one.

We evaluate an edge-deployable monitoring pipeline — thermal-image classification, normal-only sensor anomaly scoring, cost-sensitive action assignment, and locally generated natural-language explanation — under a safety-relevant metric set rather than accuracy alone. Evaluation uses the public MultimodalGasData corpus (Narkhede et al. 2022) with a leakage-controlled block-wise holdout and a 20-window embargo. The corpus contains laboratory surrogates — incense smoke, alcohol-based vapor, and their mixture — not hydrocarbons; results therefore characterize evaluation methodology on a representative metal-oxide array rather than field detection performance.

Eleven models spanning tree ensembles, kernel methods, feedforward and recurrent networks, offline reinforcement learning, a depth-3 threshold rule and classical sequential change detection were trained under one protocol. Four findings follow. **First**, the ten multiclass models fall within 4.7 accuracy points of one another (0.930–0.977), a range this design cannot resolve, and all record zero missed hazards and zero high-severity false alarms in distribution — the in-distribution metric set does not discriminate at all. **Second**, withholding one hazardous class at training time separates them by more than two orders of magnitude: a multilayer perceptron misses 9.49% of unseen Smoke windows (95% Clopper–Pearson upper bound 10.05%) against a 0.038% bound for four other models. **Third**, and more consequentially, missed-hazard rate is itself insufficient. On unseen Mixture, seven of eight models bound their miss rate below 2.9%, yet escalate between **0.5% and 100%** of the same hazardous windows to alarm-grade action; a support-vector classifier misses 0.03% of windows while escalating 0.5% of them, answering 99.5% with a sub-alarm response the miss metric scores as success. **Fourth**, cost asymmetry swept from 1:1 to 20:1 changes neither missed-hazard rate (0 throughout) nor escalation adequacy (1.00 throughout) and degrades accuracy above 6:1.

Under graded sensor loss the three failure modes separate cleanly: with all seven channels removed the cost-weighted policy and the threshold rule hold zero misses and full escalation but reach a **100% false-alarm rate** — 1,800 alarms per hour from a single detector at the 0.5 Hz cadence — while gradient boosting holds zero false alarms and misses 60% of hazards. Reporting either column alone certifies a different model as safe.

We conclude that missed-hazard rate, escalation adequacy, false-alarm burden in alarm-management units, degradation under graded sensor loss and drift, and confidence bounds on every zero count should be reported together as standard.

**Keywords:** gas-hazard monitoring; safety-relevant evaluation; cost-sensitive learning; distribution shift; alarm management; edge deployment; anomaly detection; explainable AI

---

## 1. Introduction

Major process-safety incidents are seldom preceded by silence. More often the warning is present, distributed across several indications, and never converted into timely and proportionate action. In the eleven minutes before the Milford Haven refinery explosion, the control-room operator received 275 alarms (Goel et al. 2017). The failure was not sensing. It was the conversion of sensed evidence into a decision.

That distinction is sharp at upstream and midstream facilities. Wellpads, tank batteries, compressor stations, and gas-processing plants carry fixed point-gas detectors — commonly low-cost metal-oxide-semiconductor (MOX) elements — feeding alarm systems that in many installations already operate at or beyond the long-term average alarm rates industry guidance considers manageable for one operator position (EEMUA 2013; ISA 2016). The same facilities face rising obligation to detect and act on fugitive hydrocarbon release, where the required response is simultaneously a safety action and an emissions action. In both cases the operational question is not *what gas is present* but *what should be done now, and how confident must we be to do it*.

Machine learning has been applied extensively to the first question and scarcely to the second. Gas-detection models are ranked by classification accuracy, and on established benchmarks that ranking has saturated: reported accuracies on the corpus used here span roughly 93–99.7% across more than ten peer-reviewed studies (Narkhede et al. 2021; Faleh and Kachouri 2023; El Barkani et al. 2024; Sharma et al. 2024; Zhang and Zhang 2025). When a benchmark saturates, differences among leading methods stop being informative about deployment, and the interesting question becomes what the accuracy ranking is failing to measure.

### 1.1 Accuracy is a symmetric metric applied to an asymmetric problem

In a monitoring context the error classes are not exchangeable, and no single scalar orders them:

- A hazardous condition that draws no response forfeits the intervention window entirely.
- A hazardous condition that draws a sub-alarm response — increased sampling, a request for verification — preserves part of that window but notifies no operator, and is not equivalent to a correct escalation.
- A clean condition that draws a high-severity response consumes operator attention and, at sufficient rate, degrades the alarm system on which later hazards depend (Laberge et al. 2014).
- A hazardous condition that draws the *wrong* high-severity response is, in most operating regimes, nearly as good as the right one.

A model ranked first on accuracy may be ranked last on any of these, and nothing in an accuracy table reveals which. This paper shows that on a standard benchmark it is ranked last on several.

### 1.2 What is established and what is not

The component technologies are mature. Reconstruction-based models trained on normal operation detect departures from baseline in multivariate sensor streams (Malhotra et al. 2016), including in field-validated pipeline settings (Liang et al. 2024). Vision models classify thermal and optical gas signatures at embedded-device speeds (Korjani et al. 2024; Jocher et al. 2023). Cost-sensitive learning gives a principled account of unequal error costs (Elkan 2001). Multimodal fusion of thermal imagery with MOX arrays improves gas classification over either modality alone (Narkhede et al. 2021, 2022). Compact language models make local explanation feasible without transmitting monitoring data off site (Dehnaw et al. 2024).

What is not established is how these components behave when ranked by anything other than accuracy. Specifically:

1. whether accuracy-ranked model selection preserves the ranking under a missed-hazard criterion;
2. whether models that agree in distribution continue to agree when the hazard is one they were never trained on — the condition that matters most, since a fielded detector will eventually meet a release it has not seen;
3. whether missed-hazard rate is itself sufficient, or whether it can be satisfied by under-escalation a miss count does not register;
4. whether these behaviors survive the arithmetic, memory, and thermal constraints of the low-cost edge hardware on which such systems are installed.

### 1.3 Contributions

**A safety-relevant evaluation protocol for gas-monitoring models**, comprising a leakage-controlled block-wise holdout with an explicit embargo and seed-varying block position; a five-level action target separating missed hazard from under-escalation from high-severity false alarm; leave-one-class-out (LOCO) evaluation against an unseen hazard; a graded perturbation suite spanning additive noise, calibration drift and channel loss at five to seven severities; and Clopper–Pearson bounds on every zero count. To our knowledge this combination has not previously been applied to a MOX gas-detection benchmark.

**Evidence that accuracy ranking is uninformative about safety behavior.** Ten multiclass models spanning very different inductive biases span 4.7 accuracy points in distribution and are indistinguishable on every safety metric there, yet separate by more than two orders of magnitude in missed-hazard rate on an unseen hazard.

**Evidence that missed-hazard rate is necessary but not sufficient.** On an unseen hazardous class, models with miss rates bounded below 2.9% differ by a factor of 198 in escalation adequacy, and the models with the best miss rates include both the best and among the worst escalators.

**Two negative results, reported in full.** Cost asymmetry produces no measurable change in missed-hazard rate or escalation adequacy at any ratio from 1:1 to 20:1 and degrades accuracy above 6:1; and a deterministic label-function reference attains the accuracy ceiling by construction, so any benefit from a learned policy on this corpus must lie in degraded conditions rather than nominal ones.

**Incumbent-practice and classical comparators.** A depth-3 decision tree on seven raw sensor channels and a CUSUM sequential detector are evaluated under the identical protocol, so the learned models are measured against what a facility would otherwise deploy.

We do not claim to advance the classification state of the art on this corpus, and we do not believe that would be a useful thing to advance. The benchmark is saturated. The open question is what the saturated numbers fail to measure.

---

## 2. Background and Related Work

### 2.1 Leak detection and the gap between indication and response

Gas-hazard detection rests on an established base of hardware- and software-based methods (Murvay and Silea 2012; Adegboye et al. 2019): distributed acoustic and fiber-optic sensing, vapor sensing and negative-pressure-wave detection on one side; real-time transient modeling, mass balance, statistical analysis and model-based diagnostics on the other (Zhang et al. 2013; Bustnes et al. 2011). These have materially improved identification and localization, their principal limitation being uneven performance under practical operating conditions rather than absence of capability (Han and Kim 2014). For the present argument the more consequential limitation is different: they terminate in a leak indication, a location estimate, or a concentration estimate. Such outputs are necessary for loss prevention but are not response decisions, and the literature evaluating them does not measure whether the downstream response would be adequate.

### 2.2 Anomaly detection as an evidence layer

Reconstruction-based sequence models trained only on normal operation have been the standard unsupervised approach to multivariate sensor anomaly detection since Malhotra et al. (2016), and have been applied to natural-gas pipeline monitoring with field validation (Liang et al. 2024). Their appeal for safety work is that they require no labeled examples of every hazardous condition. An anomaly score is nonetheless an intermediate quantity: it states that behavior departs from baseline, not what should be done, and it is not calibrated to hazard severity. Any use of such a score inside a safety path carries an obligation to demonstrate that it ranks hazard monotonically — an obligation the literature rarely discharges and which we test directly in Section 4.1.

### 2.3 Multimodal gas classification and benchmark saturation

The MultimodalGasData corpus pairs thermal frames with a seven-channel MOX array and established that fusing the modalities improves classification over either alone (Narkhede et al. 2021, 2022). It has become a standard benchmark, and reported accuracies have converged: 97.0% (Narkhede et al. 2021), 93.0% (Faleh and Kachouri 2023), 91.7% (El Barkani et al. 2024), 99.7% (Sharma et al. 2024), 99.7% (Zhang and Zhang 2025).

Two features of this literature bear on the present work. First, the reported figures are, to our knowledge, computed on random splits over overlapping sliding windows drawn from a single recording session. Dennler et al. (2022) showed on a comparably structured MOX corpus that this conflates recording time with class identity and identified a substantial body of published work requiring re-evaluation; Vergara et al. (2012) had earlier documented the magnitude of MOX drift over long horizons. Second, none of these studies reports a safety-relevant quantity: not missed-hazard rate, not escalation adequacy, not false-alarm burden, not behavior under sensor loss. The benchmark has saturated on a metric that does not discriminate deployment fitness.

### 2.4 Cost-sensitive learning and safety objectives

That error costs are unequal, and that classifiers should be trained accordingly, has been formalized since Elkan (2001), and cost-sensitive reweighting is now routine. What is much less often reported is whether a given asymmetry produced a measurable effect on the specific error it was introduced to suppress. Section 4.4 reports such a test and returns a negative result we believe generalizes to any saturated, well-separated benchmark.

### 2.5 Agentic coordination and operator-facing explanation

Systems coordinating specialized models toward a larger task have been applied in the energy sector to well-construction assistance, completions optimization and enterprise modeling (Sabbagh et al. 2024; Santiago et al. 2025; Jessen and Roshchin 2025). These are analytical and advisory settings rather than real-time monitoring, with correspondingly different evaluation criteria. Explanation matters for operator-facing safety systems because trust, review and post-incident accountability depend on it; it also introduces a hazard of its own, since a language model can produce an explanation that is fluent and inconsistent with the decision it purports to explain, which in a control room is worse than no explanation. Our treatment of that constraint is architectural (Section 3.3).

### 2.6 Positioning of this study

**Table 1** summarizes representative prior work and the evaluation gap each leaves open.

| Study | Area | Contribution | Evaluation gap addressed here |
|---|---|---|---|
| Malhotra et al. (2016) | Anomaly detection | Reconstruction-error scoring for multivariate streams | Score not calibrated to hazard severity; no response mapping |
| Liang et al. (2024) | Anomaly detection | Field-validated normal-only leak detection | Detection endpoint only; downstream response unevaluated |
| Korjani et al. (2024) | Computer vision | High detection rates on optical gas imaging | Degraded-sensing performance not characterized as a safety metric |
| Narkhede et al. (2021, 2022) | Multimodal sensing | Thermal–MOX fusion improves classification; public corpus | Classification accuracy only; random split over overlapping windows |
| Sharma et al. (2024); Zhang and Zhang (2025) | Multimodal classification | State-of-the-art accuracy on this corpus | No missed-hazard, escalation, false-alarm or degradation reporting |
| Dennler et al. (2022) | Benchmark methodology | Demonstrates drift-induced leakage in MOX benchmarks | Motivates, but does not supply, a safety-relevant metric set |
| Elkan (2001) | Cost-sensitive learning | Formal account of unequal error costs | Effectiveness on a saturated benchmark untested |
| Sabbagh et al. (2024) | Multi-agent systems | Coordination improves answer quality | Analytical workflow; not real-time monitoring |

The contribution of this work sits in the right-hand column: not a new architecture, but evidence about what the standard evaluation of these architectures fails to reveal.

---

## 3. Methodology

### 3.1 Dataset and preprocessing

Evaluation uses the public MultimodalGasData corpus (Narkhede et al. 2022; Mendeley Data, CC BY 4.0), pairing a seven-channel MQ-series MOX array with synchronized 206 × 156 thermal frames from a Seek Compact camera. It comprises 6,400 labeled samples in four classes of 1,600: clean air (NoGas), incense smoke (Smoke), alcohol-based deodorant vapor (Perfume), and a smoke–vapor mixture (Mixture). **Table 2** lists the array.

| Sensor | Primary detection target |
|---|---|
| MQ-2 | LPG, butane, methane, smoke |
| MQ-3 | Alcohol, ethanol, vapors |
| MQ-5 | LPG, natural gas |
| MQ-6 | LPG, butane, iso-butane |
| MQ-7 | Carbon monoxide |
| MQ-8 | Hydrogen |
| MQ-135 | Air-quality indicators (NH₃, benzene, NOₓ, CO₂) |

**Table 2 — MQ sensor array composition and primary detection targets.**

Two properties of the corpus govern the entire experimental design and are stated here rather than deferred.

**The analytes are laboratory surrogates, not hydrocarbons.** Incense smoke and alcohol-based vapor exercise the MOX transduction mechanism, the cross-sensitivity structure of the array and its baseline drift — all of which a facility detector encounters — but they do not establish detection performance for methane or heavier hydrocarbons. Every result here characterizes evaluation methodology on a representative MOX array, not field performance.

**The four classes were recorded as four contiguous blocks within a single acquisition session of approximately 90 minutes.** Within-session baseline drift is therefore confounded with class identity — precisely the structure Dennler et al. (2022) showed to inflate reported accuracy on MOX benchmarks under a randomized split. The split below is a response to that property, not a convenience.

**Windowing.** Seven-channel readings were formed into sliding windows of length 20, each labeled by its final reading. **Windows spanning a class boundary are discarded**, so no window mixes two classes. This yields **6,324 windows, 1,581 per class**.

**Split.** Consecutive windows share 19 of 20 raw rows, so a random split places near-duplicate windows in both partitions; a plain sequential split is equally unsuitable because the corpus is block-ordered by class. We therefore use a leakage-controlled block-wise holdout: within each class block a contiguous 20% forms the test partition, separated from the training segments by an embargo of *G* = 20 windows, so no training window shares a raw row with any test window. **The position of the held-out block varies with the run seed**, so reported dispersion includes data-partition variance and not only model-initialization variance (Bouthillier et al. 2021). This yields **4,980 training and 1,264 test windows (316 per class)**. All feature scaling and anomaly-score normalization are fitted on the training partition only and applied to the test partition without refitting.

### 3.2 Monitoring pipeline

The pipeline (ARXIS) has five components. At each inference cycle it receives a thermal image *I*ₜ and a sensor window **X**ₜ ∈ ℝ^(20×7), and returns a safety action *a*ₜ ∈ {0,…,4} and an explanation *E*ₜ: a **perception** component classifying the thermal image; an **anomaly** component scoring the sensor window by reconstruction error against a normal-only model; a **coordination** component assembling the decision state; a **decision** component mapping that state to an action; and a **reasoning** component generating an operator-facing explanation.

**The pipeline is advisory.** It occupies the alarm-management and operator-support layer and does not actuate. The action labeled *Emergency Shutdown* denotes a recommendation that the operator initiate the facility's existing ESD procedure; it does not command a trip. The safety instrumented function remains an independent, deterministic, separately verified layer, consistent with the independence requirement of layer-of-protection analysis and with the absence of any established certification pathway for a learned component within a safety instrumented function under IEC 61511 (IEC 2016). All results are obtained with the pipeline in this position, and the facility's protective function is unaffected by its removal. We regard this as a design requirement rather than a caveat: one learned component selecting across both the alarm layer and the shutdown layer would collapse two protection layers into a single common-cause element.

| Action | Label | Operational response |
|---|---|---|
| 0 | Monitor | Routine monitoring; no operator notification |
| 1 | Increase sampling | Elevated scan frequency and event logging |
| 2 | Request verification | Operator notification and secondary sensor check |
| 3 | Raise alarm | Automated alarm, incident logging, field dispatch |
| 4 | Emergency shutdown | Recommend initiation of the facility ESD procedure |

**Table 3 — Safety-action space.** Actions 3 and 4 are *alarm-grade*: they place a notification in front of an operator. Actions 1 and 2 do not.

### 3.3 Component models

**Perception.** Thermal images are classified with YOLOv8n-cls (Jocher et al. 2023), chosen for its speed–footprint tradeoff on embedded hardware: images resized to 224 × 224, pretrained initialization, AdamW at 10⁻³ with cosine annealing, weight decay 10⁻⁴, batch 32, 50 epochs, random flip/rotation/brightness augmentation, on an 80/20 stratified split of the 6,400 frames. *That split is randomized over frames captured consecutively within one session*, so it is subject to the same leakage mechanism the sensor-side holdout excludes; adjacent frames are near-duplicates. Perception accuracy is therefore reported as an optimistic upper bound. The thermal frames were not available at revision time, so this split could not be corrected (Appendix A).

**Anomaly detection.** An LSTM autoencoder (single-layer encoder and decoder, hidden dimension 32, linear output) trained on NoGas windows only, following Malhotra et al. (2016). The mean reconstruction error over the full 20-step window is the anomaly score. The threshold τ is the 95th percentile of reconstruction error on **NoGas training windows only**, and evaluation is on **held-out** windows (Section 4.1).

**Coordination.** The 22-dimensional decision state is

&nbsp;&nbsp;&nbsp;&nbsp;φₜ = [ ρ̃ₜ , **X**ₜ[−1,:] , **δ**ₜ , **σ**ₜ ] ∈ ℝ²² .................................................(1)

with ρ̃ₜ the normalized anomaly score, **X**ₜ[−1,:] the current seven-channel reading, **δ**ₜ the per-sensor change across the window and **σ**ₜ the per-sensor standard deviation. The state contains no visual term: thermal evidence informs the perception and explanation paths, not the action.

**Decision.** A feedforward network with a dueling value–advantage head (Wang et al. 2016) mapping φₜ to five action scores, **trained by cost-weighted cross-entropy — not by reinforcement learning.** Target actions come from a deterministic map *a*\*(·) from class to acceptable action set: NoGas→{0}, Smoke→{3}, Mixture→{4}, Perfume→{1,2}. Each sample carries a loss weight *w*(*g*ₜ) = *c*_miss for hazardous classes and *c*_false otherwise, with *C* = *c*_miss/*c*_false. The objective is

&nbsp;&nbsp;&nbsp;&nbsp;*L*(θ) = − (1/*N*) Σₜ *w*(*g*ₜ) · log *p*_θ( *a*\*(*g*ₜ) | φₜ ) ..................................(2)

with *p*_θ the softmax over action scores. The deployed configuration uses *C* = 8:1; Section 4.4 reports the full sweep.

Two consequences of Eq. 2 bound what can be claimed, and are stated because a reviewer will derive them independently. **First, the target action is a deterministic function of the class label**, so decision accuracy is four-class classification accuracy composed with a fixed map, not a distinct quantity measured on a distinct task. What differs between the decision framing and the classification framing is the *error metric*, not the task — and the error metric is what this paper's results concern. **Second, a rule applying *a*\*(·) to the true label attains 100% decision accuracy by construction.** Such a rule consumes the label it is meant to infer and is not deployable; where it appears below it is identified as a label-function reference, never a baseline. The deployable analogue is the depth-3 threshold rule of Section 3.4.

**Reasoning.** Explanations are generated locally with Gemma 3 1B served through Ollama (Google DeepMind 2025), prompted with gas class, classification confidence, normalized anomaly score and threshold, and selected action, capped at 150 tokens. No monitoring data leaves the device. The explanation is advisory and delivered off the safety-critical path: the action is fixed by the decision component and is not altered by the generated text. The separation is deliberate — a free-text model can produce an explanation that is fluent yet inconsistent with the decision, which in a control room is a hazard rather than an aid — and, as Section 4.7 shows, the latency arithmetic independently forbids placing a language model in the decision path. The safety argument and the timing budget converge on the same architecture.

### 3.4 Comparators

Eleven models were trained under one protocol: the cost-weighted policy of Eq. 2; an **unweighted** network of identical topology; a **multilayer perceptron** (256-256-128); **cost-sensitive gradient boosting** (300 trees); an **RBF support-vector classifier**; a **random forest** (300 trees); a **recurrent network** over K = 10 consecutive states; **conservative Q-learning** (TD(0) bootstrap plus a conservative penalty on non-behavior actions); **k-nearest neighbours** (k = 5); a **threshold rule** — a depth-3 decision tree restricted to the seven raw current-sensor channels, interpretable and deployable, the incumbent-practice comparator; and **CUSUM** (Page 1954), a one-sided cumulative-sum detector on the anomaly score with μ₀ and σ estimated from NoGas training windows and the decision threshold set on the training partition. CUSUM is two-class by construction — it cannot separate Smoke from Mixture — so its decision accuracy is not comparable with the multiclass models; its missed-hazard rate and escalation adequacy are.

### 3.5 The safety-relevant metric set

We evaluate every model on five quantities rather than one. This set is the paper's principal methodological proposal.

**Decision accuracy.** Fraction of test windows assigned an action in *a*\*(*g*ₜ). Reported for continuity with prior work, not as a safety metric.

**Missed-hazard rate.** Fraction of hazardous windows (Smoke and Mixture) assigned the passive *Monitor* action. This counts only *a* = 0: assigning a hazardous window to *Raise Alarm* when *Emergency Shutdown* was the target is not a miss, because an operator is still notified. Its limitation is that assigning a hazardous window to *Increase Sampling* or *Request Verification* is also not a miss, although no operator is notified. Section 4.3 shows this limitation is not academic, which is the reason for the next metric.

**Escalation adequacy.** Fraction of hazardous windows assigned an alarm-grade action (*a* ≥ 3) — the quantity that determines whether an operator learns of the hazard. We also report **under-escalation**, the fraction receiving *a* ∈ {1,2}.

**High-severity false-alarm rate.** Fraction of *clean* windows assigned *a* ≥ 3. We note that the project's original evaluation code divided false alarms by the number of alerts rather than the number of clean windows; the two coincide only at zero. All figures here use the per-clean-window definition, and Section 4.7 converts it into alarm burden per hour, because a rate is not directly comparable with the envelopes an operator works within (EEMUA 2013; ISA 2016).

**Confidence bounds on every zero count.** An observed zero is not a demonstrated zero. All zero-count claims carry a one-sided 95% Clopper–Pearson upper bound (Clopper and Pearson 1934). Pooled over five seeds this study observes 3,160 hazardous and 1,580 clean test windows, so a zero supports only "≤ 0.095%" and "≤ 0.189%" respectively; a claim below 10⁻³ would require approximately 2,995 consecutive zero-miss observations.

### 3.6 Protocol and statistical treatment

All experiments use five seeds (42, 1337, 7, 2024, 99), each with its own block position, with determinism guards enabled and single-threaded execution.

**With *n* = 5 paired seeds, the two-sided Wilcoxon signed-rank test has a minimum attainable *p*-value of 2^(1−n) = 0.0625.** No comparison in this design can reach α = 0.05 at any effect size. We therefore report no significance-based ranking among models and ask readers not to infer one; paired *p*-values are quoted for completeness with this constraint stated alongside. A properly powered comparison would require substantially more randomized runs varying seed, split, augmentation and hyperparameter draw, together with an equivalence analysis over a region of practical equivalence (Benavoli et al. 2017; Bouthillier et al. 2021); this is identified as required further work.

### 3.7 Edge deployment setup

The edge study evaluates whether the decision path meets a practical sampling-interval budget on modest industrial-IoT hardware. It is a benchmark replay on edge hardware, not a live field deployment. The platform is a Raspberry Pi 4 Model B (Cortex-A72, 8 GB RAM) on 64-bit Raspberry Pi OS Bookworm, with Python 3.11, PyTorch 2.3 CPU, ONNX Runtime 1.18 and Ultralytics YOLOv8 8.2; the reasoning component is served locally through Ollama with a 4-bit-quantized Gemma 3 1B model. The test partition is streamed from local storage at 0.5 Hz (a 2,000 ms sampling interval), within which the deployable decision path must complete.

---

## 4. Results

### 4.1 Component characterization

**Perception.** The thermal classifier attained 98.8% top-1 accuracy on 1,280 held-out validation images at 0.78 ms mean inference latency (**Table 4**), with perfect recall for Smoke and Mixture; the 15 misclassifications fell at the NoGas–Perfume boundary.

| Gas class | Precision | Recall | F1 | Accuracy (%) |
|---|---|---|---|---|
| Mixture | 1.000 | 1.000 | 1.000 | 100.0 |
| NoGas | 0.990 | 0.963 | 0.976 | 96.3 |
| Perfume | 0.972 | 0.991 | 0.981 | 99.1 |
| Smoke | 0.991 | 1.000 | 0.995 | 100.0 |
| Overall | 0.988 | 0.988 | 0.988 | 98.8 |

**Table 4 — Perception component, 1,280 held-out validation images.** Obtained under a randomized image split (Section 3.3); read as an optimistic upper bound.

**Anomaly detection.** Two questions matter here, and both were open in the earlier draft.

*Does the score rank hazard?* Mean reconstruction error by class is NoGas **0.736**, Perfume **1.543**, Mixture **117.72**, Smoke **229.25** (Fig. 1a). The score separates hazardous from non-hazardous conditions by two orders of magnitude, so it is a usable hazard indicator — but it is **not monotone in target severity**: Mixture carries the higher target action (*Emergency Shutdown*) yet scores below Smoke. The score should therefore be read as evidence of abnormality, not as a severity estimate, and no result in this paper depends on it being one.

*Is the published operating point out of sample?* No. Recomputing the threshold as the 95th percentile of all NoGas windows and evaluating on the same windows reproduces AUC 0.962 at exactly **5.000%** false-positive rate — the nominal value of a 95th-percentile threshold evaluated on the sample that defined it. Fitting τ on NoGas *training* windows only and evaluating on **held-out** windows gives **ROC-AUC 0.9928 ± 0.0053, TPR 0.7363 ± 0.0949 and FPR 0.0000 ± 0.0000** across five seeds (Fig. 1b). The corrected evaluation is materially *better* on discrimination and false positives and lower on sensitivity; the earlier figures should not be used.

![](figures_v2/fig_anomaly.png)

**Fig. 1 — Anomaly component.** (a) Mean reconstruction error by class, log scale. (b) Operating point with the threshold fitted on its own sample versus fitted on training windows and evaluated on held-out windows.

### 4.2 In distribution, eleven models are indistinguishable on every metric

All models were trained on the same partition with the same five seeds and evaluated on the same holdout (**Table 5**, Fig. 2).

| Model | Decision accuracy | SD | Missed-hazard | 95% CP bound | Escalation | High-severity FA | Wilcoxon *p* vs. cost-weighted |
|---|---|---|---|---|---|---|---|
| Random forest | **0.9769** | **0.0086** | 0.0000 | ≤ 0.095% | 1.000 | 0.0000 | 0.1875 |
| Recurrent (LSTM) | 0.9680 | 0.0231 | 0.0000 | ≤ 0.095% | 1.000 | 0.0000 | 0.8125 |
| Gradient boosting | 0.9634 | 0.0211 | 0.0098 | ≤ 1.322% | 0.990 | 0.0000 | 1.0000 |
| **Cost-weighted policy** | 0.9623 | 0.0214 | 0.0000 | ≤ 0.095% | 1.000 | 0.0000 | — |
| Multilayer perceptron | 0.9612 | 0.0110 | 0.0000 | ≤ 0.095% | 1.000 | 0.0000 | 0.8125 |
| Unweighted network | 0.9562 | 0.0386 | 0.0000 | ≤ 0.095% | 1.000 | 0.0000 | 1.0000 |
| k-nearest neighbours | 0.9521 | 0.0295 | 0.0000 | ≤ 0.095% | 1.000 | 0.0000 | 0.1250 |
| Support vector classifier | 0.9511 | 0.0190 | 0.0000 | ≤ 0.095% | 1.000 | 0.0000 | 0.4375 |
| Conservative Q-learning | 0.9438 | 0.0485 | 0.0000 | ≤ 0.095% | 1.000 | 0.0000 | 0.3750 |
| **Threshold rule** (depth-3) | 0.9297 | 0.0295 | 0.0000 | ≤ 0.095% | 1.000 | 0.0000 | 0.1875 |
| CUSUM (two-class) | 0.4994\* | 0.0004 | 0.0013 | ≤ 0.289% | 0.999 | 0.0000 | 0.0625 |

**Table 5 — Model comparison on the block-wise holdout, five seed-varying partitions.** Pooled *n* = 3,160 hazardous and 1,580 clean test windows. \*CUSUM emits only actions 0 and 3, so its decision accuracy is not comparable; its safety columns are. The minimum attainable two-sided *p* at *n* = 5 is 0.0625, so no entry in the final column can reach α = 0.05.

Three observations.

**The ten multiclass models span 4.7 accuracy points** (0.9297–0.9769). The highest point accuracy and the lowest variance belong to the **random forest**; the cost-weighted policy places fourth; the **depth-3 threshold rule on seven raw sensor channels is 3.3 points behind the best learned model** and within one standard deviation of four of them.

**In distribution, the safety metrics do not discriminate at all.** Ten of eleven models record exactly zero missed hazards, escalation adequacy of 1.000, and zero high-severity false alarms. Gradient boosting is the sole exception at 0.0098 miss. On this evidence a facility could deploy a three-level decision tree and observe identical safety behavior to any deep model tested.

**We assert no ranking, and this design does not support one.** The smallest observed *p* is 0.0625 (CUSUM), which is the minimum attainable value. The correct reading of Table 5 is that these models are **not distinguishable in distribution** — which is the premise for everything that follows, and more useful than a ranking would be.

![](figures_v2/fig_zoo.png)

**Fig. 2 — Decision accuracy on the block-wise holdout,** mean ± SD over five seed-varying partitions. The shaded band spans the full range of model means.

### 4.3 Out of distribution, the same models separate by two orders of magnitude — and escalation separates further

For each hazardous class in turn, models were retrained on the remaining three classes and evaluated on every window of the withheld class. Feature scaling and anomaly normalization were fitted on the three training classes only, so no statistic of the withheld class enters training. Held-out decision accuracy is zero by construction — withholding a class removes its target action from the training label set, so the model cannot emit it — and the informative quantities are what the model does instead. **Table 6** and Fig. 3 report both.

| Held-out | Model | Missed-hazard | 95% CP bound | **Escalation (a ≥ 3)** | **Under-escalation (a ∈ {1,2})** |
|---|---|---|---|---|---|
| Smoke | Cost-weighted policy | 0.0000 | ≤ 0.038% | 1.000 ± 0.000 | 0.000 |
| Smoke | Gradient boosting | 0.0000 | ≤ 0.038% | 1.000 ± 0.000 | 0.000 |
| Smoke | Random forest | 0.0000 | ≤ 0.038% | 1.000 ± 0.000 | 0.000 |
| Smoke | Threshold rule | 0.0000 | ≤ 0.038% | 1.000 ± 0.000 | 0.000 |
| Smoke | Unweighted network | 0.0001 | ≤ 0.060% | 0.9999 ± 0.0003 | 0.000 |
| Smoke | Support vector classifier | 0.0042 | ≤ 0.558% | 0.928 ± 0.023 | 0.068 |
| Smoke | k-nearest neighbours | 0.0116 | ≤ 1.383% | 0.943 ± 0.005 | 0.045 |
| Smoke | **Multilayer perceptron** | **0.0949** | **≤ 10.047%** | 0.902 ± 0.130 | 0.003 |
| Mixture | Cost-weighted policy | 0.0000 | ≤ 0.038% | **0.226 ± 0.209** | **0.774** |
| Mixture | Gradient boosting | 0.0000 | ≤ 0.038% | **1.000 ± 0.000** | 0.000 |
| Mixture | Random forest | 0.0000 | ≤ 0.038% | **0.990 ± 0.010** | 0.010 |
| Mixture | Support vector classifier | 0.0003 | ≤ 0.080% | **0.005 ± 0.008** | **0.995** |
| Mixture | Unweighted network | 0.0004 | ≤ 0.098% | **0.215 ± 0.215** | 0.785 |
| Mixture | Multilayer perceptron | 0.0070 | ≤ 0.870% | **0.242 ± 0.121** | 0.751 |
| Mixture | k-nearest neighbours | 0.0254 | ≤ 2.854% | **0.205 ± 0.072** | 0.770 |
| Mixture | Threshold rule | 0.2487 | ≤ 25.683% | 0.564 ± 0.399 | 0.188 |

**Table 6 — Leave-one-class-out evaluation.** *n* = 1,581 windows per class per seed; bounds pooled over 7,905 evaluations. Scaling fitted on the three training classes only.

**In-distribution accuracy does not predict out-of-distribution missed-hazard rate.** On withheld Smoke the multilayer perceptron — fifth of ten by point accuracy in Table 5, and statistically indistinguishable from every other model there — assigns the passive *Monitor* action to 9.49% of unseen hazardous windows (95% bound 10.05%), against a 0.038% bound for four other models. That is a separation of more than two orders of magnitude, entirely invisible in Table 5, and no accuracy-based selection procedure would have avoided the failing model.

**Missed-hazard rate is itself insufficient, and this is the sharper result.** On withheld Mixture, **seven of eight models bound their miss rate below 2.9%** and by that criterion all seven pass. Their escalation adequacy ranges from **0.5% to 100%** — a factor of 198. The support-vector classifier misses 0.03% of unseen hazardous windows while escalating **0.5%** of them: it answers 99.5% of the most hazardous class in the corpus with *Increase Sampling* or *Request Verification*, and the miss metric records that as success. The cost-weighted policy escalates 22.6%, under-escalating 77.4%. Gradient boosting — carrying none of the pipeline's safety machinery — escalates all of them.

**The choice of safety metric, not the choice of model, determines which model appears safe.** A metric set reporting missed-hazard rate alone would rank the support-vector classifier above gradient boosting on this evidence and would be wrong by a factor of 198 on the quantity that decides whether an operator is notified. Note also that the two models achieving full escalation on both unseen hazards are tree ensembles, and that the deployable threshold rule fails safe on unseen Smoke while failing badly on unseen Mixture (24.87%, ≤ 25.68%) — no comparator is uniformly best, which is itself the argument for reporting the full set.

![](figures_v2/fig_loco.png)

**Fig. 3 — Leave-one-class-out behavior.** (a) Missed-hazard rate on a logarithmic axis; a linear axis compresses a 9.49% failure into visual equivalence with a 0.03% one. (b) Escalation adequacy, mean ± SD over five seeds.

### 4.4 Cost asymmetry changes accuracy, not safety behavior

The loss-weight ratio *C* of Eq. 2 was swept across nine values with all else fixed (**Table 7**, Fig. 4).

| Cost ratio *C* | Decision accuracy | SD | Missed-hazard | Escalation | High-severity FA |
|---|---|---|---|---|---|
| 1:1 (symmetric) | 0.9562 | 0.0386 | 0.0000 | 1.000 | 0.0000 |
| 2:1 | 0.9532 | 0.0418 | 0.0000 | 1.000 | 0.0000 |
| 4:1 | 0.9570 | 0.0390 | 0.0000 | 1.000 | 0.0000 |
| 6:1 | **0.9655** | 0.0272 | 0.0000 | 1.000 | 0.0000 |
| 8:1 (deployed) | 0.9623 | 0.0214 | 0.0000 | 1.000 | 0.0000 |
| 10:1 | 0.9589 | 0.0338 | 0.0000 | 1.000 | 0.0000 |
| 12:1 | 0.9533 | 0.0346 | 0.0000 | 1.000 | 0.0000 |
| 16:1 | 0.9427 | 0.0463 | 0.0000 | 1.000 | 0.0000 |
| 20:1 | 0.8389 | 0.1189 | 0.0000 | 1.000 | 0.0000 |
| *Label function* | *1.0000* | *0.0000* | *0.0000* | *1.000* | *0.0000* |

**Table 7 — Cost-asymmetry sweep, five seeds per configuration.** The label-function row applies *a*\*(·) to the true class label; it attains the ceiling by construction, consumes the label it is meant to infer, and is not a deployable baseline.

**Missed-hazard rate is zero and escalation adequacy is 1.000 at every ratio, including the symmetric 1:1 configuration.** Accuracy rises to a maximum of 0.9655 at 6:1, is 0.9623 at the deployed 8:1, and falls monotonically thereafter to 0.8389 at 20:1 — twelve points below the peak, with variance rising fourfold.

Cost asymmetry therefore produced no measurable safety benefit on this corpus and, beyond 6:1, cost accuracy. The reason is structural: because the target action is a deterministic function of a well-separated class label, and because a miss requires assigning a hazardous window to the class furthest from it in feature space, the miss rate sits at the floor before any weighting is applied. There is no error surface for the asymmetry to reshape. The correct inference is not that cost-sensitive learning is ineffective in general — the literature is unambiguous that it is effective where the error surface is nontrivial (Elkan 2001) — but that **this benchmark cannot demonstrate it**, and by extension that no saturated, well-separated benchmark can. Validating such an objective requires a corpus with genuine overlap between hazardous and benign states, or a metric under which under-escalation carries cost. Section 4.3 supplies the second, and under it the cost-weighted policy does not lead.

We note also that the deployed 8:1 configuration is not the accuracy optimum and was originally selected on test-partition dispersion; re-selection on a validation split is an open item.

![](figures_v2/fig_costsweep.png)

**Fig. 4 — Cost-asymmetry sweep.** Shading is ± 1 SD over five seed-varying partitions.

### 4.5 Feature ablation moves accuracy and leaves safety behavior untouched

The decision state was ablated by feature group, holding the architecture and protocol fixed (**Table 8**, Fig. 5).

| Decision state | *d* | Decision accuracy | SD | Δ vs. full | Missed-hazard | Escalation |
|---|---|---|---|---|---|---|
| Full state | 22 | 0.9612 | 0.0110 | — | 0.0000 | 1.000 |
| Without per-sensor σ | 15 | 0.9601 | 0.0357 | −0.11 pp | 0.0000 | 1.000 |
| Without anomaly score | 21 | 0.9574 | 0.0206 | −0.38 pp | 0.0000 | 1.000 |
| Without per-sensor δ | 15 | 0.9399 | 0.0413 | −2.14 pp | 0.0000 | 1.000 |
| Without δ and σ | 8 | 0.8875 | 0.0730 | −7.37 pp | 0.0000 | 1.000 |
| Current readings only | 7 | 0.8845 | 0.0764 | −7.67 pp | 0.0000 | 1.000 |
| Anomaly score only | 1 | 0.7513 | 0.1349 | −21.00 pp | 0.0000 | 1.000 |

**Table 8 — Decision-state ablation, five seeds.**

Temporal features carry the accuracy: removing both δ and σ costs 7.37 points, and the single anomaly score alone still reaches 75.1%. But **missed-hazard rate is zero and escalation adequacy is 1.000 in every condition, including the one-dimensional state.** No feature group in this decision state changes in-distribution safety behavior. This is a further instance of the paper's central point: an ablation reported on accuracy alone would appear to identify which features "drive safety behavior," and would be measuring something else.

![](figures_v2/fig_ablation.png)

**Fig. 5 — Decision-state ablation.** Bars are mean ± SD decision accuracy; missed-hazard rate and escalation adequacy are constant across all conditions and are stated in the title.

### 4.6 Under graded degradation, three distinct failure modes appear

Six models were subjected to additive noise (σ = 0.1–0.5), calibration drift (± 10–50% gain and baseline shift) and channel dropout (*k* = 1…7 of 7 sensors), each at graded severity, with all three safety metrics reported (**Table 9**, Fig. 6).

| Condition | Model | Decision acc. | Missed-hazard | Escalation | High-severity FA | Alarms h⁻¹ |
|---|---|---|---|---|---|---|
| Clean | Cost-weighted | 0.962 | 0.0000 | 1.000 | 0.0000 | ≤ 3.4\* |
| Clean | Random forest | 0.977 | 0.0000 | 1.000 | 0.0000 | ≤ 3.4\* |
| Clean | Threshold rule | 0.930 | 0.0000 | 1.000 | 0.0000 | ≤ 3.4\* |
| Drift ± 50% | Cost-weighted | 0.916 | 0.0000 | 1.000 | 0.0006 | 1.1 |
| Drift ± 50% | Multilayer perceptron | 0.927 | 0.0003 | 0.999 | 0.0000 | 0 |
| Drift ± 50% | Gradient boosting | 0.876 | **0.0775** | 0.890 | 0.0000 | 0 |
| Noise σ = 0.5 | Cost-weighted | 0.843 | 0.0000 | 1.000 | 0.1342 | 242 |
| Noise σ = 0.5 | Random forest | 0.889 | 0.0000 | 1.000 | 0.0063 | 11 |
| Dropout *k* = 1 | Cost-weighted | 0.883 | 0.0000 | 1.000 | 0.1171 | **211** |
| Dropout *k* = 1 | Random forest | 0.974 | 0.0000 | 1.000 | 0.0000 | 0 |
| Dropout *k* = 3 | Cost-weighted | 0.793 | 0.0000 | 0.992 | 0.1532 | 276 |
| Dropout *k* = 3 | Multilayer perceptron | 0.851 | 0.0218 | 0.975 | 0.0234 | 42 |
| Dropout *k* = 7 | Cost-weighted | 0.318 | 0.0000 | 1.000 | **1.0000** | **1,800** |
| Dropout *k* = 7 | Threshold rule | 0.250 | 0.0000 | 1.000 | **1.0000** | **1,800** |
| Dropout *k* = 7 | Random forest | 0.355 | 0.0000 | 1.000 | 0.6000 | 1,080 |
| Dropout *k* = 7 | Multilayer perceptron | 0.332 | **0.5266** | 0.473 | 0.2000 | 360 |
| Dropout *k* = 7 | Gradient boosting | 0.381 | **0.6000** | 0.400 | 0.0000 | 0 |

**Table 9 — Selected perturbation results** (full sweep in Fig. 6). Alarm burden is the false-alarm rate at the 0.5 Hz deployment cadence, i.e. rate × 1,800 windows h⁻¹, per detector. \*Clean-condition burden is the Clopper–Pearson upper bound on an observed zero, not a point estimate.

Three failure modes separate cleanly, and **no single metric distinguishes them**:

- **Fail-loud.** The cost-weighted policy and the threshold rule preserve zero missed hazards and full escalation under complete sensor loss — by escalating *everything*. Their false-alarm rate reaches 1.000, equivalent to 1,800 high-severity alarms per hour from one detector. Under EEMUA (2013) that is a hazard, not a safe failure; on the missed-hazard metric alone it is a perfect score.
- **Fail-silent.** Gradient boosting holds its false-alarm rate at zero throughout and misses 60% of hazards at *k* = 7, with escalation collapsing to 0.400. On the false-alarm metric alone it is a perfect score.
- **Graceful, then brittle.** The random forest holds zero misses and full escalation to *k* = 3 with no false alarms, then degrades to a 60% false-alarm rate at *k* = 7.

The operationally important number is the first onset, not the endpoint: **losing a single sensor of seven takes the cost-weighted policy from zero to 211 high-severity alarms per hour per detector**, while the random forest is unaffected. A facility running a hundred detectors would see the difference immediately, and no accuracy table, and no missed-hazard table, would have predicted it.

We note finally that at accuracies below roughly 60% none of these models is performing the task in any useful sense; "zero missed hazards" at 31.8% accuracy is a statement about failure *mode*, not fitness for service.

![](figures_v2/fig_perturb.png)

**Fig. 6 — Graded perturbation suite.** Rows share a scale so panels are comparable. Peak false-alarm rate under drift is 0.06%.

### 4.7 Edge deployment

**Table 10** reports latency, footprint and safety behavior across four configurations. These measurements are carried forward from the original hardware campaign and were not re-run for this revision.

| Configuration | Size (MB) | Mean latency (ms) | P99 (ms) | Decision acc. (%) | Missed-hazard | High-severity FA |
|---|---|---|---|---|---|---|
| Desktop CPU, float32 | 8.74 | 5.8 | 9.6 | 94.44 | 0.0000 | 0.0000 |
| Pi 4, float32, synchronous | 8.74 | 14,738 | 24,202 | 94.36 | 0.0000 | 0.0000 |
| Pi 4, INT8, synchronous | 4.19 | 14,675 | 24,028 | 93.97 | 0.0000 | 0.0032 |
| Pi 4, INT8, asynchronous reasoning | 4.19 | **235** | 413 | 93.97 | 0.0000 | 0.0032 |

**Table 10 — Edge deployment on a Raspberry Pi 4 against a 2,000 ms sampling budget.**

**Explanation must be decoupled from the decision path.** Synchronous local explanation produces a mean end-to-end latency of 14,738 ms against a 2,000 ms budget — a factor of seven over, on hardware otherwise entirely adequate, since the decision network itself runs in 1.07 ms. Moving explanation off the critical path and quantizing to INT8 reduces the deployable path to 235 ms mean, 413 ms P99. The conclusion generalizes: in a monitoring context a language model's role is to explain a decision already taken, never to participate in taking it. The timing budget enforces what the safety argument of Section 3.3 already required.

**Quantization carries a measurable safety cost.** INT8 halves the footprint (8.74 → 4.19 MB) and introduces one high-severity false alarm across 316 clean windows (0.0032; 95% CP upper bound 1.49%). Where zero high-severity false alarms is required, the decision network can remain in floating point while the larger perception model is quantized; the decision network is not the source of the footprint.

**From false-alarm rate to alarm burden.** A rate is not comparable to the envelopes an operator works within, so we convert. At 0.5 Hz a single detector processes 1,800 windows per hour, so the INT8 point estimate corresponds to approximately **5.8 high-severity alarms per hour from one instrument** under continuous clean-air operation — from a single detector, approaching the long-term average rate EEMUA (2013) treats as the limit of manageability for an entire operator position. The float32 configuration observed no false alarm, but its 95% upper bound of 0.944% corresponds to a burden of up to **17 alarms per hour**, again per detector. This conversion is in our view the single most important reframing available to work of this kind: "zero false alarms in 316 windows" sounds like a strong result and, in the units an alarm-management engineer uses, is not yet evidence of an acceptable one. Establishing an acceptable burden requires observation counts one to two orders of magnitude larger than any experiment reported here.

**Sustained thermal behavior narrows the margin.** Over a 36-minute passively cooled run the processor reached its 80 °C throttle point after approximately 24 minutes, reducing clock from 1,500 to 1,234 MHz and raising median latency from 420 to 640 ms. The decision path remained inside budget, but the margin more than halved through an effect no short benchmark would reveal.

### 4.8 Position relative to prior work on this corpus

Reported classification accuracies on MultimodalGasData span 93–99.7%, and the decision accuracies reported here sit below most of them. We state this plainly because the comparison is not like-for-like in either direction and both directions matter.

*Against us:* our evaluation uses a block-wise holdout with an explicit embargo, discards boundary-straddling windows, varies the partition with the seed, and fits all scaling on the training partition; the published comparisons are, to our knowledge, computed on randomized splits over overlapping windows from a single recording session — the protocol Dennler et al. (2022) showed conflates recording time with class identity. The figures are not directly comparable and the direction of the bias is known.

*In our favor:* the quantities differ. A classification error and an action error carry different operational consequence — confusing two hazardous classes preserves the need to escalate, whereas assigning a hazardous window to *Monitor* forfeits the intervention window. For a like-for-like recognition comparison the relevant figure is the thermal classifier's 98.8%, subject to the split caveat of Section 3.3.

We do not claim to advance the accuracy state of the art on this corpus, and the contribution does not rest on one.

---

## 5. Discussion

### 5.1 In distribution the metrics are saturated; out of distribution they diverge

The central empirical result is a dissociation with a sharp boundary. In distribution, ten model families spanning tree ensembles, kernel methods, feedforward and recurrent networks, offline reinforcement learning and a three-level decision tree are indistinguishable on *every* metric we report: 4.7 accuracy points separate best from worst, which this design cannot resolve, and all but one record zero missed hazards, full escalation and zero false alarms. A facility choosing among them on in-distribution evidence has no basis for choosing at all — including no basis for preferring a deep model to a decision tree.

Out of distribution the same models separate by more than two orders of magnitude on missed-hazard rate and by a factor of 198 on escalation adequacy, and the orderings are not preserved: the model that fails safe on one unseen hazard under-escalates on another; the two models that escalate fully on both are tree ensembles that carry none of the pipeline's safety machinery; and the deployable threshold rule is perfect on one unseen hazard and among the worst on the other.

The consequence for practice is direct. A team selecting a gas-monitoring model on benchmark accuracy — which is what the published literature on this corpus supports them in doing — obtains no information about how the selected model will behave on a release it was not trained on. That is the condition under which the model will eventually be asked to perform, and it is the only condition in which these models differ.

### 5.2 Missed-hazard rate is necessary and not sufficient

Having established that accuracy is the wrong metric, the natural substitute is missed-hazard rate. Our leave-one-class-out results show this to be insufficient in a specific and consequential way.

A missed-hazard metric counting only the fully passive response scores a hazardous window answered with *Request Verification* as a success. On withheld Mixture, seven of eight models satisfy that metric — all bounded below 2.9% at 95% confidence — while escalating between 0.5% and 100% of the same windows. An operator running the support-vector configuration would receive no notification for 99.5% of windows of the most hazardous class in the corpus, and the safety metric would report success.

This is the paper's most transferable finding, and it is not specific to gas monitoring. **Wherever a graded response hierarchy is learned, a metric defined on the most extreme failure will be satisfied by systematic under-response one rung above it.** The remedy is to define the metric at the operationally meaningful threshold — here, whether an operator is notified — rather than at the worst conceivable outcome.

Section 4.6 shows the converse trap with equal force. Under complete sensor loss the cost-weighted policy and the threshold rule score perfectly on missed hazard and escalation by escalating everything, at 1,800 alarms per hour per detector; gradient boosting scores perfectly on false alarms by missing 60% of hazards. Each of the three metrics, alone, certifies a different model as safe. Only together do they describe what the system does.

### 5.3 What the cost asymmetry did and did not do

The cost sweep returns no effect on missed-hazard rate or escalation adequacy at any ratio from 1:1 to 20:1, with an accuracy penalty above 6:1. We take this seriously rather than setting it aside, because the asymmetric objective was the mechanism by which the pipeline was expected to be safe.

The explanation is structural, and it generalizes: **on a saturated, well-separated benchmark a safety objective cannot be validated, because the unsafe behavior it exists to suppress does not occur.** Demonstrating that a cost asymmetry works requires a corpus with genuine overlap between hazardous and benign states, or a metric under which sub-alarm responses carry cost. Section 4.3 supplies the second, and there the cost-weighted policy escalates 22.6% of unseen Mixture windows against gradient boosting's 100%.

A reader may reasonably ask what, then, the learned policy contributes. On this evidence: in nominal conditions, nothing that a depth-3 decision tree does not contribute, at 3.3 fewer accuracy points and identical safety behavior. Its advantages are narrow and specific — full escalation on unseen Smoke where the perceptron misses 9.49%, and zero missed hazards under 50% calibration drift where gradient boosting misses 7.75% — and each is purchased with a false-alarm cost under sensor loss that the tree ensembles do not incur. We present it as such rather than as a general improvement.

We would go further about the objective itself. Eq. 2 weights *samples* by class hazard but treats all incorrect actions identically: under-escalating a hazardous window to *Request Verification* and over-escalating it to *Emergency Shutdown* incur exactly the same loss. That is not a cost asymmetry in the sense the safety argument requires, and it is the most plausible mechanical explanation for the escalation behavior in Section 4.3. An ordinal or full cost-matrix objective, in which distance and direction along the action ladder both carry cost, is the natural next design and is not tested here.

### 5.4 Implications for deployment

Three conclusions hold across configurations and are, we believe, the portable engineering content of this study.

**Language models belong outside the decision path.** The safety argument and the latency arithmetic converge: a 14.7 s synchronous path against a 2 s budget is not a tuning problem, and a model that could alter an action it cannot be verified to justify would be a hazard even if it were fast.

**Quantization and sensor-loss behavior are alarm-management decisions, not modeling decisions.** INT8 introduced 5.8 alarms per hour per detector; losing one sensor of seven introduced 211. Whether either is acceptable is a facility judgment about operator load, and it cannot be made from an accuracy table.

**Qualification must be sustained and must include sensor loss.** A 36-minute run halved the latency margin through thermal throttling alone, and single-channel dropout — the most operationally likely fault for a fixed detector — separates models that are identical on every clean-condition metric.

### 5.5 What this study does not establish

This study does not establish that the pipeline detects hydrocarbons; the corpus contains none. It does not establish that any model here is fit for service; the largest observation count supporting any zero-count claim is 7,905 evaluations, bounding a miss rate at 0.038% and no lower. It does not establish that the coordination and explanation components improve safety outcomes; they are apparatus, are not experimentally isolated, and no result here depends on them. And it does not rank the models, because the design cannot.

What it does establish is that the evaluation conventions of this literature are not fit for the purpose the literature claims, and that a metric set costing a few additional columns per experiment reverses model-selection decisions on this corpus.

---

## 6. Limitations and Threats to Validity

**Analyte validity.** The corpus contains incense smoke, alcohol-based vapor and their mixture. These are surrogates. No result establishes detection performance for methane or heavier hydrocarbons; external validity to petroleum facility monitoring is argued from the shared MOX transduction mechanism, not demonstrated.

**Single-session, single-device provenance.** All 6,400 samples derive from one acquisition session on one device. Sensor ageing, inter-device variability, seasonal ambient variation, wind, hydraulic transients and long-term drift are unrepresented. Cross-session and cross-device validation is the single most important outstanding experiment.

**Statistical power.** Five paired seeds cannot resolve differences at α = 0.05 under a Wilcoxon signed-rank test, whose minimum attainable two-sided *p* at *n* = 5 is 0.0625. No ranking among the models is asserted and none should be inferred.

**Metric scope.** Missed-hazard rate counts only the fully passive action; escalation adequacy is reported alongside it for that reason. A graded expected-cost formulation over a full action-distance cost matrix would be preferable and is not attempted.

**Perception split.** The thermal-image split is randomized over consecutive frames from a single session and is subject to the leakage mechanism the sensor-side protocol excludes. The image corpus was unavailable at revision time, so this could not be corrected; 98.8% is an optimistic upper bound and no conclusion in this paper rests on it.

**Anomaly severity ordering.** The anomaly score separates hazardous from benign conditions by two orders of magnitude but is not monotone in target severity (Mixture scores below Smoke). It should be read as evidence of abnormality only.

**Edge measurements not re-run.** Section 4.7 is carried forward from the original hardware campaign on the earlier data pipeline; its decision-accuracy figures are not directly comparable with Sections 4.2–4.6, though its latency, footprint and thermal measurements are unaffected.

**Modality scope.** The action policy consumes sensor dynamics and the anomaly score only. Visual evidence informs the perception and explanation paths, not the action.

**Coordination layer.** The components that coordinate, critique and supervise the pipeline are described as apparatus, are not experimentally isolated, and no claim depends on them.

**Perturbation realism.** Drift is modeled as a per-channel gain and baseline shift applied at test time, and dropout as channel zeroing. Neither reproduces the temporal character of real MOX ageing.

---

## 7. Conclusions

We evaluated an edge-deployable gas-monitoring pipeline under a safety-relevant metric set rather than accuracy alone, on a public MOX benchmark of laboratory surrogates, under a leakage-controlled block-wise holdout with seed-varying partitions.

1. **In distribution, the metric set does not discriminate.** Ten multiclass models spanning very different inductive biases lie within 4.7 accuracy points and all but one record zero missed hazards, escalation adequacy of 1.000 and zero high-severity false alarms. A depth-3 decision tree on seven raw sensor channels matches every learned model on all three safety metrics.

2. **Out of distribution, accuracy ranking carries no information about safety behavior.** Withholding one hazardous class separates the same models by more than two orders of magnitude in missed-hazard rate (9.49%, 95% bound 10.05%, against a 0.038% bound), a separation nothing in the in-distribution table anticipates.

3. **Missed-hazard rate is necessary but not sufficient.** On a second unseen hazardous class, seven of eight models bound their miss rate below 2.9% while escalating between 0.5% and 100% of the same windows — a factor of 198 on the quantity that determines whether an operator is notified, invisible to a miss metric that counts only the fully passive response.

4. **A cost-asymmetric objective produced no measurable safety benefit**, at any ratio from 1:1 to 20:1, and degraded accuracy above 6:1. Where hazardous and benign states are well separated and the target action is a deterministic function of the class, no error surface exists for a safety objective to reshape.

5. **Under graded sensor loss, three distinct failure modes appear, and each single metric certifies a different model as safe.** Fail-loud models reach a 100% false-alarm rate — 1,800 alarms per hour per detector — while scoring perfectly on missed hazard; fail-silent models hold zero false alarms while missing 60% of hazards. Losing one sensor of seven moves the cost-weighted policy from zero to 211 alarms per hour while leaving the random forest unaffected.

Taken together, these results argue that missed-hazard rate with a confidence bound, escalation adequacy, false-alarm burden in alarm-management units, and degradation of all three under graded sensor loss and drift should be reported as standard alongside accuracy in machine-learning studies of gas-hazard monitoring. On the evidence here, an evaluation reporting accuracy alone would have been uninformative about every one of these behaviors, and each safety metric taken alone would have selected a different model.

Priorities for further work, in order: cross-session and cross-device validation; evaluation on a corpus containing a controlled hydrocarbon release; an ordinal or cost-matrix objective in which under- and over-escalation are priced differently; class-conditional conformal prediction (Angelopoulos and Bates 2023) to convert observed zero-miss counts into distribution-free coverage guarantees on the hazardous class; and a properly powered comparison over randomized runs with an equivalence analysis (Benavoli et al. 2017; Bouthillier et al. 2021).

---

## Nomenclature

| Symbol | Definition |
|---|---|
| *a* | safety action, *a* ∈ {0, 1, 2, 3, 4} |
| *a*\*(·) | acceptable target-action map from gas class to action set |
| *C* | cost ratio, *C* = *c*_miss / *c*_false |
| *c*_miss, *c*_false | loss weights for hazardous and non-hazardous training samples |
| *E*ₜ | operator-facing explanation at cycle *t* |
| *G* | embargo length between training and test partitions, in windows |
| *g*ₜ | ground-truth gas class for window *t* |
| *h* | CUSUM decision threshold |
| *I*ₜ | thermal image at cycle *t* |
| *k* | number of sensor channels removed (dropout severity) |
| *L*(θ) | cost-weighted cross-entropy objective, Eq. 2 |
| *N* | number of training samples |
| *n* | number of observations or paired runs |
| *p*_θ | action probability distribution under parameters θ |
| *S*ₜ | CUSUM statistic at step *t* |
| **X**ₜ | seven-channel sensor window, **X**ₜ ∈ ℝ^(20×7) |
| **δ**ₜ | per-sensor change across the window |
| θ | model parameters |
| μ₀ | CUSUM baseline mean, estimated on NoGas training windows |
| ρ̃ₜ | normalized reconstruction-error anomaly score |
| **σ**ₜ | per-sensor standard deviation across the window |
| σ | additive-noise standard deviation (Section 4.6) |
| τ | anomaly detection threshold |
| φₜ | 22-dimensional decision state, Eq. 1 |

**Subscript.** *t* — inference cycle or window index.

**Abbreviations.** CP, Clopper–Pearson; ECE, expected calibration error; ESD, emergency shutdown; FA, false alarm; LOCO, leave-one-class-out; MOX, metal-oxide semiconductor; ROC-AUC, area under the receiver operating characteristic curve; SD, standard deviation; SIS, safety instrumented system; VOC, volatile organic compound.

---

## Acknowledgments

This research was supported by the Subsurface Energy and Digital Innovation Center (SEDI) at the University of Wyoming. The MultimodalGasData corpus is used under CC BY 4.0; the authors thank Narkhede et al. for making it public.

## Author Contributions

**B. C. Nweke:** conceptualization, methodology, software, investigation, formal analysis, data curation, visualization, writing — original draft. **G. Ramezan:** conceptualization, methodology, writing — review and editing. **S. Saraji:** conceptualization, supervision, project administration, resources, writing — review and editing.

## Declaration of Competing Interest

The authors declare no known competing financial interests or personal relationships that could have appeared to influence the work reported in this paper.

## Data and Code Availability

The MultimodalGasData corpus is publicly available (Narkhede et al. 2022) under CC BY 4.0. Experiment drivers, the safety-metric module, the additional baselines, model checkpoints and the result files underlying Tables 5–9 are available from the corresponding author. See Appendix B.

---

## References

Adegboye, M. A., Fung, W. K., and Karnik, A. 2019. Recent Advances in Pipeline Monitoring and Oil Leakage Detection Technologies: Principles and Approaches. *Sensors* 19 (11): 2548. https://doi.org/10.3390/s19112548.

Angelopoulos, A. N. and Bates, S. 2023. Conformal Prediction: A Gentle Introduction. *Foundations and Trends in Machine Learning* 16 (4): 494–591. [CITATION NEEDED — verify volume and pagination]

Benavoli, A., Corani, G., Demšar, J. et al. 2017. Time for a Change: A Tutorial for Comparing Multiple Classifiers Through Bayesian Analysis. *Journal of Machine Learning Research* 18 (77): 1–36.

Bouthillier, X., Delaunay, P., Bronzi, M. et al. 2021. Accounting for Variance in Machine Learning Benchmarks. *Proc., Machine Learning and Systems (MLSys)* 3: 747–769. [CITATION NEEDED — verify pagination]

Bustnes, T. E., Rousselet, M., and Berland, S. 2011. Leak Detection Performance of a Commercial Real-Time Transient Model. Paper presented at the PSIG Annual Meeting, Napa Valley, California, 24–27 May. PSIG-1114.

Clopper, C. J. and Pearson, E. S. 1934. The Use of Confidence or Fiducial Limits Illustrated in the Case of the Binomial. *Biometrika* 26 (4): 404–413. https://doi.org/10.1093/biomet/26.4.404.

Dehnaw, A. M., Manie, Y. C., Yao, C.-K. et al. 2024. Deep Neural Network Optimization for Efficient Gas Detection Systems in Edge Intelligence Environments. *Processes* 12 (12): 2638. [CITATION NEEDED — verify author list and issue]

Dennler, N., Rastogi, S., Fonollosa, J. et al. 2022. Drift in a Popular Metal Oxide Sensor Dataset Reveals Limitations for Gas Classification Benchmarks. *Sensors and Actuators B: Chemical* 361: 131668. [CITATION NEEDED — verify volume and article number]

EEMUA. 2013. *Alarm Systems: A Guide to Design, Management and Procurement*, third edition. EEMUA Publication 191. London: Engineering Equipment and Materials Users Association.

El Barkani, M., Benamar, N., Talei, H. et al. 2024. Gas Leakage Detection Using Tiny Machine Learning. *Electronics* 13 (23): 4768. https://doi.org/10.3390/electronics13234768.

Elkan, C. 2001. The Foundations of Cost-Sensitive Learning. *Proc., 17th International Joint Conference on Artificial Intelligence (IJCAI)*, Seattle, Washington, 4–10 August, 973–978.

Faleh, R. and Kachouri, A. 2023. A Hybrid Deep Convolutional Neural Network-Based Electronic Nose for Pollution Detection. *Chemometrics and Intelligent Laboratory Systems* 237: 104825. https://doi.org/10.1016/j.chemolab.2023.104825.

Goel, P., Datta, A., and Mannan, M. S. 2017. Industrial Alarm Systems: Challenges and Opportunities. *Journal of Loss Prevention in the Process Industries* 50: 23–36. https://doi.org/10.1016/j.jlp.2017.09.001.

Google DeepMind. 2025. Gemma 3 Technical Report. [CITATION NEEDED — cite the Gemma 3 report with correct year and identifier]

Han, P. and Kim, M. 2014. Optimizing Leak Detection Performance. Paper presented at the PSIG Annual Meeting, Baltimore, Maryland, 6–9 May. PSIG-1407.

IEC. 2016. *Functional Safety — Safety Instrumented Systems for the Process Industry Sector — Part 1*, IEC 61511-1:2016. Geneva: International Electrotechnical Commission.

ISA. 2016. *Management of Alarm Systems for the Process Industries*, ANSI/ISA-18.2-2016. Research Triangle Park, North Carolina: International Society of Automation.

Jessen, H. and Roshchin, M. 2025. Agentic AI Revolution Across Oil and Gas Value Streams. Paper SPE-229240-MS presented at ADIPEC. [CITATION NEEDED — verify location and dates]

Jocher, G., Chaurasia, A., and Qiu, J. 2023. YOLOv8 by Ultralytics. https://github.com/ultralytics/ultralytics.

Korjani, M., Conley, D., and Smith, M. 2024. Temporal Deep Learning Image Processing Model for Natural Gas Leak Detection Using OGI Camera. Paper OTC-34756-MS presented at the Offshore Technology Conference Asia. [CITATION NEEDED — verify location and dates]

Laberge, J. C., Bullemer, P., Tolsma, M. et al. 2014. Addressing Alarm Flood Situations in the Process Industries Through Alarm Summary Display Design and Alarm Response Strategy. *International Journal of Industrial Ergonomics* 44 (3): 395–406. https://doi.org/10.1016/j.ergon.2013.11.008.

Liang, J., Liang, S., Zhang, H. et al. 2024. Leak Detection in Natural Gas Pipelines Based on Unsupervised Reconstruction of Healthy Flow Data. *SPE Prod & Oper* 38 (3): 513–526. [CITATION NEEDED — verify pagination, SPE paper number and DOI. The earlier draft cited this as SPE Journal; it appeared in SPE Production & Operations]

Malhotra, P., Ramakrishnan, A., Anand, G. et al. 2016. LSTM-Based Encoder-Decoder for Multi-Sensor Anomaly Detection. arXiv:1607.00148 (preprint, submitted 1 July 2016).

Murvay, P.-S. and Silea, I. 2012. A Survey on Gas Leak Detection and Localization Techniques. *Journal of Loss Prevention in the Process Industries* 25 (6): 966–973. https://doi.org/10.1016/j.jlp.2012.05.010.

Narkhede, P., Walambe, R., Mandaokar, S. et al. 2021. Gas Detection and Identification Using Multimodal Artificial Intelligence Based Sensor Fusion. *Applied System Innovation* 4 (1): 3. https://doi.org/10.3390/asi4010003.

Narkhede, P., Walambe, R., Chandel, P. et al. 2022. MultimodalGasData: Multimodal Dataset for Gas Detection and Classification. *Data* 7 (8): 112. https://doi.org/10.3390/data7080112.

Page, E. S. 1954. Continuous Inspection Schemes. *Biometrika* 41 (1/2): 100–115. https://doi.org/10.1093/biomet/41.1-2.100.

Sabbagh, V. B., Lima, C. B. C., and Xexéo, G. 2024. Comparative Analysis of Single and Multiagent Large Language Model Architectures. *SPE J.* 29 (12): 6869–6884. [CITATION NEEDED — verify issue and SPE paper number]

Santiago, C. J. S., Shumaker, N., and Weir, A. 2025. Integrating Data-Driven Insights with Domain Expertise Using Agentic Conversational Analytics. Paper SPE-228143-MS presented at the SPE Annual Technical Conference and Exhibition. [CITATION NEEDED — verify location and dates]

Sharma, A., Kumar, R., Singh, P. et al. 2024. Gas Detection and Classification Using Multimodal Data Based on Federated Learning. *Sensors* 24 (18): 5904. https://doi.org/10.3390/s24185904. [CITATION NEEDED — verify author list]

Vergara, A., Vembu, S., Ayhan, T. et al. 2012. Chemical Gas Sensor Drift Compensation Using Classifier Ensembles. *Sensors and Actuators B: Chemical* 166–167: 320–329. https://doi.org/10.1016/j.snb.2012.01.074.

Wang, Z., Schaul, T., Hessel, M. et al. 2016. Dueling Network Architectures for Deep Reinforcement Learning. *Proc., 33rd International Conference on Machine Learning (ICML)*, New York City, 19–24 June, 1995–2003.

Zhang, E. and Zhang, E. 2025. Gas Pipeline Leakage Detection Based on Multiple Multimodal Deep Feature Selections and Optimized Deep Forest Classifier. *Frontiers in Environmental Science* 13: 1569621. [CITATION NEEDED — verify article number]

Zhang, J., Hoffman, A., Murphy, K. et al. 2013. Review of Pipeline Leak Detection Technologies. Paper presented at the PSIG Annual Meeting, Prague, Czech Republic, 16–19 April. PSIG-1303.

---

## Appendix A — Items Still Requiring Author Action

**This appendix is a work list, not for publication.** Everything else in this manuscript is supported by a result file generated for this revision.

**A.1 — Cannot be resolved without data not currently on disk.**

1. **Perception split (Section 3.3, Table 4).** The thermal image corpus (`data/Thermal Camera Images`) is empty in the working tree, so the randomized image split could not be replaced with a block-wise one. Restore the images, re-split block-wise, and re-report. If accuracy falls, that is a reportable result supporting the paper's own argument.
2. **Edge deployment (Section 4.7, Table 10).** Requires the Raspberry Pi 4. The latency, footprint and thermal figures are hardware measurements and stand; the decision-accuracy column was produced on the earlier data pipeline and is not comparable with Sections 4.2–4.6. Re-run the replay on the corrected pipeline, and add escalation adequacy and alarm burden to each row.

**A.2 — Recommended before submission.**

3. Re-select the deployed cost ratio on a held-out validation split rather than on test-partition dispersion (Section 4.4).
4. Implement and evaluate an ordinal or cost-matrix objective in which under-escalation and over-escalation are priced differently (Section 5.3). This is the design the paper's own evidence points to and would likely be the strongest addition available.
5. Re-run the calibration experiment (expected calibration error) on the corrected pipeline with class-conditional and debiased estimators, bootstrap intervals and reliability diagrams. The earlier calibration results were produced on a different data path and are omitted from this revision rather than carried forward.
6. Raise the run count from 5 to ≥ 29 randomized runs and add an equivalence analysis over a region of practical equivalence, so that a positive claim of practical equivalence can be made rather than merely a disclaimer of power (Section 3.6).
7. Reconcile the false-alarm denominator across the codebase: `retrain/metrics.py` divides false alarms by the number of alerts, whereas this manuscript divides by the number of clean windows. They coincide only at zero, and only the latter converts to alarm burden.
8. Resolve every `[CITATION NEEDED]` in the reference list, and confirm that Liang et al. (2024) is cited to *SPE Production & Operations*, not SPE Journal.

**A.3 — Terminology, resolved in this revision but requiring author sign-off.** The earlier draft described the decision component as trained by offline reward-shaped reinforcement learning, with an asymmetric reward, ε-greedy action selection, replay episodes, cumulative reward and a Huber loss. The model producing every number in this paper is trained by cost-weighted cross-entropy against targets from the deterministic map *a*\*(·), as described in Section 3.3 and Eq. 2. The description here is the correct one; all reinforcement-learning language and the associated training-dynamics figure have been removed. **This correction should carry explicit sign-off from all authors.**

---

## Appendix B — Reproducibility Statement

**Pipeline.** Windows of length 20 are formed over the raw corpus; windows spanning a class boundary are discarded, giving 6,324 windows (1,581 per class). The anomaly feature is the mean reconstruction error of the full 20-step window under the pretrained NoGas autoencoder. The block-wise holdout reserves a contiguous 20% of each class block for test, separated from both training segments by a 20-window embargo, with the held-out block's position drawn from the run seed. Feature standardization and anomaly-percentile normalization are fitted on the training partition only. In the leave-one-class-out experiment they are fitted on the three training classes only, so no statistic of the withheld class enters training.

**Protocol.** Five seeds (42, 1337, 7, 2024, 99), each with its own partition. PyTorch determinism guards enabled, single-threaded execution. Every experiment reported in Sections 4.1–4.6 was executed in a single uninterrupted run for this revision.

**Artifacts.** `retrain/safety_metrics.py` (metric set and Clopper–Pearson bounds); `retrain/new_baselines.py` (k-NN, threshold rule, CUSUM); `retrain/run_all_v2.py` (model comparison, cost sweep, perturbation, ablation, anomaly evaluation); `retrain/run_loco_v3.py` (leave-one-class-out with three-class scaling); `retrain/make_figs_v2.py` (Figs. 1–6). Results: `retrain/results_v2/v2_zoo.csv`, `v2_zoo_sig.json`, `v2_loco.csv`, `v2_costsweep.csv`, `v2_perturb.csv`, `v2_ablation.csv`, `v2_anomaly.json`.

**Figure palette.** Categorical colors were validated against a colorblind-separation, chroma, lightness and contrast check; the green–orange pair sits in the marginal separation band, so every categorical mark also carries a direct value label as secondary encoding.
