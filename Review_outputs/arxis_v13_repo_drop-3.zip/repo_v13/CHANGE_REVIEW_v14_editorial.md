# Change review: the editorial pass on structure, Summary and style

This round answers an editorial review rather than a technical one. Nothing in the science moved, no experiment was re-run, and no number changed. What changed is the shape of the paper and the way it talks.

State after this round: `verify_v13.py` **963 checks, 1 deliberate failure**. `self_audit.py` **951 checks, 0**. `test_safety_metrics.py` **30 assertions, 0**. `audit_release.py` **0 problems**. The one open failure is still the Ultralytics version placeholder in Appendix A.

---

## Structure

The reviewer's main structural objection was that the paper reached a general Discussion and then introduced two more experiments after it, and that the Model Application section carried substantial new quantitative analyses that change interpretation and in one case reverse model ordering. Both are fixed.

Experiments 8 and 9 now precede the Discussion. The two eventization analyses, alarm episodes and hazard episodes, moved out of Model Application and into Results, where the tables they produce sit alongside the perturbation sweep whose numbers they reinterpret. Model Application became **Engineering Implications** and now carries only what follows from the results: the metric-disagreement view, the proposed screen, the reporting-units argument, the Discussion material and future work.

Section names follow the reviewer's scheme. Prior Research Review became **Related Work and Positioning**, Proposed Method became **Methodology**, Experimental Results and Discussion became **Results**, and Conclusion became **Conclusions**.

Three tables renumbered as a consequence. The proposed screen moved from Table 14 to Table 16, and the two eventization tables from Tables 15 and 16 to Tables 14 and 15, following their content into Results.

The Results section now narrates six experiments that answer a research question, with Experiments 4, 5 and 7 grouped into a single supporting subsection rather than three. The reviewer asked for the cost-ratio sweeps, ordinal-objective mechanics, calibration details and ablation details to be retained but moved out of the main narrative, which is what that grouping does: each keeps the one finding the rest of the paper cites and points at its supporting section for everything else.

---

## Summary and title

The Summary was 565 words and functioned as a mini-Discussion. It is now **404**, against the reviewer's target of 350 to 400. The reject-option and raw-fault findings are compressed into one sentence, the "one in eleven" uncertainty discussion is gone from the Summary and kept where it is derived, and the scope limits are one clause rather than a paragraph. The reviewer also caught a terminology slip the previous round had introduced: the Summary called the 0.011 against 0.245 comparison "reconstruction error" when it is the normalized anomaly feature. Fixed.

The title is now **ARXIS: Safety-Oriented Evaluation of Learned Gas-Monitoring Models Under Class Exclusion and Sensor Degradation**, the reviewer's preferred option, propagated to the supporting information and the repository.

One tension is worth flagging rather than deciding silently. The paper states in several places that the evaluated object is the sensor-policy core and not the running ARXIS system, and warns against reading its tables as a characterization of that system. A title beginning "ARXIS:" invites exactly that reading. The reviewer offered an unbranded alternative, and switching to it is a one-line change if that reading is the greater risk.

---

## Writing

The review listed eleven rhetorical constructions appearing at high density. All of them are gone: "this is worth stating precisely," "worth being exact about," "that is worth knowing," "worth saying which way," "two further patterns are worth noting," "three things follow," "the threat this poses is worth naming," "that is the point," "the practical rule is," "the objection is reasonable," and "a reader who takes that view would." Each was replaced with the pattern the reviewer asked for: result, qualification, engineering implication, then stop.

"Rather than" fell from 93 occurrences to 55, and the not-X-but-Y formula with it, though the contrast structure remains where the contrast is the finding.

Two errors surfaced during the rewrite. The Conclusions opened "Four findings follow" above five findings, and its closing scope paragraph still said the held-out-class tests carry no reject option and that the degradation regimes are perturbations of standardized features, both of which Experiments 8 and 9 had made false.

---

## Repeated caveats

Each limitation now gets one definitive treatment. The overlap-and-dependence caveat was stated in full in two places; the Limitations copy is now a cross-reference to the Methodology derivation. The statistical-power section dropped the claim-caveat-counterargument-caveat chain around ρ while keeping both qualifications the earlier reviews required, that the correlated *t*-test is a sensitivity analysis over an assumed dependence structure and that its agreement with the paired bootstrap is not independent confirmation. The action-ladder, persistence-rule and perturbation-realism entries each lost a restatement of something already said.

---

## Length, and where it stopped

The reviewer asked for a 25 to 30 percent reduction. The body went from **23,223 words to 20,621, a cut of 11.2 percent**. That is short of the target and the gap is worth being precise about rather than rounding away.

What was cut: the defensive explanation and repeated caveats the review named, the Summary, the three supporting experiments' main-narrative treatment, the two large eventization tables condensed to their informative rows, and prose restating tables.

What was not: the qualifications four earlier review rounds required. The bound-versus-estimate language, the constructed-target declarations, the class-exclusion-is-not-domain-shift statements, the descriptive-counts framing on the episode tables, the persistence-rule sensitivity, and the disjoint-support treatment together account for well over a thousand words, and each exists because a referee showed a claim outrunning its evidence. Cutting to 25 percent from here means deleting those, which trades one reviewer's objection for another's.

Two further reductions are available if wanted, and both are decisions rather than edits. Experiments 4, 5 and 7 could leave the body entirely, replaced by two sentences and a pointer, saving about 600 words. The Nomenclature section, 529 words, could move to the supporting information if SPE permits. Together those would reach roughly 16 percent.

The internal word bands in `verify_v13.py` were retightened to the new structure so that they bind rather than sit slack: Summary 300 to 420, Methodology 1800 to 3600, Engineering Implications 700 to 1800, Limitations 500 to 1200, Conclusions 300 to 560.

---

## What the condensed tables cost, and the gates that cover it

Tables 14 and 15 in the body are now selected rows, with the complete tables added to the supporting information as Tables S11 and S12 under a new Section S13. Condensing meant some Table 15 rows name a count of models rather than one model, which is a claim about every comparator not listed separately for that condition. Those grouped rows are checked against `v3_episode_metrics.csv` by four new gates rather than trusted, because a hand-typed grouping is exactly the kind of thing that has gone wrong in this manuscript before. The full SI tables were generated from the result files, not transcribed.

Nine verification gates were rewritten to follow reworded prose. In each case the gate still checks the same substantive claim; where a gate was checking only a stylistic flourish that the review asked to remove, that clause was dropped and the substantive half kept.

---

## On the AI-writing observation

The review is right that no phrase proves authorship, and its recommendation was to remove meta-commentary and repetition rather than to swap vocabulary. That is what was done. No text was made deliberately awkward, no words were substituted to defeat a detector, and no sentence was lengthened or shortened for any reason other than clarity. Anything the journal requires by way of disclosure is a matter for the authors and the journal's current policy.

---

## A defect this round introduced, and the gates that now cover it

The previous round added a Kumar et al. (2024) reference and then moved it to keep the reference list alphabetical. The move located the insertion point with `t.index("Laberge")`, which finds the *first* occurrence of that string in the file. That was not the Laberge reference entry; it was an in-text citation in the Introduction. The full reference, journal, volume, pages and DOI, was spliced into the middle of a sentence about alarm burden, splitting it across a paragraph break.

It shipped. The manuscript delivered at the end of that round carried a broken sentence in its second page, and every suite passed, because the reference-ordering gate reads only the References section and nothing was checking the body for reference-shaped text.

The sentence is restored and the reference is in the reference list where it belongs. Three gates now cover the class of fault rather than the instance: no reference-style entry may appear in body prose, no bare DOI or URL may appear in body prose outside a table or the availability statement, and every surname cited in the body must have a matching reference entry with no orphans in either direction. The gates were checked by re-injecting the exact fault and confirming two of them fire.

The third gate is the one that would have caught it earliest, and it is worth saying why it did not exist: the paper had never had a citation without an entry, so nothing prompted the check. That is the wrong reason to leave a gate out, and it is the same reasoning that left the averaged-pseudocount bound unchecked several rounds ago.

## One reference added from the OnePetro sweep

**Lima, F. de A., Copetti, A., Bertini, L. et al. 2026. Autoencoders for Early Kick Detection: Improving Safety in Offshore Oilwell Drilling.** *SPE J.*, published online 10 June 2026, SPE-231854-PA. It supports the Related Work sentence about reconstruction-based sequence models in field monitoring, alongside Malhotra et al. (2016) and Liang et al. (2023), and it is the nearest same-venue precedent: an autoencoder detector for a safety-critical event, in the SPE Journal Data Science and Engineering Analytics collection this manuscript targets.

The record comes from the collection listing, which gives the author list, the publication date and the DOI. Volume, issue and pages are not quoted because the article page sits behind a bot check that was not worked around, so the entry uses the online-first form. If the paper has since been assigned to an issue, that should be filled in before submission.

Three further candidates were identified and **not** added, because the search results give volume, issue and first page but not author lists, and an SPE reference cannot be written without them. They are listed with their locations in the OnePetro sweep document, and each needs the article record confirmed before use.
