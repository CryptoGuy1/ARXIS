# Change review: the 14 September technical review, and the supervisor's notes

Two inputs arrived together. One was a technical review of v13 organized in five parts. The other was a set of marked-up screenshots from the supervisor, whose comments were shorter and pointed at different things: the paper is already big enough, there are too many block diagrams, and the repository does not match the paper.

State after this round: `verify_v13.py` **953 checks, 1 deliberate failure**. `self_audit.py` **1,062 checks, 0**. `test_safety_metrics.py` **30 assertions, 0**. `audit_release.py` **0 problems**.

The one open failure is the Ultralytics version in Appendix A. Nothing in the repository records which version trained the thermal classifier, `requirements.lock` says `not installed`, and the checkpoint is not in this workspace. It stays a placeholder rather than becoming a plausible-looking guess.

---

## The reject-option threshold was set in sample, and that was indefensible

This is the largest change of the round and it was not on the review's list. Item 4.4 asked why the *q* = 0 row of Table 12 does not reproduce the corresponding Table 10 entry if the two come from different checkpoints or training paths. Chasing that turned up something worse than a provenance gap.

The Experiment 8 threshold was the *q*-th percentile of confidence on the **training** windows. A paper whose first experiment exists to show that in-sample estimates mislead had set its own operating threshold in sample. The review's question was about bookkeeping; the honest answer was that the construction needed replacing.

It now is. A contiguous 20% tail of each class block is carved off as a calibration band before anything is fitted, separated from the fitting windows by the same 20-window embargo the outer holdout uses. The threshold is set there. Experiment 8 was re-run end to end.

**Every number in Table 12 and Table S9 changed.** The direction of the findings did not, but their size did, and two claims had to be withdrawn outright.

| Claim, before | After |
|---|---|
| SVM escalation repaired 0.0049 → 0.9283 | 0.0030 → 0.7111 |
| clean-window rejection at that threshold, 57.3% | 41.2% |
| cost-weighted 0.2634 → 0.8391 | 0.3750 → 0.9256 |
| separation range +52.0 to −97.0 points | +42.4 to −91.6 points |
| "the random forest rejects everything at every threshold" | withdrawn: it rejects 0.95% at *q* = 5 on Smoke |
| "every model rejects more than 30% of held-out clean windows" | withdrawn: *k*-NN rejects 14.9% and 16.5% |
| four of fourteen separation cells non-positive | five |

The repair is smaller than the paper claimed and the price is smaller too. Both were overstated by a threshold fitted on data the model had already seen, which is precisely the effect Experiment 1 measures, arriving in the paper's own methodology.

On the original question, item 4.4: the *q* = 0 row is now explicitly the within-experiment reference and is **expected** to differ from Table 10, because carving out the calibration band leaves a fit partition about a fifth smaller. The Table 12 caption says so and names the size of the gap, which is largest for the two tree ensembles (0.983 and 1.000 in Table 10 against 0.7746 and 0.7857 here). The driver now imports `make` from `run_final` so the constructor is shared and the difference is attributable to the partition rather than to a training-budget accident.

---

## Items answered without a rerun

**4.2, the anomaly column.** Table 13's final column was headed "Anomaly score" and the surrounding prose called it the same thing as Fig. 5's reconstruction errors. They are not the same quantity: Fig. 5 reports raw reconstruction error (0.023 to 164.7) and Table 13 reports the min-max normalized feature ρ̃ of Eq. 1, clipped to [0, 1] against the 1st and 99th training percentiles. The column is now headed "Normalized anomaly feature, ρ̃", both captions say explicitly that it is not on Fig. 5's scale, and the prose in the body, in S12 and in the Conclusion uses the normalized name throughout.

**4.5, the fault labels.** "Open circuit" and "saturated at rail" named specific electrical failures the experiment does not reproduce. They are now "forced raw zero", described as a low-rail proxy, and "high-end clamp", described as a clamp at the largest value seen in training that stands in for a rail-limited reading without reproducing any device's saturation behavior. The mechanism paragraph no longer says "a constant trace is the easiest thing there is to rebuild", which is a claim about reconstruction detectors in general; it says this autoencoder was fitted on clean-air windows only, that a near-constant trace is well inside what it reconstructs easily, and that whether a differently trained detector would behave the same way is untested.

**4.6, per-model evidence.** The claim that every comparator sends every hazardous window below alarm grade under a full clamp is now supported in the body by naming all six comparators and pointing at the column of Table S10 where each reads 0.0000 / 0.0000. S12 adds that this is a statement about all six individually rather than an artifact of reporting a worst case.

**4.7, the second bound.** It is called a "disjoint-support reference bound", never a correction. The floor(*N*/20) counting convention is now stated where the counts appear, together with the fact that a maximal nonoverlapping selection from 316 consecutive windows holds 16 rather than 15 and that the smaller figure is taken deliberately. The Summary no longer says an observed zero is compatible with "about one in eleven"; it says the data cannot exclude several percent, and roughly 9% under the most conservative reference count, and calls both limits on resolution rather than estimates.

---

## The supervisor's notes

**Fig. 3 is no longer a flowchart.** The old figure was five labeled boxes and six arrows. It has been replaced by a three-panel figure: (a) a schematic of the acquisition arrangement the corpus describes, drawn and not to scale, carrying no dimension the corpus does not state; (b) twenty real consecutive rows of the released corpus from one Smoke episode, all seven channels, which is the window the pipeline actually reads; (c) the decision state drawn as the 22 cells it has, with the thermal branch shown contributing none of them. That last panel carries the one structural claim the old figure existed to make. `retrain/make_fig_setup.py`, `make setupfig`.

Retiring a figure that v9 carried would normally trip the inventory gate in `verify_v13.py`. Rather than loosening the gate, it now holds an explicit `RETIRED` map that requires the replacement to be present, so an accidental deletion still fails.

**A label in Fig. 4 contradicted the paper.** The ladder drew action 4 as "Emergency shutdown". The manuscript states in its limitations that action 4 is deliberately *not* called that, because the pipeline actuates nothing. The figure now uses Table 4's label. Three new gates check that the drawn ladder matches the table and that no figure source still contains the old string.

**The paper is shorter.** Roughly 250 words came out of the Results, Proposed Method, Introduction and Conclusion without losing a result: the CQL and CUSUM hyperparameter detail now points at S5 rather than repeating it, the cost-ratio re-selection points at S3, the ρ and ROPE sensitivity keeps its two conclusions and drops its mechanics into S6, and the hourly-conversion caveats are stated once instead of twice. Two errors surfaced while trimming. The Conclusion said "Four findings follow" above five findings. Its closing scope paragraph still said the held-out-class tests carry no reject option and that the degradation regimes are perturbations of standardized features, both of which Experiments 8 and 9 had made false.

**The repository now matches the paper.** The README's target table listed Tables 9, 13, 16 and 18 and Figs. 1 to 20, numbering from a version two revisions old, and pointed at `verify_v11.py`. It has been rewritten against the current objects, and it now names the two labels in this repository that read as stronger claims than the code supports: `SupervisedDQN` is a DuelingDQN architecture trained with cross-entropy and is not a reinforcement-learning agent, and action 4 is `Recommend ESD assessment` and not an emergency shutdown. The citation block records that the submitted state is tagged `v13-submission` and that a reviewer should check out the tag rather than the tip of the branch. The Data and Code Availability statement says the same and notes that an archival DOI is added once the deposit is minted. No DOI is quoted, because none exists yet.

---

## One reference added

Four references had been left uncited because the egress policy blocked Crossref and OpenAlex and inventing volume numbers was not acceptable. One is now verified and added: Kumar, Singh and Pandey (2024), *Transactions on Electrical and Electronic Materials* 25 (5): 653-664, a modality comparison for gas-leak detection scored on classification accuracy and precision. It supports the Prior Research paragraph's claim about what that literature measures. The other three remain uncited. Its accuracy figures are not quoted, because the abstract does not give them and the full text was not reachable.

---

## What is still open

The Ultralytics version. The three unverified references. The thermal image set is still split randomly rather than block-wise, which the Supporting Information states plainly and which remains the largest outstanding piece of work in the artifact.
