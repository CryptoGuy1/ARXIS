# What the four model papers do, measured

Four SPE Journal papers were read programmatically rather than by eye, so the numbers below are measurements and not impressions.

| | Paper | Pages | Words | Figs | Tables |
|---|---|---|---|---|---|
| A | SPE-205365-PA, *Machine Learning for Deepwater Drilling: Gas-Kick-Alarm Classification* (Aug 2021) | 27 | 19,699 | 19 | 8 |
| B | SPE-230320-PA, *Scanning Strategy Optimization of Pan-Tilt TDLAS* (Dec 2025) | 16 | 8,072 | 13 | 12 |
| C | SPE-231403-PA, *Sample Quality Evaluation using Reinforcement Learning* (Jan 2026) | 20 | 13,302 | 19 | 8 |
| D | SPE-234709-PA, *A Lightweight YOLOv13 Variant for Real-Time Cavings Detection* (Sep 2026) | 14 | 8,712 | 11 | 6 |

Paper A is the closest in subject: gas, alarms, classification, and a safety framing. Paper D is the closest in figure craft and is the one the diagram work here was modelled on.

---

## 1. Summary

**All four are a single unbroken paragraph.** Not one has a paragraph break. Word counts: A 438, B 164, C 336, D 214.

Ours was 404 words across five paragraphs. It is now **417 words in one paragraph**, which sits inside the range A and C establish. If a hard ceiling turns up in the submission template, A at 438 is the evidence that 417 passes.

The structure all four follow: problem, what was done, what was found, what it implies. No scope-limit paragraph of its own; scope goes in a trailing clause, if anywhere.

---

## 2. Captions, which was the largest gap

**Figure captions are one short sentence.** Measured lengths: "Fig. 4—Structure of a GRU unit." (6 words). "Fig. 1—Pan-tilt TDLAS detection device." (5). "Fig. 1—Overall workflow of image-based cavings detection." (7). "Fig. 2—Architecture of the proposed YOLOv13-CavDet." (6).

The only thing that ever follows that sentence is an abbreviation expansion: "Fig. 3—FIN module architecture. GN = group normalization; GConv = graph convolution; SiLU = sigmoid linear unit."

**Table captions are shorter still.** "Table 1—Configuration." (2 words). "Table 2—Hyperparameters." (2). "Table 3—Comparison with different methods." (5).

Ours ran to 135 words with six sentences on Table 12, 98 on Table 10, 85 on Table 13. Twenty-two of thirty-one captions were over 22 words.

Every caption is now one sentence. Nothing was deleted: the qualifications those captions carried are load-bearing, several of them because earlier referees demanded them, so each moved into the body paragraph that introduces or follows its table. The worst-partition bound rule, the reason Table 12's *q* = 0 column differs from Table 10, the normalized-anomaly-feature scale note, the descriptive-counts framing on the episode tables, and the illustrative-conversion caveat on the hourly figures are all still in the paper, in prose, where the model papers put that kind of material.

---

## 3. Figure resolution

Measured on the embedded rasters, as delivered by the publisher:

| Paper | Median dpi | Range | Median pixel width |
|---|---|---|---|
| A (2021) | 200 | 110 to 200 | 537 |
| B (2025) | 300 | 254 to 429 | 1,430 |
| C (2026) | 361 | 286 to 426 | 1,773 |
| D (2026) | 330 | 330 to 411 | 2,033 |

The trend is clear and the oldest paper is visibly the weakest. Published figures land at 300 to 430 dpi *after* downsampling, which means source art goes in higher.

Every figure here is now rendered at **600 dpi**, pinned on each `savefig` call rather than left to a global setting, and checked by a new gate that reads the rendered files. Twenty-four figures, 10 MB total.

Page geometry read off the model papers, for sizing: single column **3.35 in**, one-and-a-half column **4.77 in**, full width **6.81 in**.

---

## 4. Diagram idiom

Paper D's figures are the standard to hit, and they share a vocabulary:

- a **dashed rounded container** per functional block, with a **bold italic label inside its top-left corner** (FIN, C3AH, HyperACE)
- **solid rounded boxes**, one pale fill per family, saturated outline of the same hue
- **circled operators on the wire** for add, subtract, elementwise multiply
- **feature tensors as stacked slabs** in weak perspective
- **span arrows under a region**, labelled beneath (Backbone, Neck, Head)
- **real photographs embedded** in the workflow figure, not drawn stand-ins
- the whole composition **centred**, which is what "centralized on the block" means

Paper A's Fig. 3 adds the flowchart vocabulary: proper decision diamonds, Yes/No edge labels, orthogonal routing, and coloured dashed containers labelled Unit 1, Unit 2, Unit 3.

All of this is now implemented in `retrain/spe_style.py` as drawing primitives, so the diagrams share one vocabulary instead of each being drawn ad hoc.

---

## 5. Section structure

| Paper | Sequence |
|---|---|
| A | Summary → Introduction → Background and Motivation → Experimental Study → Results and Discussion → Conclusions → Nomenclature → Acknowledgments → References |
| B | Summary → Introduction → Methodology → Case Study → Conclusion and Prospects → Nomenclature → Acknowledgments → References |
| C | Summary → Introduction → Methodology → Experimental Results and Analysis → Conclusion → References |
| D | Summary → Introduction → Related Works → Model → Experiments and Analysis → Conclusion → Data Availability → Acknowledgments → References |

Ours already matches after the previous round: Summary → Introduction → Related Work and Positioning → Methodology → Results → Engineering Implications → Limitations → Conclusions → Nomenclature → Acknowledgments → Data and Code Availability → References → Appendix A.

The one difference is Engineering Implications and Limitations, which none of the four carries as separate sections. Both exist because earlier referees asked for them. They stay.

---

## 6. What changed in this round

**Title.** ARXIS is out: *A Safety-Oriented Benchmark for Learned Gas-Monitoring Models Under Class Exclusion and Sensor Degradation*. The branded title invited exactly the misreading the paper spends paragraphs guarding against, that its tables characterize a system rather than a protocol.

**Framed as a benchmark.** The Summary now opens "This paper reports a benchmark study" and states plainly that no new detector is proposed. Keywords lead with benchmarking. The Methodology heading for the pipeline is "The Pipeline Under Test".

**Figure 3 removed.** The acquisition schematic is gone and the figures renumbered. Its driver and Makefile target are deleted, and the retired-figure gate now requires it to be absent from both documents.

**Three architecture figures added**, which the manuscript needed and did not have:

- **Fig. 3**, perception: YOLOv8n-cls backbone and head, with a **real released thermal frame** as the input rather than a drawn box
- **Fig. 4**, anomaly: the LSTM autoencoder, the residual, and the normalized anomaly feature
- **Fig. 5**, decision: the dueling value and advantage streams over the 22-cell state, and where the alarm boundary falls on the action ladder

Shapes come from the implementation, not invention: hidden dimension 32 from `raw_pipeline.py`, the dueling split from `agent_rl.py`, four classes at 224 by 224 from the perception configuration.

**Figures 1 and 6 redrawn** in the model-paper idiom, with real corpus data in Fig. 1: a real thermal frame and a real seven-channel sensor window, not schematic stand-ins.

---

## 7. One factual correction the images forced

The manuscript said the corpus pairs the MOX array with "206 by 156 thermal frames". The released files are **480 by 640**. The Seek Compact sensor is 206 by 156; what ships is a rendered image at 480 by 640 carrying the colour palette and the temperature scale bar. The text now says so.

---

## 8. Still open

**Plotting software.** The result plots are matplotlib. Origin was mentioned as an alternative, and it would change nothing about the data, only the rendering. The case against switching is that every plot is currently regenerated from a result file by a driver the verification suite checks; moving to a GUI tool breaks that chain and reintroduces the hand-transcription risk this project has been bitten by more than once. If the look is the concern, matplotlib can be styled to match Origin's conventions inside the existing pipeline.

**A thermal frame per class.** Only the Mixture class images are present locally, so the figures use a real Mixture frame. A four-panel figure showing one real frame per class would be stronger and needs the other three class folders.

**The Ultralytics version** in Appendix A, unchanged and still the one deliberate verification failure.
