# Change review: three experiments the reviews asked for, now run

Three things every audit of this work recommended had been declined as "a new experiment" rather than attempted. They are all computable from the corpus already in hand, and all three are now in the paper. Two produced findings strong enough to change what the paper concludes.

State after this round: `verify_v13.py` **951 checks, 1 deliberate failure**. `self_audit.py` **1,053 checks, 0**. `test_safety_metrics.py` **30 assertions, 0**. `audit_release.py` **0 problems**.

---

## Experiment 8. What a reject option buys, and what it costs

Every review made the same objection to the class-disjoint experiment: the comparators are closed-set classifiers with no way to decline, so a withheld hazardous class is forced through actions they already know. Every review recommended the same remedy, a reject-option baseline with an operational meaning attached to a rejection.

The construction is deliberately plain. Confidence is the maximum predicted class probability. The threshold is the *q*-th percentile of confidence on training windows, swept from 0, which recovers the closed-set comparator exactly, to 30. A rejection is not an action, so both defensible mappings are reported: to *Monitor*, and to *Raise alarm*.

**The repair is real and large.** On the held-out Mixture class, the support-vector classifier that under-escalates 99.5% of a hazardous class as a closed-set model reaches **0.9283** escalation adequacy once it may decline. The cost-weighted policy moves from 0.2634 to 0.8391. This is the most effective single intervention tested anywhere in the study on the metric Experiment 3 exists to expose.

**The price is paid on clean air.** At the same threshold the support-vector classifier rejects **57.3%** of held-out clean windows and the cost-weighted policy 60.4%. Mapped to an alarm that is an annunciation on three clean windows in five. Mapped to *Monitor* instead, every rejection becomes a missed hazard by definition, so the same threshold that lifts escalation to 0.9283 produces a 0.9283 missed-hazard rate. There is no free direction.

**Rejection behavior dissociates across models exactly as action behavior does.** Separation between the held-out-class and clean-window rejection rates runs from **+52.0 points** for the unweighted network on held-out Smoke to **−97.0 points** for gradient boosting, which declines 1.9% of an unfamiliar hazardous class while declining 98.7% of the clean air it was trained on. The random forest rejects everything at every threshold. A confidence score turns out to be no better a guide to behavior under an unfamiliar hazard than an accuracy figure, which is the paper's thesis arriving in a new place.

One observation fell out that belongs to Experiment 1's story. At a threshold set to reject 30% of *training* windows, every model rejects more than 30% of held-out clean windows, several of them far more. A deferral threshold calibrated in-sample on this corpus does not transfer to the partition it was meant for.

New: **Table 12**, Supplementary Section S11 with **Table S9**, `retrain/run_reject_option.py`, `v3_reject_option.csv`, `make reject`.

---

## Experiment 9. Faults in raw sensor space, and a silent failure mode

The pre-submission plan called this "the preferred path for a stronger paper": perturb the raw seven-channel window rather than the standardized decision state, and recompute everything downstream. That is what this does. The current readings, the per-channel deltas, the per-channel standard deviations and the autoencoder reconstruction error are all recomputed from the faulted raw window, so nothing is patched in feature space and a fault actually reaches the anomaly path.

Four modes a fixed detector meets: a channel *stuck* at its first reading, a channel at raw *zero* (open circuit, the case Experiment 6 states it does not cover), a channel *saturated* at the largest value seen in training, and additive noise in raw units at a fraction of each channel's own training standard deviation.

**The modes are not interchangeable, and the ordering is not what the standardized experiment implies.**

| Mode | Worst missed hazard | Worst under-escalation | Anomaly score (clean = 0.245) |
|---|---|---|---|
| Stuck, *k* = 7 | 0.0035 | 0.0209 | 0.248 |
| Open circuit, *k* = 7 | 0.0000 | 0.0000 | 1.000 |
| Saturated, *k* = 4 | **0.3930** | 0.5873 | **0.168** |
| Saturated, *k* = 7 | 0.0000 | **1.0000** | **0.011** |
| Raw noise, 2 SD | 0.1354 | 0.1415 | 0.806 |

Stuck-at is nearly benign. An open circuit is loud: reconstruction error goes to its ceiling and the false-alarm rate to 1.000, a failure anyone would notice within minutes.

**Saturation is the one that matters, because it is quiet.** At four saturated channels the worst comparator misses 39.3% of hazardous windows while reconstruction error falls *below* its clean-condition value. At seven, every comparator sends every hazardous window to a sub-alarm action: missed-hazard rate 0.0000, escalation adequacy 0.0000, alarm-grade false alarms 0.0000, reconstruction error 0.011. **Three of the four reported metrics read as perfect while nothing whatsoever reaches an operator.**

The mechanism is plain once seen. A reconstruction-based detector scores a window by how hard it is to rebuild, and a constant trace is the easiest thing there is to rebuild. Pinning a channel at its rail makes the reading look *more* normal to the component whose job is to notice abnormality. A one-sided upper threshold on reconstruction error catches the open circuit and the noise and is actively misled by the fault mode with the highest missed-hazard rate tested. That is an argument for a two-sided abnormality test, and it is invisible in standardized feature space, where a dropped channel is set to the training mean and the anomaly feature is not perturbed at all.

This retires two statements the manuscript had been making: that the electrical-zero case is untested, and that no fault mode beyond one per family is covered.

New: **Table 13**, Supplementary Section S12 with **Table S10**, `retrain/run_raw_faults.py`, `v3_raw_faults.csv`, `make rawfaults`.

---

## The overlap control, and an honest null

Reviews objected that the random-versus-blocked gap confounds two things: near-duplicate windows landing on both sides of the split, and training data drawn from the whole recording rather than a contiguous early band. The manuscript had narrowed its claim because nothing separated them.

A stride-20 window set shares no raw reading between any two windows, so contamination is impossible in it by construction. Four arms, random against blocked and overlapping against disjoint, every arm subsampled to the same 256-window training budget so sample size is not a confound.

**It does not resolve.** Averaged over six models the overlap effect is +1.56 points and the position effect −1.30, and neither keeps its sign: overlap runs from −1.98 to +5.85, position from −6.87 to +2.81. Two models are *more* accurate under the blocked protocol at this budget, which should not happen if contamination were the whole story.

We report the null. At a 256-window budget every model sits far below the operating point of the rest of the paper, so an effect estimated there may not transfer to a 4,900-window one. Experiment 1's claim stays where the evidence puts it: the protocol moves the number, and the contrast should not be attributed to overlap alone. The control is worth having because it converts "we could not separate them" into "we tried to separate them, at matched size, and could not".

New: Supplementary Section S10 with **Table S8**, `retrain/run_overlap_isolation.py`, `v3_overlap_isolation.csv`, `make overlap`.

---

## Everything that moved with them

Two body experiments and two body tables were added, so Tables 12 through 16 renumbered and the research-question table gained RQ5. Table 3 gained two columns. The Summary, the contributions and the Conclusion each carry one new finding. Two Limitations statements were retired as no longer true.

Ninety-nine checks were added to `verify_v13.py`, recomputing every cell of both new tables from its result file and gating the claims made about them in prose, including that saturation lowers the anomaly score below its clean value and that total saturation is silent on every comparator. One of those gates immediately caught an error I had made by hand: the clean row of Table 13 was written as all zeros when gradient boosting's clean missed-hazard rate is 0.0092.

The word budgets for the Summary, the Conclusion and the Results section were raised once, with the experiment count going from seven to nine, and both sections were compressed before the bands moved.
