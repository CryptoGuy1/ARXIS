# ARXIS revision v8

16 figures, 10 tables, three appendices.

## Changes in v8
1. The "Note on this version" block is gone, along with five other passages that
   described what earlier drafts did. A submitted paper states what was done.
   Both substantive caveats survive where they belong: the perception split
   caveat in Section 3.3, Table 4's caption and Limitations; the absence of any
   hardware evaluation in Limitations.
2. New experiment (Section 4.5, Fig. 13): anomaly-input sensitivity.
   run_anomaly_influence.py sweeps the anomaly feature across [0,1] on every
   test window with the other 21 features fixed, for seven comparators.
   Result: the channel is close to inert for most models (threshold rule 0.0%,
   k-NN 0.1%, SVM 0.7%, MLP 3.3%, cost-weighted 8.0%, random forest 16.1%) and
   load-bearing for gradient boosting (60.6%). Forcing it to zero moves GBM's
   missed-hazard rate from 0.0098 to 0.3405 and escalation from 0.990 to 0.495,
   while every other model is unaffected.
3. Figures renumbered; ablation figure repositioned; all cross-references checked.

## NOT in the paper, and why
folder_live_test_*.csv is a 4-sample smoke test (one synthetic sensor-only
sample per class) with an accompanying 20-row anomaly-override sweep. Too small
to support a reported result. Section 4.5 answers the same question properly on
1,264 test windows across five partitions and seven models.

save_action_target_model.py and diagnose_and_fix.py train on flattened raw
140-dimensional windows with a tail split, no embargo and no seed variation.
That is a deployable-checkpoint pipeline, not the paper's protocol, and its
accuracies are not comparable with Table 5. Keep the two separate.

## Code (drop into retrain/)
safety_metrics.py, new_baselines.py, run_all_v2.py, run_loco_v3.py,
run_calib_actions_v2.py, run_anomaly_influence.py, make_figs_v2.py
