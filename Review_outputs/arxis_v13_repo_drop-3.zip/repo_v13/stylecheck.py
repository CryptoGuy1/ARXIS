"""Stylometric diagnostics, benchmarked against a published human-written paper.

There is no reliable way to compute an "AI percentage" from text, and this does
not try. What it does is measure the features commercial detectors actually key
on, then report them side by side with SPE-219771, a peer-reviewed paper by
human authors in the same journal and section. A value inside the human paper's
neighbourhood is evidence the prose does not carry the signature; a value far
outside it is worth looking at. That comparison is interpretable. A score is not.
"""
import re, statistics as st
from collections import Counter

def load(path, md=False):
    t = open(path).read()
    for m in ("## References", "\nReferences\n"):
        if m in t: t = t[:t.index(m)]
    if md:
        t = re.sub(r"!\[\]\([^)]*\)", " ", t)
        # Drop markup that is not prose: tables, object captions, display
        # equations (indented with nbsp entities), and the keyword and
        # abbreviation lines, which are semicolon-delimited lists by house
        # style rather than sentences.
        t = "\n".join(l for l in t.split("\n")
                      if not l.strip().startswith("|")
                      and not l.strip().startswith("&nbsp;")
                      and not l.strip().startswith("**Keywords:**")
                      and not l.strip().startswith("**Abbreviations.**")
                      and not re.match(r"^\*\*(?:Table |Fig\. )\d+—", l.strip()))
        t = t.replace("&nbsp;", " ")
        t = re.sub(r"&[a-z]+;", " ", t)
        t = re.sub(r"[*#`_]", "", t)
        t = "\n".join(l.rstrip() + "." if l.strip().startswith("-")
                       and not l.rstrip().endswith((".", "?", "!")) else l
                       for l in t.split("\n"))
    t = re.sub(r"Downloaded from onepetro[^\n]*", " ", t)
    t = re.sub(r"\s+", " ", t)
    return t

def sentences(t):
    t = re.sub(r"(?<=\b[A-Z])\.", "", t)                  # initials
    t = re.sub(r"\b(et al|Fig|Eq|vs|approx|cf|i\.e|e\.g|Dr|No)\.", r"\1", t)
    return [s.strip() for s in re.split(r"(?<=[.!?])\s+", t) if len(s.split()) >= 4]

# "would" is excluded: in this manuscript it is almost always counterfactual
# ("a failed autoencoder would supply zero"), which is a conditional, not a hedge.
HEDGES = r"\b(may|might|could|appears?|suggests?|seems?|likely|possibly|perhaps|arguably|relatively|somewhat|generally|typically|often)\b"
CONNECT = r"\b(however|moreover|furthermore|therefore|thus|additionally|consequently|in addition|nevertheless|notably|importantly|overall|in conclusion|firstly|secondly)\b"

def metrics(name, t):
    S = sentences(t)
    L = [len(s.split()) for s in S]
    W = re.findall(r"[a-z']+", t.lower())
    tri = Counter(tuple(W[i:i+3]) for i in range(len(W)-2))
    rep3 = sum(c for c in tri.values() if c > 1) / max(len(W), 1)
    # moving-average type-token ratio over 400-word windows
    ttrs = [len(set(W[i:i+400]))/400 for i in range(0, max(len(W)-400, 1), 200)]
    return dict(
        name=name, words=len(W), sentences=len(S),
        sent_mean=st.mean(L), sent_sd=st.pstdev(L),
        burstiness=st.pstdev(L)/st.mean(L),
        sent_p10=sorted(L)[len(L)//10], sent_p90=sorted(L)[9*len(L)//10],
        short_pct=100*sum(1 for x in L if x <= 8)/len(L),
        long_pct=100*sum(1 for x in L if x >= 35)/len(L),
        mattr=st.mean(ttrs) if ttrs else 0,
        rep_trigram_pct=100*rep3,
        hedges_per_1k=1000*len(re.findall(HEDGES, t, re.I))/max(len(W),1),
        connectives_per_1k=1000*len(re.findall(CONNECT, t, re.I))/max(len(W),1),
        commas_per_sent=t.count(",")/len(S),
        semicolons_per_1k=1000*t.count(";")/max(len(W),1),
    )

rows = [metrics("SPE-219771 (human, published)", load("model_paper.txt")),
        metrics("ARXIS v10 (this manuscript)",   load("ARXIS_Manuscript_v10_SPE.md", md=True)),
        metrics("ARXIS v9 (earlier draft)",      load("ARXIS_Manuscript_v9.md", md=True))]

KEYS = [("words","words",".0f"),("sentences","sentences",".0f"),
        ("sent_mean","mean sentence length",".1f"),("sent_sd","sentence length SD",".1f"),
        ("burstiness","burstiness (SD/mean)",".3f"),
        ("sent_p10","10th pct length",".0f"),("sent_p90","90th pct length",".0f"),
        ("short_pct","sentences <= 8 words (%)",".1f"),
        ("long_pct","sentences >= 35 words (%)",".1f"),
        ("mattr","lexical diversity (MATTR)",".3f"),
        ("rep_trigram_pct","repeated trigrams (%)",".2f"),
        ("hedges_per_1k","hedges per 1k words",".1f"),
        ("connectives_per_1k","formulaic connectives per 1k",".1f"),
        ("commas_per_sent","commas per sentence",".2f"),
        ("semicolons_per_1k","semicolons per 1k words",".1f")]

w = 30
print(f"{'metric':<{w}} " + " ".join(f"{r['name'][:26]:>27}" for r in rows))
print("-" * (w + 1 + 28*len(rows)))
for k, label, fmt in KEYS:
    print(f"{label:<{w}} " + " ".join(f"{format(r[k], fmt):>27}" for r in rows))
